#!/usr/bin/env python3
"""
realtime_kernel_agent_windows.py
===================================
Windows-compatibele versie van Laag 3 (realtime procesmonitoring).

BELANGRIJKE KANTTEKENING: net als llm_botnet_scanner_windows.py is dit
gebouwd en getest op Linux via psutil's Linux-backend — de detectielogica
(groeicurve-drempels, dynamic-library-load-detectie, lineage-regels) is dus
functioneel getest, maar de daadwerkelijke Windows-systeemkoppeling van
psutil zelf (ToolHelp/WMI-API's) is hier niet op een echte Windows-machine
bevestigd.

Windows-specifieke aanpassing: de lijst met 'verdachte interpreters' en
'downloader-tools' gebruikt Windows-procesnamen (powershell.exe, cmd.exe,
certutil.exe — een bekende Windows LOLBin die vaak voor downloads wordt
misbruikt) in plaats van de Linux-namen (bash, curl, wget).

Dit bestand staat LOS van realtime_kernel_agent.py (de Linux/proc-native
versie die al in productie draait) — géén wijzigingen aan die werkende versie.

Extra Windows-vereiste: pip install psutil

Gebruik (identiek aan de Linux-versie):
  python realtime_kernel_agent_windows.py --interval 2 --duration 60 --json events.json
"""

import argparse
import ctypes
import json
import os
import re
import signal
import subprocess
import sys
import time
from collections import defaultdict

try:
    import psutil
except ImportError:
    print("[!] Het 'psutil'-package is vereist op Windows: pip install psutil", file=sys.stderr)
    sys.exit(1)

# ──────────────────────────────────────────────────────────────
# Signaturen
# ──────────────────────────────────────────────────────────────

ML_LIB_PATTERNS = [
    re.compile(r"nvcuda\.dll", re.IGNORECASE),
    re.compile(r"cublas.*\.dll", re.IGNORECASE),
    re.compile(r"cudnn.*\.dll", re.IGNORECASE),
    re.compile(r"torch.*\.(dll|pyd)", re.IGNORECASE),
    re.compile(r"ggml.*\.dll", re.IGNORECASE),
    re.compile(r"llama.*\.dll", re.IGNORECASE),
    re.compile(r"nvml\.dll", re.IGNORECASE),
    re.compile(r"tensorflow.*\.dll", re.IGNORECASE),
    re.compile(r"onnxruntime.*\.dll", re.IGNORECASE),
    re.compile(r"libcuda\.so"), re.compile(r"libtorch"), re.compile(r"libggml"),
]

# Modelbestand-extensies — zelfde brug tussen Laag 3 en Laag 5 als de
# Linux-variant (zie realtime_kernel_agent.py voor de volledige toelichting).
MODEL_FILE_PATTERNS = [
    re.compile(r"\.gguf$", re.IGNORECASE),
    re.compile(r"\.safetensors$", re.IGNORECASE),
    re.compile(r"\.ggml$", re.IGNORECASE),
    re.compile(r"\.pt$", re.IGNORECASE),
    re.compile(r"\.pth$", re.IGNORECASE),
    re.compile(r"\.onnx$", re.IGNORECASE),
    re.compile(r"\.bin$", re.IGNORECASE),
]
MIN_MODEL_FILE_SIZE_MB = 50

SUSPICIOUS_INTERPRETERS = {
    "powershell.exe", "powershell_ise.exe", "pwsh.exe", "cmd.exe",
    "python.exe", "pythonw.exe", "wscript.exe", "cscript.exe",
}

SUSPICIOUS_DOWNLOADER_PARENTS = {
    "curl.exe", "bitsadmin.exe", "certutil.exe", "mshta.exe",
}

RSS_SPIKE_DELTA_KB = 2 * 1024 * 1024
RSS_SPIKE_WINDOW_SEC = 15
POLL_INTERVAL_DEFAULT = 2.0


def is_admin() -> bool:
    try:
        if os.name == "nt":
            return ctypes.windll.shell32.IsUserAnAdmin() != 0
        return os.geteuid() == 0
    except Exception:
        return False


def read_cmdline(pid) -> str:
    try:
        p = psutil.Process(int(pid))
        return " ".join(p.cmdline())
    except (psutil.NoSuchProcess, psutil.AccessDenied, ValueError):
        return ""


def read_comm(pid) -> str:
    try:
        return psutil.Process(int(pid)).name()
    except (psutil.NoSuchProcess, psutil.AccessDenied, ValueError):
        return ""


def get_ppid(pid) -> str:
    try:
        return str(psutil.Process(int(pid)).ppid())
    except (psutil.NoSuchProcess, psutil.AccessDenied, ValueError):
        return ""


def get_rss_kb(pid) -> int:
    try:
        return psutil.Process(int(pid)).memory_info().rss // 1024
    except (psutil.NoSuchProcess, psutil.AccessDenied, ValueError):
        return 0


def get_loaded_libs(pid) -> set:
    try:
        p = psutil.Process(int(pid))
        return {m.path for m in p.memory_maps()}
    except (psutil.NoSuchProcess, psutil.AccessDenied, ValueError, NotImplementedError):
        return set()


def get_ml_libs(libs: set) -> set:
    hits = set()
    for lib in libs:
        for pattern in ML_LIB_PATTERNS:
            if pattern.search(lib):
                hits.add(lib)
    return hits


def get_loaded_model_files(libs: set) -> set:
    """Zelfde principe als get_ml_libs, maar dan gericht op modelbestanden."""
    hits = set()
    for path in libs:
        for pattern in MODEL_FILE_PATTERNS:
            if not pattern.search(path):
                continue
            if pattern.pattern.startswith(r"\.bin"):
                try:
                    size_mb = os.path.getsize(path) / (1024 * 1024)
                except OSError:
                    continue
                if size_mb < MIN_MODEL_FILE_SIZE_MB:
                    continue
            hits.add(path)
    return hits


def attempt_auto_attestation(model_path: str, endpoint_key: str, registry: str,
                              authority_pubkey: str, endpoint_pubkey: str, quote_dir: str) -> dict:
    """
    Windows-equivalent van dezelfde functie in realtime_kernel_agent.py —
    zie daar voor de volledige toelichting. Identieke logica, alleen het
    pad naar python.exe verschilt (sys.executable werkt op beide platforms).
    """
    script = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tpm_model_attestation.py")
    python_cmd = sys.executable or "python"

    if not os.path.isfile(endpoint_key):
        return {"status": "skipped", "reason": "Geen endpoint-sleutel gevonden — Laag 5 is nog niet ingesteld."}
    if not os.path.isfile(registry):
        return {"status": "skipped", "reason": "Geen registry gevonden — Laag 5 is nog niet ingesteld."}

    os.makedirs(quote_dir, exist_ok=True)
    quote_out = os.path.join(quote_dir, f"auto_quote_{int(time.time())}.json")

    try:
        quote_result = subprocess.run(
            [python_cmd, script, "measure-and-quote", "--model", model_path,
             "--endpoint-key", endpoint_key, "--out", quote_out],
            capture_output=True, text=True, timeout=30,
        )
        if quote_result.returncode != 0:
            return {"status": "error", "reason": f"measure-and-quote mislukt: {quote_result.stderr.strip()[:300]}"}

        with open(quote_out, encoding="utf-8") as f:
            quote_data = json.load(f)
        nonce = quote_data.get("nonce")
        if not nonce:
            return {"status": "error", "reason": "Quote-bestand bevat geen nonce — onverwacht formaat."}

        verify_result = subprocess.run(
            [python_cmd, script, "verify", "--quote", quote_out, "--registry", registry,
             "--authority-pubkey", authority_pubkey, "--endpoint-pubkey", endpoint_pubkey,
             "--expected-nonce", nonce],
            capture_output=True, text=True, timeout=30,
        )
        verified = verify_result.returncode == 0
        return {
            "status": "verified" if verified else "unauthorized",
            "quote_path": quote_out,
            "detail": verify_result.stdout.strip()[:500] if verified else verify_result.stderr.strip()[:500],
        }
    except subprocess.TimeoutExpired:
        return {"status": "error", "reason": "Time-out bij measure-and-quote/verify."}
    except Exception as e:
        return {"status": "error", "reason": f"Onverwachte fout: {e}"}


def list_pids() -> list:
    return [str(p) for p in psutil.pids()]


def build_lineage(pid: str, comm_cache: dict, max_depth=6) -> list:
    chain = []
    current = pid
    for _ in range(max_depth):
        comm = comm_cache.get(current) or read_comm(current)
        if not comm:
            break
        chain.append((current, comm))
        ppid = get_ppid(current)
        if not ppid or ppid == "0" or ppid == current:
            break
        current = ppid
    return chain


def lineage_is_suspicious(chain: list):
    ancestor_comms = [comm for _, comm in chain[1:]]
    for comm in ancestor_comms:
        if comm in SUSPICIOUS_DOWNLOADER_PARENTS:
            return f"Gespawnd (indirect) door downloader-tool '{comm}' — past bij drop-and-execute"
    for comm in ancestor_comms:
        if comm in SUSPICIOUS_INTERPRETERS:
            return f"Gespawnd via script-interpreter '{comm}' vóór ML-library-load — mogelijk injectie/dropper"
    return None


class ProcessState:
    def __init__(self, pid, ts, rss_kb, libs, comm, ppid, cmdline):
        self.pid = pid
        self.first_seen = ts
        self.rss_history = [(ts, rss_kb)]
        self.libs_seen = set(libs)
        self.comm = comm
        self.ppid = ppid
        self.cmdline = cmdline
        self.reported_growth = False
        self.reported_libs = set()
        self.reported_lineage = False
        self.reported_model_files = set()

    def update(self, ts, rss_kb, libs):
        self.rss_history.append((ts, rss_kb))
        cutoff = ts - RSS_SPIKE_WINDOW_SEC * 3
        self.rss_history = [(t, r) for t, r in self.rss_history if t >= cutoff]
        new_libs = libs - self.libs_seen
        self.libs_seen |= libs
        return new_libs

    def rss_growth_in_window(self, now_ts):
        recent = [(t, r) for t, r in self.rss_history if now_ts - t <= RSS_SPIKE_WINDOW_SEC]
        if len(recent) < 2:
            return 0
        return max(r for _, r in recent) - min(r for _, r in recent)


class Agent:
    def __init__(self, interval, duration, json_path, flush_interval=60, auto_attest=True):
        self.interval = interval
        self.duration = duration
        self.json_path = json_path
        self.flush_interval = flush_interval
        self.states = {}
        self.events = []
        self.running = True
        self.auto_attest = auto_attest
        keys_base = os.path.expanduser("~/llm-detect-keys")
        self.endpoint_key = os.path.join(keys_base, "endpoint_keys", "private.pem")
        self.endpoint_pubkey = os.path.join(keys_base, "endpoint_keys", "public.pem")
        self.authority_pubkey = os.path.join(keys_base, "authority_keys", "public.pem")
        self.registry = os.path.join(keys_base, "registry.json")
        self.quote_dir = os.path.join(keys_base, "auto_quotes")

    def stop(self, *_):
        self.running = False

    def write_json(self):
        if self.json_path:
            # Zelfde race-condition-fix als de Linux-variant — zie
            # realtime_kernel_agent.py voor de volledige toelichting. De
            # lock-helpers in result_integrity.py zijn cross-platform
            # (msvcrt op Windows, fcntl op Linux), dus deze code is
            # ongewijzigd t.o.v. de Linux-versie.
            import result_integrity as _ri
            lock_path = f"{self.json_path}.lock"
            lock_file = open(lock_path, "a+b")
            if os.path.getsize(lock_path) == 0:
                lock_file.write(b"0")
                lock_file.flush()
            lock_file.seek(0)
            _ri._lock_exclusive(lock_file)
            try:
                tmp_path = f"{self.json_path}.tmp"
                with open(tmp_path, "w", encoding="utf-8") as f:
                    json.dump(self.events, f, indent=2)
                os.replace(tmp_path, self.json_path)
                try:
                    _key_dir = os.path.expanduser("~/llm-detect-keys/result-integrity")
                    _priv = _ri.get_or_create_signing_key(_key_dir)
                    _ri.sign_result_file(self.json_path, _priv)
                except Exception as _e:
                    print(f"[!] Kon resultaat niet ondertekenen ({_e}) — bestand blijft ongesigneerd.")
            finally:
                _ri._unlock(lock_file)
                lock_file.close()

    def emit(self, severity, pid, comm, cmdline, message):
        event = {
            "ts": round(time.time(), 2),
            "severity": severity,
            "pid": pid,
            "comm": comm,
            "cmdline": cmdline[:200],
            "message": message,
        }
        self.events.append(event)
        print(f"  [{severity}] PID {pid} ({comm})  {message}")

    def poll_once(self):
        ts = time.time()
        current_pids = set(list_pids())
        comm_cache = {}

        for pid in current_pids:
            comm = read_comm(pid)
            comm_cache[pid] = comm
            if not comm:
                continue

            rss_kb = get_rss_kb(pid)
            all_libs = get_loaded_libs(pid)
            ml_libs = get_ml_libs(all_libs)
            model_files = get_loaded_model_files(all_libs)
            cmdline = read_cmdline(pid) or comm

            if pid not in self.states:
                self.states[pid] = ProcessState(
                    pid, ts, rss_kb, ml_libs, comm, get_ppid(pid), cmdline
                )
                new_ml_libs = ml_libs
            else:
                state = self.states[pid]
                new_ml_libs = state.update(ts, rss_kb, ml_libs)
                state = self.states[pid]

            state = self.states[pid]

            growth = state.rss_growth_in_window(ts)
            if growth >= RSS_SPIKE_DELTA_KB and not state.reported_growth:
                state.reported_growth = True
                self.emit(
                    "HOOG", pid, comm, cmdline,
                    f"Acute geheugengroei: +{growth / (1024*1024):.2f} GB binnen "
                    f"{RSS_SPIKE_WINDOW_SEC}s — past bij model-loading"
                )

            newly_loaded = new_ml_libs - state.reported_libs
            if newly_loaded:
                state.reported_libs |= newly_loaded
                elapsed = ts - state.first_seen
                self.emit(
                    "HOOG", pid, comm, cmdline,
                    f"ML/GPU-bibliotheek dynamisch geladen ({elapsed:.1f}s na eerste observatie): "
                    f"{', '.join(sorted(newly_loaded))}"
                )

                chain = build_lineage(pid, comm_cache)
                reason = lineage_is_suspicious(chain)
                if reason and not state.reported_lineage:
                    state.reported_lineage = True
                    chain_str = " ← ".join(f"{c}({p})" for p, c in chain)
                    self.emit(
                        "KRITIEK", pid, comm, cmdline,
                        f"{reason}. Ouderketen: {chain_str}"
                    )

            # ── Signaal 4: nieuw modelbestand -> brug naar Laag 5 (standaard AAN, --no-auto-attest om uit te zetten) ──
            new_model_files = model_files - state.reported_model_files
            if new_model_files:
                state.reported_model_files |= new_model_files
                if self.auto_attest:
                    for model_path in sorted(new_model_files):
                        result = attempt_auto_attestation(
                            model_path, self.endpoint_key, self.registry,
                            self.authority_pubkey, self.endpoint_pubkey, self.quote_dir,
                        )
                        if result["status"] == "verified":
                            self.emit(
                                "INFO", pid, comm, cmdline,
                                f"Nieuw modelbestand automatisch geverifieerd en toegestaan: {model_path}"
                            )
                        elif result["status"] == "unauthorized":
                            self.emit(
                                "KRITIEK", pid, comm, cmdline,
                                f"Nieuw modelbestand NIET geautoriseerd (niet in registry of ingetrokken): {model_path} — {result.get('detail', '')}"
                            )
                        elif result["status"] == "skipped":
                            self.emit(
                                "INFO", pid, comm, cmdline,
                                f"Nieuw modelbestand gezien, automatische attestatie overgeslagen: {model_path} ({result['reason']})"
                            )
                        else:
                            self.emit(
                                "AANDACHT", pid, comm, cmdline,
                                f"Nieuw modelbestand gezien, automatische attestatie mislukte: {model_path} ({result.get('reason', 'onbekende fout')})"
                            )
                else:
                    self.emit(
                        "INFO", pid, comm, cmdline,
                        f"Nieuw modelbestand gezien (--no-auto-attest actief, geen actie ondernomen): {', '.join(sorted(new_model_files))}"
                    )

        for pid in list(self.states.keys()):
            if pid not in current_pids:
                del self.states[pid]

    def run(self):
        signal.signal(signal.SIGINT, self.stop)
        try:
            signal.signal(signal.SIGTERM, self.stop)
        except (ValueError, AttributeError):
            pass

        print(f"── Realtime kernel-agent gestart (interval={self.interval}s, duur={self.duration}s) ──")
        print("   Ctrl+C om te stoppen.\n")

        start = time.time()
        last_flush = start
        while self.running and (time.time() - start) < self.duration:
            self.poll_once()
            if time.time() - last_flush >= self.flush_interval:
                self.write_json()
                last_flush = time.time()
            time.sleep(self.interval)

        print(f"\n── Agent gestopt na {time.time() - start:.1f}s. {len(self.events)} events gelogd. ──")

        self.write_json()
        if self.json_path:
            print(f"Events geschreven naar: {self.json_path}")


def main():
    parser = argparse.ArgumentParser(description="Realtime kernel-adjacent monitoring agent — Windows-versie (psutil-gebaseerd)")
    parser.add_argument("--interval", type=float, default=POLL_INTERVAL_DEFAULT)
    parser.add_argument("--duration", type=float, default=60)
    parser.add_argument("--json", default=None)
    parser.add_argument("--flush-interval", type=float, default=60)
    parser.add_argument("--no-auto-attest", action="store_true",
                         help="Schakel de automatische koppeling aan Laag 5 UIT — staat sinds deze versie "
                              "standaard AAN (zie realtime_kernel_agent.py voor de volledige toelichting).")
    args = parser.parse_args()

    agent = Agent(args.interval, args.duration, args.json, args.flush_interval, not args.no_auto_attest)
    agent.run()

    if not is_admin():
        print(
            "\n[!] Let op: niet als Administrator gedraaid — alleen processen van de "
            "huidige gebruiker zijn volledig inspecteerbaar. Voor systeembrede monitoring: "
            "start als Administrator."
        )


if __name__ == "__main__":
    main()
