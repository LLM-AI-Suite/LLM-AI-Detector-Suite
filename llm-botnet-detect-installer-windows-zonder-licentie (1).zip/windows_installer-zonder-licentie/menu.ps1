﻿# menu.ps1 - LLM-Botnet Detectiesysteem, interactief keuzemenu
# Wordt aangeroepen door de bootstrap in het README - hoeft nooit los
# gedraaid te worden, tenzij je zelf al in een uitgepakte map staat.
#
# NOTE: net als install.ps1/uninstall.ps1/update.ps1 is dit script NIET
# uitgevoerd op een echte Windows-machine (de ontwikkelomgeving heeft
# geen toegang tot Windows/PowerShell). Zorgvuldig geschreven naar het
# bewezen patroon van de Linux-versie (menu.sh, daar wel volledig
# getest), maar test dit eerst op een niet-kritieke machine.

try {
    $DetectedLang = (Get-Culture).TwoLetterISOLanguageName
} catch {
    $DetectedLang = "en"
}
if ($DetectedLang -eq "nl") {
    $UiLang = "nl"
} else {
    $UiLang = "en"
}

$T_NL = @{
    title = "LLM-Botnet Detectiesysteem"
    menu_intro = "Wat wil je doen?"
    opt_a = "a) Installeren (eerste keer, of naast een bestaande installatie)"
    opt_b = "b) Bijwerken (behoudt sleutels en geschiedenis)"
    opt_c = "c) Verse installatie (verwijdert alles, installeert daarna opnieuw)"
    opt_d = "d) Verwijderen (software stoppen, geen herinstallatie)"
    opt_e = "e) Diagnose draaien (basisstatus in een keer)"
    opt_f = "f) Netwerkinterface controleren/herstellen (Laag 2)"
    opt_wachter = "Alleen de Wachter-tier (uitgeklede installatie, alleen Laag 2)? [j/n, leeg = n]"
    prompt = "Keuze [a/b/c/d/e/f]"
    invalid = "Onbekende keuze - probeer opnieuw."
    purge_confirm = "Verse installatie verwijdert ook je TPM-sleutels en scangeschiedenis. Doorgaan? [j/n]"
    aborted = "Afgebroken - niets gewijzigd."
    no_install_found = "Geen bestaande installatie gevonden - kies eerst 'a' of 'c'."
    diag_title = "=== Basisdiagnose ==="
    diag_version = "Versie:"
    diag_install_dir = "Installatiemap:"
    diag_not_installed = "Niet geinstalleerd (map niet gevonden)."
    diag_port_listening = "GUI lijkt actief (poort 5000 is in gebruik)."
    diag_port_not_listening = "GUI lijkt niet actief (poort 5000 niet in gebruik) - dat is normaal als je 'm nu niet hebt gestart."
    diag_models = "Modellen in registry:"
    iface_check_title = "=== Netwerkinterface-controle ==="
    iface_current = "Beschikbare interfaces:"
    iface_note = "Windows heeft geen doorlopende Laag 2-achtergrondservice (handmatig starten via de GUI, zie 8.3 in de documentatie) - deze controle toont daarom alleen de huidige beschikbare interfaces, ter informatie bij het kiezen in de GUI zelf."
}

$T_EN = @{
    title = "LLM-Botnet Detection System"
    menu_intro = "What would you like to do?"
    opt_a = "a) Install (first time, or alongside an existing installation)"
    opt_b = "b) Update (keeps keys and history)"
    opt_c = "c) Fresh install (removes everything, then reinstalls)"
    opt_d = "d) Uninstall (stop software, no reinstall)"
    opt_e = "e) Run diagnostics (basic status at a glance)"
    opt_f = "f) Check/repair network interface (Layer 2)"
    opt_wachter = "Sentinel tier only (stripped-down install, Layer 2 only)? [y/n, blank = n]"
    prompt = "Choice [a/b/c/d/e/f]"
    invalid = "Unrecognized choice - please try again."
    purge_confirm = "Fresh install also removes your TPM keys and scan history. Continue? [y/n]"
    aborted = "Aborted - nothing changed."
    no_install_found = "No existing installation found - choose 'a' or 'c' first."
    diag_title = "=== Basic diagnostics ==="
    diag_version = "Version:"
    diag_install_dir = "Install directory:"
    diag_not_installed = "Not installed (directory not found)."
    diag_port_listening = "GUI appears active (port 5000 in use)."
    diag_port_not_listening = "GUI does not appear active (port 5000 not in use) - that's normal if you haven't started it right now."
    diag_models = "Models in registry:"
    iface_check_title = "=== Network interface check ==="
    iface_current = "Available interfaces:"
    iface_note = "Windows has no continuous Layer 2 background service (started manually via the GUI, see 8.3 in the documentation) - this check therefore only shows currently available interfaces, for reference when choosing in the GUI itself."
}

function T($key) {
    if ($UiLang -eq "nl") { return $T_NL[$key] } else { return $T_EN[$key] }
}

$ScriptDir = $PSScriptRoot
$InstallDir = "$env:LOCALAPPDATA\llm-botnet-detect"

Write-Host (T "title") -ForegroundColor Green
Write-Host "=================================================="
Write-Host ""
Write-Host (T "menu_intro")
Write-Host (T "opt_a")
Write-Host (T "opt_b")
Write-Host (T "opt_c")
Write-Host (T "opt_d")
Write-Host (T "opt_e")
Write-Host (T "opt_f")
Write-Host ""
$Choice = Read-Host (T "prompt")

switch ($Choice) {
    "a" {
        $Wachter = Read-Host (T "opt_wachter")
        if ($Wachter -eq "j" -or $Wachter -eq "J" -or $Wachter -eq "y" -or $Wachter -eq "Y") {
            & "$ScriptDir\install.ps1" -Wachter
        } else {
            & "$ScriptDir\install.ps1"
        }
    }
    "b" {
        & "$ScriptDir\update.ps1"
    }
    "c" {
        $Confirm = Read-Host (T "purge_confirm")
        if ($Confirm -ne "j" -and $Confirm -ne "J" -and $Confirm -ne "y" -and $Confirm -ne "Y") {
            Write-Host (T "aborted")
            exit 0
        }
        if (Test-Path $InstallDir) {
            & "$ScriptDir\uninstall.ps1" -PurgeAll
            # Zelfde subtiliteit als de Linux-versie: uninstall.ps1 geeft
            # exit 0 terug bij zowel een geslaagde verwijdering als een
            # bewuste afbreking (bijv. het bevestigingswoord niet exact
            # getypt) - controleer daarom of de installatiemap
            # daadwerkelijk weg is voordat we naar install.ps1 doorgaan.
            if (Test-Path $InstallDir) {
                Write-Host (T "aborted")
                exit 1
            }
        }
        $Wachter = Read-Host (T "opt_wachter")
        if ($Wachter -eq "j" -or $Wachter -eq "J" -or $Wachter -eq "y" -or $Wachter -eq "Y") {
            & "$ScriptDir\install.ps1" -Wachter
        } else {
            & "$ScriptDir\install.ps1"
        }
    }
    "d" {
        & "$ScriptDir\uninstall.ps1"
    }
    "e" {
        Write-Host (T "diag_title")
        if (-not (Test-Path $InstallDir)) {
            Write-Host (T "diag_not_installed")
        } else {
            Write-Host "$(T 'diag_install_dir') $InstallDir"
            $VersionPath = Join-Path $InstallDir "VERSION"
            if (Test-Path $VersionPath) {
                Write-Host "$(T 'diag_version') $((Get-Content $VersionPath -Raw).Trim())"
            }
            $PortInUse = $false
            try {
                $Connections = Get-NetTCPConnection -LocalPort 5000 -State Listen -ErrorAction SilentlyContinue
                if ($Connections) { $PortInUse = $true }
            } catch { }
            if ($PortInUse) { Write-Host (T "diag_port_listening") } else { Write-Host (T "diag_port_not_listening") }
            $RegistryPath = "$env:USERPROFILE\llm-detect-keys\registry.json"
            if (Test-Path $RegistryPath) {
                try {
                    $Registry = Get-Content $RegistryPath -Raw | ConvertFrom-Json
                    Write-Host "$(T 'diag_models') $($Registry.models.Count)"
                } catch { }
            }
        }
    }
    "f" {
        Write-Host (T "iface_check_title")
        Write-Host (T "iface_note")
        Write-Host ""
        Write-Host (T "iface_current")
        Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
            Where-Object { $_.IPAddress -ne "127.0.0.1" } |
            ForEach-Object { Write-Host "  - $($_.InterfaceAlias) ($($_.IPAddress))" }
    }
    default {
        Write-Host (T "invalid")
        exit 1
    }
}
