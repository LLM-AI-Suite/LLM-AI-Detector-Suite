#!/bin/bash
# diagnose-detectiesuite.sh — Volledige diagnose van de LLM-Botnet Detectiesuite
# Gebruik: bash diagnose-detectiesuite.sh > diagnose-output.txt 2>&1
# Geeft in 1 keer alle info die normaal via losse commando's werd opgevraagd.

INSTALL_DIR="/opt/llm-botnet-detect"
RESULTS_DIR_PRIMARY="/var/log/llm-detect"
# Als dit script via sudo draait (bijv. vanuit de GUI's Testen & Simulatie-
# tabblad, zie whitepaper 9.21), is $HOME root's eigen thuismap — niet die
# van de installerende gebruiker. sudo zet in dat geval zelf $SUDO_USER op
# de oorspronkelijke, echte gebruiker; die gebruiken we hier in plaats van
# een kaal $HOME. Zonder dit resolven alle onderstaande paden (resultaten-
# fallback, sleutels, registry) stilzwijgend verkeerd zodra dit script voor
# het eerst als root draait — precies hetzelfde bugpatroon dat elders in
# het project al eerder gevonden en gerepareerd is (zie 9.15/9.17/9.19),
# hier ontdekt via een echte productie-diagnose die 30 'tampered'-bestanden
# rapporteerde die dat in werkelijkheid niet waren.
REAL_USER="${SUDO_USER:-$(whoami)}"
REAL_HOME=$(eval echo "~$REAL_USER")
RESULTS_DIR_FALLBACK="$REAL_HOME/llm-detect-results"
KEYS_DIR="$REAL_HOME/llm-detect-keys"

sep() { echo ""; echo "=================================================================="; echo "== $1"; echo "=================================================================="; }

sep "0. BASISINFO"
echo "Hostnaam: $(hostname)"
echo "Datum/tijd: $(date)"
echo "OS: $(cat /etc/os-release 2>/dev/null | grep PRETTY_NAME)"

sep "1. VERSIE EN INSTALLATIELOCATIE"
echo "Geïnstalleerd in: $INSTALL_DIR"
[ -f "$INSTALL_DIR/VERSION" ] && echo "Versie: $(cat "$INSTALL_DIR/VERSION")" || echo "❌ VERSION niet gevonden"
ls -la "$INSTALL_DIR" 2>&1 | head -30

sep "2. WELKE RESULTATENMAP WORDT DAADWERKELIJK GEBRUIKT"
echo "Primair ($RESULTS_DIR_PRIMARY):"
if [ -d "$RESULTS_DIR_PRIMARY" ] && [ -w "$RESULTS_DIR_PRIMARY" ]; then
    echo "  ✅ bestaat en is beschrijfbaar voor $(whoami) -> WORDT GEBRUIKT"
    RESULTS_DIR="$RESULTS_DIR_PRIMARY"
else
    echo "  ⚠️  bestaat niet of niet beschrijfbaar"
fi
echo "Fallback ($RESULTS_DIR_FALLBACK):"
[ -d "$RESULTS_DIR_FALLBACK" ] && echo "  bestaat, $(ls "$RESULTS_DIR_FALLBACK" 2>/dev/null | wc -l) bestanden" || echo "  bestaat niet"
ls -la "$RESULTS_DIR_PRIMARY" 2>/dev/null | grep -v "^total" | awk '{print $3":"$4}' | sort | uniq -c
echo "(bovenstaande toont eigendom per bestand — gemengd root/gebruiker-eigendom is een signaal voor een chown-probleem)"

sep "3. SERVICES — STATUS"
echo "--- User-services (GUI, correlatie, netflow-verwerking) ---"
systemctl --user status llm-detect-gui.service --no-pager 2>&1 | grep -E "Active:|Main PID:"
systemctl --user status llm-detect-correlate.timer --no-pager 2>&1 | grep -E "Active:"
systemctl --user status llm-detect-netflow-process.timer --no-pager 2>&1 | grep -E "Active:"
echo "--- Systeembrede services (Laag 3, netflow-capture) ---"
sudo systemctl status llm-detect-realtime-agent.service --no-pager 2>&1 | grep -E "Active:|Main PID:"
sudo systemctl status llm-detect-softflowd.service --no-pager 2>&1 | grep -E "Active:"
sudo systemctl status nfdump@llmdetect.service --no-pager 2>&1 | grep -E "Active:"

sep "4. RECENTE SERVICE-FOUTEN (laatste 2 uur)"
journalctl --user -u llm-detect-gui.service -p err --since "2 hours ago" --no-pager 2>&1 | tail -20
sudo journalctl -u llm-detect-realtime-agent.service -p err --since "2 hours ago" --no-pager 2>&1 | tail -20

sep "5. RATE-LIMIT-STATUS (429's in de laatste 15 minuten)"
COUNT_429=$(journalctl --user -u llm-detect-gui.service --since "15 minutes ago" --no-pager 2>&1 | grep -c "429")
echo "Aantal 429-responses: $COUNT_429"
[ "$COUNT_429" -gt 5 ] && echo "⚠️  Verhoogd — mogelijk een rate-limit-lockout actief" || echo "✅ Normaal"

sep "6. CRASH-RAPPORTEN (Ubuntu Apport, van onze eigen scripts)"
ls /var/crash/_opt_llm-botnet-detect_*.crash 2>/dev/null || echo "Geen crash-rapporten gevonden"

sep "7. GEPLANDE TAKEN BUITEN ONZE EIGEN SERVICES (cron/timer)"
echo "Gevonden via een los, extern cron-item dat maandenlang onopgemerkt 'tampered'-"
echo "resultaten produceerde (root/gebruiker-sleutelmismatch) — deze sectie zoekt"
echo "actief naar vergelijkbare, niet-officiële verwijzingen naar onze eigen scripts."
FOUND_EXTERNAL=$(sudo grep -rl "llm_botnet_scanner\|tpm_model_attestation\|realtime_kernel_agent\|correlation_engine" \
    /etc/cron.d/ /etc/cron.hourly/ /etc/cron.daily/ /etc/crontab 2>/dev/null)
if [ -n "$FOUND_EXTERNAL" ]; then
    echo "⚠️  Gevonden, buiten onze officiële llm-detect-*-services om:"
    echo "$FOUND_EXTERNAL"
    echo "   Controleer of dit bewust is (bijv. een eigen, aanvullende scan) en of het"
    echo "   als de juiste gebruiker draait — niet als root zonder LLM_DETECT_KEY_DIR."
else
    echo "✅ Niets gevonden buiten onze eigen services."
fi
ROOT_CRONTAB=$(sudo crontab -l 2>/dev/null | grep -c "llm_botnet_scanner\|tpm_model_attestation\|realtime_kernel_agent\|correlation_engine")
[ "$ROOT_CRONTAB" -gt 0 ] 2>/dev/null && echo "⚠️  Ook gevonden in root's eigen crontab (sudo crontab -l)"

sep "8. INTEGRITEITSSTATUS — SAMENVATTING OVER ALLE RESULTATEN"
python3 -c "
import sys, os, glob, json
sys.path.insert(0, '$INSTALL_DIR')
import result_integrity as ri
key_dir = '$KEYS_DIR/result-integrity'
try:
    pub = ri.get_public_key(key_dir)
except Exception as e:
    print(f'❌ Kon publieke sleutel niet laden: {e}')
    sys.exit(0)
counts = {}
per_bestand_tampered = []
for f in glob.glob('$RESULTS_DIR_PRIMARY/*.json') + glob.glob('$RESULTS_DIR_FALLBACK/*.json'):
    if 'samples' in f:
        continue
    try:
        status = ri.verify_result_file(f, pub)['status']
    except Exception:
        continue
    counts[status] = counts.get(status, 0) + 1
    if status == 'tampered':
        per_bestand_tampered.append(f)
print('Verdeling:', counts)
if per_bestand_tampered:
    print('Gemanipuleerde bestanden:')
    for f in per_bestand_tampered[:10]:
        print(' ', f)
"

sep "9. SLEUTELS — AANWEZIGHEID EN EIGENDOM"
ls -la "$KEYS_DIR/result-integrity/" 2>&1
ls -la "$KEYS_DIR/authority_keys/" 2>&1
ls -la "$KEYS_DIR/endpoint_keys/" 2>&1

sep "10. MODELREGISTRY — SAMENVATTING"
python3 -c "
import json, os
path = '$KEYS_DIR/registry.json'
try:
    with open(path) as f:
        r = json.load(f)
    models = r.get('models', [])
    revoked = r.get('revoked', [])
    print(f'Totaal modellen: {len(models)}')
    print(f'Ingetrokken: {len(revoked)}')
    for m in models:
        naam = m.get('name', '(naamloos)')
        vlag = ''
        if naam.endswith('.part'):
            vlag = ' [WAARSCHIJNLIJK ONVOLTOOIDE DOWNLOAD]'
        if naam.endswith('.bik') or naam.endswith('.bin'):
            vlag = ' [WAARSCHIJNLIJK GEEN MODEL — CONTROLEREN]'
        print(f'  {naam}{vlag}')
except FileNotFoundError:
    print('Nog geen registry.json — Laag 5 nog niet ingesteld')
except Exception as e:
    print(f'❌ Fout bij lezen: {e}')
"

sep "11. DEMPINGEN (findings/dismiss) — WAT STAAT ER ACTIEF GEDEMPT"
cat "$RESULTS_DIR_FALLBACK/dismissed_findings.json" 2>/dev/null || echo "Geen dempingen actief"

sep "12. SCHIJFRUIMTE"
df -h / /var/log /home 2>&1

sep "13. NETWERKINTERFACES (voor Laag 2-configuratie)"
ip -4 -o addr show 2>/dev/null | awk '{print "  - "$2" ("$4")"}' | grep -v " (127"

sep "14. TAILSCALE-STATUS"
tailscale status 2>&1 | head -10

sep "15. SYSTEMTRAY — DRAAIT HET, EN ZIJN DE JUISTE PAKKETTEN AANWEZIG"
pgrep -af tray_indicator.py || echo "Systemtray-proces niet actief"
dpkg -l gir1.2-ayatanaappindicator3-0.1 2>&1 | tail -1

sep "16. LAATSTE 10 REGELS UIT DE GESCHIEDENIS (via de API, vereist inloggegevens)"
echo "(sla over als je dit niet interactief met wachtwoord wilt draaien — commentaar de regel hieronder uit)"
# curl -sk "https://localhost:5000/api/history" -u JOUW_GEBRUIKER:JOUW_WACHTWOORD 2>&1 | python3 -m json.tool 2>&1 | head -40

sep "EINDE DIAGNOSE"
echo "Kopieer alles hierboven en plak het terug."
