# LLM-Botnet Detection System

> **Edition: no license code required / Editie: geen licentiecode nodig.**
> This package ("zonder licentie") installs directly — the installer never asks for or checks a
> license code. It is a separate edition next to the licensed package: extract it into its own folder.
> Dit pakket ("zonder licentie") installeert direct — het installatieprogramma vraagt nooit om een
> licentiecode en controleert er geen. Het is een aparte editie naast het gelicentieerde pakket: pak het in een eigen map uit.

A five-layer behavioral detection system against distributed, C2-less
LLM botnets — file/process/network scanning, netflow gossip-pattern
detection, real-time kernel monitoring, GPU fingerprinting, and
cryptographic model attestation (TPM-style), combined by a correlation
engine into a single dashboard.

This file covers **both Linux and Windows**. Jump to the section for
your platform below. (Nederlandse versie verderop in dit bestand.)

---

## Contents

- [Linux — Quick Reference](#linux--quick-reference)
- [Windows — Quick Reference](#windows--quick-reference)
- [Lost track of where the files are?](#lost-track-of-where-the-files-are)
- [Nederlandse versie](#nederlandse-versie)

---

## Linux — Quick Reference

### Recommended: one command, with a menu

Already downloaded and extracted somewhere (location doesn't matter)? Open a terminal (Ctrl+Alt+T) and paste this — it finds the package on your system and shows a menu (install / update / fresh install / uninstall / diagnostics / repair interface):

```bash
bash -c 'F=$(find ~ -iname "menu.sh" -path "*llm-botnet*" -not -path "*/oud-verzameld/*" -not -path "*/.local/share/Trash/*" -not -path "*/.Trash*" -not -path "*/\$RECYCLE.BIN/*" -printf "%T@ %p\n" 2>/dev/null | sort -rn | head -1 | cut -d" " -f2-); if [ -z "$F" ]; then echo "Package not found — first extract llm-botnet-detect-installer-linux-zonder-licentie.tar.gz (e.g. in ~/Downloads)."; else bash "$F"; fi'
```

Just follow the on-screen prompts from there. Choosing **install** or **fresh install** will also ask whether you want the **Sentinel tier only** (stripped-down install, Layer 2 only) — the same command above works for both scenarios, no separate command needed.

### Manual, step by step

### Requirements
Ubuntu 22.04/24.04 (or similar), Python 3.10+, sudo access.

### Install

```bash
cd ~/Downloads
tar -xzf llm-botnet-detect-installer-linux-zonder-licentie.tar.gz
cd llm-botnet-detect-installer-zonder-licentie
chmod +x install.sh uninstall.sh update.sh
./install.sh
```

`chmod +x` is required once per fresh download — Linux blocks execution
of a file until you explicitly grant that permission. Without this step
you'll see "Permission denied", not a broken package.

### Update (keeps your keys and scan history)

```bash
cd ~/Downloads
tar -xzf llm-botnet-detect-installer-linux-zonder-licentie.tar.gz    # from a FRESH download
cd llm-botnet-detect-installer-zonder-licentie
chmod +x update.sh
./update.sh
```

### Uninstall

```bash
cd ~/llm-botnet-detect-installer-zonder-licentie
./uninstall.sh                 # keeps your keys and scan history
./uninstall.sh --purge-all     # removes everything, no way back
```

### Full copy-paste block (download → install, in one go)

```bash
cd ~/Downloads && \
tar -xzf llm-botnet-detect-installer-linux-zonder-licentie.tar.gz && \
cd llm-botnet-detect-installer-zonder-licentie && \
chmod +x install.sh uninstall.sh update.sh && \
./install.sh
```

---

## Windows — Quick Reference

### Recommended: one command, with a menu

Already downloaded and extracted somewhere (location doesn't matter)? Open PowerShell and paste this — it finds the package on your system and shows a menu:

```powershell
$F = Get-ChildItem -Path $env:USERPROFILE -Filter "menu.ps1" -Recurse -ErrorAction SilentlyContinue | Where-Object { $_.DirectoryName -like "*windows_installer*" } | Select-Object -First 1 -ExpandProperty FullName
if (-not $F) { Write-Host "Package not found — first extract llm-botnet-detect-installer-windows-zonder-licentie.zip (e.g. in Downloads)." } else { Unblock-File -Path $F; & $F }
```

Just follow the on-screen prompts from there. Choosing **install** or **fresh install** will also ask whether you want the **Sentinel tier only** (stripped-down install, Layer 2 only) — the same command above works for both scenarios, no separate command needed.

### Manual, step by step

### Requirements
Windows 10/11, Python 3.10+ (with `python` in PATH), PowerShell.

### Install

```powershell
cd $env:USERPROFILE\Downloads
Expand-Archive -Path llm-botnet-detect-installer-windows-zonder-licentie.zip -DestinationPath . -Force
cd windows_installer-zonder-licentie
Unblock-File -Path .\install.ps1, .\uninstall.ps1, .\update.ps1
.\install.ps1
```

`Unblock-File` is required once per fresh download — Windows flags any
file downloaded from the internet, which silently blocks script
execution even with the right execution policy. If PowerShell still
refuses to run the script after that, run this once (per PowerShell
session, not permanent):

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

### Update (keeps your keys and scan history)

```powershell
cd $env:USERPROFILE\Downloads
Expand-Archive -Path llm-botnet-detect-installer-windows-zonder-licentie.zip -DestinationPath . -Force   # from a FRESH download
cd windows_installer-zonder-licentie
Unblock-File -Path .\update.ps1
.\update.ps1
```

### Uninstall

Double-click the "LLM-Botnet Detectie - Verwijderen" shortcut on your
desktop, or:

```powershell
cd "$env:LOCALAPPDATA\llm-botnet-detect"
Unblock-File -Path .\uninstall.ps1
.\uninstall.ps1                # keeps your keys and scan history
.\uninstall.ps1 -PurgeAll      # removes everything, no way back
```

### Full copy-paste block (download → install, in one go)

```powershell
cd $env:USERPROFILE\Downloads
Expand-Archive -Path llm-botnet-detect-installer-windows-zonder-licentie.zip -DestinationPath . -Force
cd windows_installer-zonder-licentie
Unblock-File -Path .\install.ps1, .\uninstall.ps1, .\update.ps1
.\install.ps1
```

---

## Lost track of where the files are?

**Linux** — find the extracted install folder anywhere under your home directory:

```bash
find ~ -maxdepth 4 -iname "install.sh" -path "*llm-botnet*" 2>/dev/null
```

**Linux** — find the actual installed program (after a successful install):

```bash
ls -la /opt/llm-botnet-detect
```

**Windows** — find the extracted install folder anywhere under Downloads:

```powershell
Get-ChildItem -Path "$env:USERPROFILE\Downloads" -Filter "install.ps1" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName
```

**Windows** — find the actual installed program (after a successful install):

```powershell
explorer "$env:LOCALAPPDATA\llm-botnet-detect"
```

---
---

## Nederlandse versie

Een vijflaags gedragsdetectiesysteem tegen gedistribueerde, C2-loze
LLM-botnets — bestand-/proces-/netwerkscanning, netflow-gossip-patroon-
detectie, realtime kernelmonitoring, GPU-fingerprinting, en
cryptografische modelattestatie (TPM-achtig), samengebracht door een
correlatie-engine tot één dashboard.

Dit bestand behandelt **zowel Linux als Windows**. Spring naar de
sectie voor jouw platform hieronder.

### Inhoud

- [Linux — Snelle referentie](#linux--snelle-referentie)
- [Windows — Snelle referentie](#windows--snelle-referentie)
- [Weet je niet meer waar de bestanden staan?](#weet-je-niet-meer-waar-de-bestanden-staan)

---

## Linux — Snelle referentie

### Aanbevolen: één commando, met keuzemenu

Al gedownload en ergens uitgepakt (het maakt niet uit waar)? Open een terminal (Ctrl+Alt+T) en plak dit — vindt het pakket zelf op je systeem en toont een menu (installeren / bijwerken / verse installatie / verwijderen / diagnose / interface herstellen):

```bash
bash -c 'F=$(find ~ -iname "menu.sh" -path "*llm-botnet*" -not -path "*/oud-verzameld/*" -not -path "*/.local/share/Trash/*" -not -path "*/.Trash*" -not -path "*/\$RECYCLE.BIN/*" -printf "%T@ %p\n" 2>/dev/null | sort -rn | head -1 | cut -d" " -f2-); if [ -z "$F" ]; then echo "Pakket niet gevonden — pak eerst llm-botnet-detect-installer-linux-zonder-licentie.tar.gz uit (bijv. in ~/Downloads)."; else bash "$F"; fi'
```

Volg daarna gewoon de vragen op het scherm — die leiden je door de rest heen. Kies je voor **installeren** of **verse installatie**, dan vraagt het menu ook of je alleen de **Wachter-tier** wilt (uitgeklede installatie, alleen Laag 2) — hetzelfde commando hierboven werkt dus voor beide scenario's, geen apart commando nodig.

### Handmatig, stap voor stap

### Vereisten
Ubuntu 22.04/24.04 (of vergelijkbaar), Python 3.10+, sudo-toegang.

### Installeren

```bash
cd ~/Downloads
tar -xzf llm-botnet-detect-installer-linux-zonder-licentie.tar.gz
cd llm-botnet-detect-installer-zonder-licentie
chmod +x install.sh uninstall.sh update.sh
./install.sh
```

`chmod +x` is eenmalig nodig per verse download — Linux blokkeert het
uitvoeren van een bestand totdat je die toestemming expliciet geeft.
Zonder deze stap zie je "Permission denied", geen kapot pakket.

### Bijwerken (behoudt je sleutels en scangeschiedenis)

```bash
cd ~/Downloads
tar -xzf llm-botnet-detect-installer-linux-zonder-licentie.tar.gz    # van een VERSE download
cd llm-botnet-detect-installer-zonder-licentie
chmod +x update.sh
./update.sh
```

### Verwijderen

```bash
cd ~/llm-botnet-detect-installer-zonder-licentie
./uninstall.sh                 # behoudt je sleutels en scangeschiedenis
./uninstall.sh --purge-all     # verwijdert alles, geen weg terug
```

### Volledig kopieerblok (downloaden → installeren, in één keer)

```bash
cd ~/Downloads && \
tar -xzf llm-botnet-detect-installer-linux-zonder-licentie.tar.gz && \
cd llm-botnet-detect-installer-zonder-licentie && \
chmod +x install.sh uninstall.sh update.sh && \
./install.sh
```

---

## Windows — Snelle referentie

### Aanbevolen: één commando, met keuzemenu

Al gedownload en ergens uitgepakt (het maakt niet uit waar)? Open PowerShell en plak dit — vindt het pakket zelf op je systeem en toont een menu:

```powershell
$F = Get-ChildItem -Path $env:USERPROFILE -Filter "menu.ps1" -Recurse -ErrorAction SilentlyContinue | Where-Object { $_.DirectoryName -like "*windows_installer*" } | Select-Object -First 1 -ExpandProperty FullName
if (-not $F) { Write-Host "Pakket niet gevonden — pak eerst llm-botnet-detect-installer-windows-zonder-licentie.zip uit (bijv. in Downloads)." } else { Unblock-File -Path $F; & $F }
```

Volg daarna gewoon de vragen op het scherm. Kies je voor **installeren** of **verse installatie**, dan vraagt het menu ook of je alleen de **Wachter-tier** wilt (uitgeklede installatie, alleen Laag 2) — hetzelfde commando hierboven werkt dus voor beide scenario's, geen apart commando nodig.

### Handmatig, stap voor stap

### Vereisten
Windows 10/11, Python 3.10+ (met `python` in PATH), PowerShell.

### Installeren

```powershell
cd $env:USERPROFILE\Downloads
Expand-Archive -Path llm-botnet-detect-installer-windows-zonder-licentie.zip -DestinationPath . -Force
cd windows_installer-zonder-licentie
Unblock-File -Path .\install.ps1, .\uninstall.ps1, .\update.ps1
.\install.ps1
```

`Unblock-File` is eenmalig nodig per verse download — Windows markeert
elk bestand dat van internet is gedownload, wat scriptuitvoering
stilzwijgend blokkeert, zelfs met het juiste uitvoeringsbeleid. Weigert
PowerShell daarna nog steeds, draai dan eenmalig (per PowerShell-sessie,
niet permanent):

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

### Bijwerken (behoudt je sleutels en scangeschiedenis)

```powershell
cd $env:USERPROFILE\Downloads
Expand-Archive -Path llm-botnet-detect-installer-windows-zonder-licentie.zip -DestinationPath . -Force   # van een VERSE download
cd windows_installer-zonder-licentie
Unblock-File -Path .\update.ps1
.\update.ps1
```

### Verwijderen

Dubbelklik de snelkoppeling "LLM-Botnet Detectie - Verwijderen" op je
bureaublad, of:

```powershell
cd "$env:LOCALAPPDATA\llm-botnet-detect"
Unblock-File -Path .\uninstall.ps1
.\uninstall.ps1                # behoudt je sleutels en scangeschiedenis
.\uninstall.ps1 -PurgeAll      # verwijdert alles, geen weg terug
```

### Volledig kopieerblok (downloaden → installeren, in één keer)

```powershell
cd $env:USERPROFILE\Downloads
Expand-Archive -Path llm-botnet-detect-installer-windows-zonder-licentie.zip -DestinationPath . -Force
cd windows_installer-zonder-licentie
Unblock-File -Path .\install.ps1, .\uninstall.ps1, .\update.ps1
.\install.ps1
```

---

## Weet je niet meer waar de bestanden staan?

**Linux** — vind de uitgepakte installatiemap overal onder je thuismap:

```bash
find ~ -maxdepth 4 -iname "install.sh" -path "*llm-botnet*" 2>/dev/null
```

**Linux** — vind het daadwerkelijk geïnstalleerde programma (na een geslaagde installatie):

```bash
ls -la /opt/llm-botnet-detect
```

**Windows** — vind de uitgepakte installatiemap overal onder Downloads:

```powershell
Get-ChildItem -Path "$env:USERPROFILE\Downloads" -Filter "install.ps1" -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty FullName
```

**Windows** — vind het daadwerkelijk geïnstalleerde programma (na een geslaagde installatie):

```powershell
explorer "$env:LOCALAPPDATA\llm-botnet-detect"
```
