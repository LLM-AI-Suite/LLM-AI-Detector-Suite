﻿# ==============================================================
# update.ps1 - LLM-Botnet Detection System (Windows)
# ==============================================================
# Updates an existing installation with the files from THIS package
# (the package this script itself is in) - no reinstall, your keys
# and scan history are left untouched.
#
# Unlike Linux, Windows can lock files that are in use by a running
# process, so the GUI must be closed manually first (this script
# checks and warns if port 5000 still appears to be in use).
#
# NOTE: this script has NOT been executed on a real Windows machine
# (same limitation as install.ps1/uninstall.ps1). Written carefully
# to mirror their proven structure and encoding safety. Test on a
# non-critical machine first.
#
# Usage:
#   .\update.ps1
# ==============================================================

try {
    $DetectedLang = (Get-Culture).TwoLetterISOLanguageName
} catch {
    $DetectedLang = "en"
}
if ($DetectedLang -eq "nl") {
    $UiLang = "nl"
} else {
    $UiLang = "en"
}

$T_NL = @{
    title = "LLM-Botnet Detectiesysteem - Bijwerken"
    err_no_install_1 = "bestaat niet - geen bestaande installatie gevonden."
    err_no_install_2 = "Gebruik install.ps1 voor een eerste installatie."
    unknown = "onbekend"
    current_version = "Huidige versie:"
    new_version = "Nieuwe versie:  "
    warn_same_version = "Deze versie lijkt al geinstalleerd te zijn (beide:"
    continue_prompt = "Toch doorgaan met bijwerken? (j/n)"
    aborted = "Afgebroken - niets gewijzigd."

    step1 = "Stap 1/4 - Controleren of de GUI draait"
    warn_port_1 = "Poort 5000 lijkt in gebruik - de GUI draait waarschijnlijk nog."
    warn_port_2 = "Sluit dat PowerShell-venster nu, druk daarna hier op Enter om door te gaan."
    press_enter = "Druk op Enter zodra het GUI-venster gesloten is"
    ok_port_free = "Poort 5000 is vrij - veilig om door te gaan"

    step2 = "Stap 2/4 - Programmabestanden bijwerken"
    ok_files = "Python-bestanden en GUI-template bijgewerkt"
    ok_docs = "Documentatiemap bijgewerkt"
    err_update_1 = "Kon de bestanden niet volledig bijwerken - ze zijn mogelijk nog in gebruik."
    err_update_2 = "Zorg dat het GUI-venster volledig gesloten is, en draai dit script opnieuw."
    err_update_3 = "Foutmelding:"

    step3 = "Stap 3/4 - HTTPS-certificaat"
    cert_exists_1 = "Er bestaat al een HTTPS-certificaat van een eerdere installatie/update."
    cert_exists_2 = "Behouden = geen nieuwe browserwaarschuwing. Vernieuwen = nieuw certificaat, je browser"
    cert_exists_3 = "vraagt dan opnieuw om de waarschuwing te accepteren (bijv. zinvol als het"
    cert_exists_4 = "IP-adres van deze machine is veranderd sinds het certificaat werd gemaakt)."
    cert_prompt = "Certificaat behouden of vernieuwen? [b/v, leeg = behouden]"
    cert_renew_char = "v"
    ok_cert_renew = "Certificaat wordt bij de volgende start automatisch opnieuw gegenereerd"
    ok_cert_keep = "Bestaand certificaat behouden - geen nieuwe browserwaarschuwing"
    ok_cert_none = "Nog geen certificaat aanwezig - wordt automatisch gegenereerd bij de eerste start"

    step4 = "Stap 4/4 - Klaar"
    done_title = "Bijwerken voltooid:"
    unchanged = "Je sleutels, scangeschiedenis en instellingen zijn ongewijzigd gebleven."
    restart_note = "Start de GUI opnieuw via de bureaubladsnelkoppeling om de update te activeren."
}

$T_EN = @{
    title = "LLM-Botnet Detection System - Updater"
    err_no_install_1 = "does not exist - no existing installation found."
    err_no_install_2 = "Use install.ps1 for a first installation."
    unknown = "unknown"
    current_version = "Current version:"
    new_version = "New version:    "
    warn_same_version = "This version appears to already be installed (both:"
    continue_prompt = "Update anyway? (y/n)"
    aborted = "Aborted - nothing changed."

    step1 = "Step 1/4 - Checking whether the GUI is running"
    warn_port_1 = "Port 5000 appears to be in use - the GUI is probably still running."
    warn_port_2 = "Close that PowerShell window now, then press Enter here to continue."
    press_enter = "Press Enter once the GUI window is closed"
    ok_port_free = "Port 5000 is free - safe to proceed"

    step2 = "Step 2/4 - Updating program files"
    ok_files = "Python files and GUI template updated"
    ok_docs = "Documentation folder updated"
    err_update_1 = "Could not fully update the files - they may still be in use."
    err_update_2 = "Make sure the GUI window is fully closed, then run this script again."
    err_update_3 = "Error:"

    step3 = "Step 3/4 - HTTPS certificate"
    cert_exists_1 = "An HTTPS certificate from an earlier installation/update already exists."
    cert_exists_2 = "Keep = no new browser warning. Regenerate = new certificate, your browser"
    cert_exists_3 = "will ask you to accept the warning again (e.g. useful if this machine's"
    cert_exists_4 = "IP address has changed since the certificate was created)."
    cert_prompt = "Keep or regenerate the certificate? [k/r, blank = keep]"
    cert_renew_char = "r"
    ok_cert_renew = "Certificate will be regenerated automatically on next start"
    ok_cert_keep = "Existing certificate kept - no new browser warning"
    ok_cert_none = "No certificate present yet - will be generated automatically on first start"

    step4 = "Step 4/4 - Done"
    done_title = "Update complete:"
    unchanged = "Your keys, scan history, and settings were left untouched."
    restart_note = "Start the GUI again via the desktop shortcut to activate the update."
}

function T($key) {
    if ($UiLang -eq "nl") { return $T_NL[$key] } else { return $T_EN[$key] }
}

$InstallDir = "$env:LOCALAPPDATA\llm-botnet-detect"
$ScriptDir = $PSScriptRoot

function Step($msg) { Write-Host "`n==> $msg" -ForegroundColor Green }
function Ok($msg) { Write-Host "[OK] $msg" -ForegroundColor Green }
function WarnMsg($msg) { Write-Host "[WARN] $msg" -ForegroundColor Yellow }
function ErrorMsg($msg) { Write-Host "[FAIL] $msg" -ForegroundColor Red }

Write-Host (T "title") -ForegroundColor Green
Write-Host "=================================================="

if (-not (Test-Path $InstallDir)) {
    ErrorMsg "$InstallDir $(T 'err_no_install_1')"
    ErrorMsg (T "err_no_install_2")
    exit 1
}

$OldVersionPath = Join-Path $InstallDir "VERSION"
$NewVersionPath = Join-Path $ScriptDir "VERSION"
$OldVersion = T "unknown"
if (Test-Path $OldVersionPath) { $OldVersion = (Get-Content $OldVersionPath -Raw).Trim() }
$NewVersion = T "unknown"
if (Test-Path $NewVersionPath) { $NewVersion = (Get-Content $NewVersionPath -Raw).Trim() }

Write-Host "$(T 'current_version') $OldVersion"
Write-Host "$(T 'new_version') $NewVersion"

if ($OldVersion -eq $NewVersion) {
    WarnMsg "$(T 'warn_same_version') $NewVersion)."
    $Confirm = Read-Host (T "continue_prompt")
    if ($Confirm -ne "y" -and $Confirm -ne "j") {
        Write-Host (T "aborted")
        exit 0
    }
}

# ==============================================================
# 1. Check whether the GUI appears to be running
# ==============================================================
Step (T "step1")

$PortInUse = $false
try {
    $Connections = Get-NetTCPConnection -LocalPort 5000 -State Listen -ErrorAction SilentlyContinue
    if ($Connections) { $PortInUse = $true }
} catch {
    # Get-NetTCPConnection not available on older systems - skip check
}

if ($PortInUse) {
    WarnMsg (T "warn_port_1")
    WarnMsg (T "warn_port_2")
    Read-Host (T "press_enter")
} else {
    Ok (T "ok_port_free")
}

# ==============================================================
# 2. Update program files
# ==============================================================
Step (T "step2")

try {
    Copy-Item "$ScriptDir\*.py" -Destination $InstallDir -Force -ErrorAction Stop
    Copy-Item "$ScriptDir\templates\index.html" -Destination "$InstallDir\templates\" -Force -ErrorAction Stop
    Ok (T "ok_files")

    $DocSourceDir = Join-Path $ScriptDir "documentatie"
    if (Test-Path $DocSourceDir) {
        $DocDestDir = Join-Path $InstallDir "documentatie"
        New-Item -ItemType Directory -Force -Path $DocDestDir | Out-Null
        Copy-Item "$DocSourceDir\*" -Destination $DocDestDir -Recurse -Force -ErrorAction Stop
        Ok (T "ok_docs")
    }

    if (Test-Path $NewVersionPath) {
        Copy-Item $NewVersionPath -Destination $OldVersionPath -Force -ErrorAction Stop
    }
} catch {
    ErrorMsg (T "err_update_1")
    ErrorMsg (T "err_update_2")
    ErrorMsg "$(T 'err_update_3') $($_.Exception.Message)"
    exit 1
}

# ==============================================================
# 3. HTTPS certificate: keep or regenerate?
# ==============================================================
Step (T "step3")

$CertDir = "$env:USERPROFILE\.config\llm-detect\tls"
$CertPath = Join-Path $CertDir "cert.pem"
$KeyPath = Join-Path $CertDir "key.pem"

if (Test-Path $CertPath) {
    Write-Host (T "cert_exists_1")
    Write-Host (T "cert_exists_2")
    Write-Host (T "cert_exists_3")
    Write-Host (T "cert_exists_4")
    $CertChoice = Read-Host (T "cert_prompt")
    $RenewChar = T "cert_renew_char"
    if ($CertChoice -eq $RenewChar) {
        Remove-Item $CertPath -Force -ErrorAction SilentlyContinue
        Remove-Item $KeyPath -Force -ErrorAction SilentlyContinue
        Ok (T "ok_cert_renew")
    } else {
        Ok (T "ok_cert_keep")
    }
} else {
    Ok (T "ok_cert_none")
}

# ==============================================================
# 4. Done
# ==============================================================
Step (T "step4")

Write-Host ""
Write-Host "==================================================" -ForegroundColor Green
Write-Host "$(T 'done_title') $OldVersion -> $NewVersion" -ForegroundColor Green
Write-Host "==================================================" -ForegroundColor Green
Write-Host ""
Write-Host (T "unchanged")
Write-Host (T "restart_note")
