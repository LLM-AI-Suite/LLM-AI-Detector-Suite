#!/usr/bin/env python3
"""
llm_botnet_scanner.py
======================
Detectietool voor ongeautoriseerde/gedistribueerde LLM-inferentie op Ubuntu-endpoints.

Drie subcommando's:
  files       -> scan bestandssysteem op GGUF/SafeTensors-signaturen en verdachte entropie
  processes   -> scan /proc op ML-runtime-fingerprints (mmap-omvang, RSS-spikes, gel. bibliotheken)
  network     -> scan /proc/net op verdachte poorten + koppel aan proces
  all         -> voert alle drie uit en correleert de resultaten

Alleen Python-stdlib, geen dependencies. Werkt zonder root voor 'files' en 'network'
(beperkt); 'processes' werkt volledig zonder root voor eigen processen, en met root
voor alle processen op het systeem.

Gebruik:
  python3 llm_botnet_scanner.py all --path /home --json report.json
  python3 llm_botnet_scanner.py files --path /home --min-size 50
  sudo python3 llm_botnet_scanner.py processes
  python3 llm_botnet_scanner.py network
"""

import argparse
import json
import math
import os
import re
import socket
import struct
import sys
import time
from pathlib import Path

# ──────────────────────────────────────────────────────────────
# Constanten / signaturen
# ──────────────────────────────────────────────────────────────

GGUF_MAGIC = b"GGUF"                     # llama.cpp / Ollama modelbestanden

# Bekende, legitieme systeembestanden die vals-positief kunnen scoren op
# entropie (dicht/binair, net als gekwantiseerde modelgewichten) — een
# generieke extensie-uitsluiting zou ook echte .bin-modelbestanden missen,
# dus dit is bewust een gerichte padlijst, consistent met dezelfde
# uitsluiting in realtime_kernel_agent.py (Laag 3). Gevonden in de praktijk:
# APT's pakketcache werd zo als 'onbevoegd model' herkend en (via Laag 3)
# automatisch ingetrokken.
KNOWN_NON_MODEL_SYSTEM_FILES = {
    "/var/cache/apt/pkgcache.bin",
    "/var/cache/apt/srcpkgcache.bin",
}
SAFETENSORS_MIN_HEADER = 8               # SafeTensors: 8-byte little-endian header length

SUSPECT_PORTS = {
    8080: "llama.cpp server (default)",
    11434: "Ollama API (default)",
    8000: "vLLM / generic ML server (default)",
    8888: "Jupyter / generic ML server",
    5000: "generic inference API (Flask default)",
    7860: "Gradio / text-generation-webui (default)",
}

ML_LIB_PATTERNS = [
    re.compile(r"libcuda\.so"),
    re.compile(r"libcublas"),
    re.compile(r"libcudnn"),
    re.compile(r"libtorch"),
    re.compile(r"libggml"),
    re.compile(r"libllama"),
    re.compile(r"libnvidia-ml"),
    re.compile(r"libtensorflow"),
    re.compile(r"libonnxruntime"),
]

# empirisch bereik voor kwantiseerde LLM-gewichtsbestanden (k-quant/GGUF), bits/byte
ENTROPY_SUSPECT_LOW = 7.15
ENTROPY_SUSPECT_HIGH = 7.85
ENTROPY_STDDEV_MAX = 0.35   # lage variantie tussen blokken = uniforme kwantisatiestructuur

BLOCK_SIZE = 4096
SAMPLE_BLOCKS = 64          # hoeveel blokken we per bestand samplen (verspreid over het bestand)

RSS_SPIKE_THRESHOLD_KB = 3 * 1024 * 1024      # 3 GB
ANON_MMAP_THRESHOLD_KB = 2 * 1024 * 1024      # 2 GB


# ──────────────────────────────────────────────────────────────
# Hulpfuncties: entropie
# ──────────────────────────────────────────────────────────────

def shannon_entropy(data: bytes) -> float:
    """Bereken Shannon-entropie in bits/byte voor een blok data."""
    if not data:
        return 0.0
    freq = [0] * 256
    for b in data:
        freq[b] += 1
    length = len(data)
    entropy = 0.0
    for count in freq:
        if count == 0:
            continue
        p = count / length
        entropy -= p * math.log2(p)
    return entropy


def sample_file_entropy(path: Path, block_size=BLOCK_SIZE, max_blocks=SAMPLE_BLOCKS):
    """
    Sample blokken verspreid door het bestand en bereken entropie per blok.
    Geeft (mean, stddev, n_blocks) terug. Vermijdt volledige bestandsread bij grote files.
    """
    try:
        size = path.stat().st_size
    except OSError:
        return None

    if size == 0:
        return None

    n_blocks = min(max_blocks, max(1, size // block_size))
    step = max(block_size, size // n_blocks)

    entropies = []
    try:
        with open(path, "rb") as f:
            offset = 0
            while offset < size and len(entropies) < n_blocks:
                f.seek(offset)
                chunk = f.read(block_size)
                if chunk:
                    entropies.append(shannon_entropy(chunk))
                offset += step
    except (OSError, PermissionError):
        return None

    if not entropies:
        return None

    mean = sum(entropies) / len(entropies)
    variance = sum((e - mean) ** 2 for e in entropies) / len(entropies)
    stddev = math.sqrt(variance)
    return mean, stddev, len(entropies)


# ──────────────────────────────────────────────────────────────
# Hulpfuncties: magic-byte / structuurdetectie
# ──────────────────────────────────────────────────────────────

def read_head(path: Path, n=64):
    try:
        with open(path, "rb") as f:
            return f.read(n)
    except (OSError, PermissionError):
        return b""


def is_gguf(head: bytes) -> bool:
    return head[:4] == GGUF_MAGIC


def looks_like_safetensors(path: Path, head: bytes) -> bool:
    """
    SafeTensors-formaat: eerste 8 bytes = little-endian uint64 header-lengte,
    gevolgd door een JSON-header die begint met '{' en typisch '"dtype"' bevat.
    LoRA-delta's worden vaak in dit formaat uitgewisseld.
    """
    if len(head) < SAFETENSORS_MIN_HEADER + 1:
        return False
    try:
        header_len = struct.unpack("<Q", head[:8])[0]
    except struct.error:
        return False
    # header-lengte moet redelijk zijn (niet absurd groot, niet 0)
    if header_len == 0 or header_len > 50_000_000:
        return False
    # volgende byte moet een JSON-object-opening zijn
    if head[8:9] != b"{":
        return False
    try:
        with open(path, "rb") as f:
            f.seek(8)
            json_bytes = f.read(min(header_len, 4096))
        return b'"dtype"' in json_bytes or b'"shape"' in json_bytes
    except (OSError, PermissionError):
        return False


def classify_file(path: Path, min_size_mb: int) -> dict | None:
    """Analyseer één bestand; geeft None terug als niets verdacht is."""
    if str(path) in KNOWN_NON_MODEL_SYSTEM_FILES:
        return None

    try:
        stat = path.stat()
    except OSError:
        return None

    size_mb = stat.st_size / (1024 * 1024)
    if size_mb < min_size_mb:
        return None

    head = read_head(path)
    findings = []
    severity = 0

    if is_gguf(head):
        findings.append("GGUF-magic-bytes gedetecteerd (llama.cpp/Ollama modelformaat)")
        severity += 3

    if looks_like_safetensors(path, head):
        findings.append("SafeTensors-headerstructuur gedetecteerd (mogelijk LoRA-delta of modelgewichten)")
        severity += 2

    # Bekende media-/archiefformaten hebben vaak een entropieprofiel dat
    # sterk lijkt op gekwantiseerde modelgewichten (beide zijn "dicht",
    # willekeurig-ogende data) — puur op entropie zonder enig ander signaal
    # is dit een zwak, foutgevoelig kenmerk (bevestigd: Bink-video's (.bik)
    # gaven herhaaldelijk valse meldingen). De GGUF/SafeTensors-checks
    # hierboven blijven wél volledig van kracht, ongeacht extensie — die
    # zijn een sterk, inhoudelijk signaal en blijven dus een vermomd
    # modelbestand met een media-extensie prima detecteren.
    KNOWN_NON_MODEL_EXTENSIONS = {
        ".bik", ".mp4", ".mkv", ".avi", ".mov", ".webm", ".wmv",
        ".zip", ".7z", ".rar", ".iso", ".mp3", ".flac", ".ogg",
    }
    has_strong_signal = is_gguf(head) or looks_like_safetensors(path, head)
    entropy_result = sample_file_entropy(path)
    if entropy_result:
        mean, stddev, n = entropy_result
        entropy_matches = ENTROPY_SUSPECT_LOW <= mean <= ENTROPY_SUSPECT_HIGH and stddev <= ENTROPY_STDDEV_MAX
        skip_as_known_media = (
            entropy_matches and not has_strong_signal
            and path.suffix.lower() in KNOWN_NON_MODEL_EXTENSIONS
        )
        if entropy_matches and not skip_as_known_media:
            findings.append(
                f"Entropieprofiel past bij gekwantiseerd model-bestand "
                f"(mean={mean:.2f} bits/byte, stddev={stddev:.3f}, n={n} blokken)"
            )
            severity += 2
    else:
        mean, stddev = None, None

    # verdacht: groot bestand met "onschuldige" of misleidende extensie maar toch model-signatuur
    # (.part/.tmp/.download/.crdownload zijn bewust uitgesloten — dat is geen
    # vermommingspoging, gewoon een normale downloadconventie; die krijgen
    # hieronder hun eigen, aparte "onvoltooide download"-classificatie)
    incomplete_download_extensions = {".part", ".tmp", ".download", ".crdownload"}
    suspicious_extension = (
        path.suffix.lower() not in {".gguf", ".safetensors", ".bin", ".pt", ".pth", ".onnx", ".ckpt"}
        and path.suffix.lower() not in incomplete_download_extensions
    )
    if (is_gguf(head) or looks_like_safetensors(path, head)) and suspicious_extension:
        findings.append(f"Modelbestand met niet-standaard extensie '{path.suffix or '(geen)'}' — mogelijk vermomd")
        severity += 3

    # Onvoltooide download herkennen: een .part-bestand kan legitiem de
    # GGUF-magic-bytes matchen (de eerste paar KB zijn er al), maar is geen
    # bruikbaar, compleet model — behandel dit als eigen categorie i.p.v.
    # als volwaardige modelvondst.
    incomplete_download = path.suffix.lower() in incomplete_download_extensions
    if incomplete_download and findings:
        findings.append(
            "Bestandsextensie wijst op een ONVOLTOOIDE DOWNLOAD, niet op een compleet, "
            "bruikbaar model — waarschijnlijk irrelevant voor autorisatie."
        )

    if not findings:
        return None

    return {
        "path": str(path),
        "size_mb": round(size_mb, 1),
        "entropy_mean": round(mean, 3) if mean is not None else None,
        "entropy_stddev": round(stddev, 3) if stddev is not None else None,
        "findings": findings,
        "severity": severity,
        "incomplete_download": incomplete_download,
    }


def scan_files(root: Path, min_size_mb: int, follow_symlinks=False):
    results = []
    skipped_dirs = 0
    dirs_scanned = 0
    # Tijdgebaseerde tussentijdse voortgang (niet aantal-mappen-gebaseerd, want
    # mapgroottes lopen te veel uiteen om daar een voorspelbaar interval van
    # te maken) — zonder dit bleef een volledige schijfscan (--path /, ~50s)
    # de hele duur volledig stil, wat in de GUI (en eerder al in de terminal)
    # tot verwarring leidde ("hangt dit?"). scan_files() print zelf niets
    # anders tussentijds; dit is bewust minimaal gehouden om de scan zelf
    # niet onnodig te vertragen.
    last_progress = time.time()
    for dirpath, dirnames, filenames in os.walk(root, followlinks=follow_symlinks):
        # sla veelgebruikte irrelevante mappen over voor snelheid
        dirnames[:] = [d for d in dirnames if d not in {
            ".git", "node_modules", "__pycache__", ".cache", "venv", ".venv"
        }]
        dirs_scanned += 1
        now = time.time()
        if now - last_progress >= 3:
            print(f"  … bezig: {dirs_scanned} mappen doorzocht, {len(results)} verdacht gevonden zover — laatst: {dirpath}", flush=True)
            last_progress = now
        for fname in filenames:
            fpath = Path(dirpath) / fname
            try:
                if fpath.is_symlink() and not follow_symlinks:
                    continue
                result = classify_file(fpath, min_size_mb)
                if result:
                    results.append(result)
            except (PermissionError, OSError):
                skipped_dirs += 1
                continue
    results.sort(key=lambda r: r["severity"], reverse=True)
    return results, skipped_dirs


# ──────────────────────────────────────────────────────────────
# Procesanalyse via /proc
# ──────────────────────────────────────────────────────────────

def read_proc_file(pid: str, name: str) -> str:
    try:
        with open(f"/proc/{pid}/{name}", "r", errors="replace", encoding="utf-8") as f:
            return f.read()
    except (OSError, PermissionError):
        return ""


def read_proc_cmdline(pid: str) -> str:
    try:
        with open(f"/proc/{pid}/cmdline", "rb") as f:
            raw = f.read()
        return raw.replace(b"\x00", b" ").decode(errors="replace").strip()
    except (OSError, PermissionError):
        return ""


def get_process_rss_kb(pid: str) -> int:
    status = read_proc_file(pid, "status")
    for line in status.splitlines():
        if line.startswith("VmRSS:"):
            parts = line.split()
            if len(parts) >= 2:
                return int(parts[1])
    return 0


def get_anon_mmap_total_kb(pid: str) -> int:
    """Som van anonieme (niet-bestandsgebonden) memory mappings groter dan een paar MB."""
    smaps_rollup = read_proc_file(pid, "smaps_rollup")
    if smaps_rollup:
        for line in smaps_rollup.splitlines():
            if line.startswith("Rss:"):
                parts = line.split()
                if len(parts) >= 2:
                    return int(parts[1])
        return 0

    # fallback: /proc/[pid]/maps tellen (minder precies, geen Rss-info)
    maps = read_proc_file(pid, "maps")
    total_kb = 0
    for line in maps.splitlines():
        cols = line.split()
        if len(cols) < 5:
            continue
        pathname = cols[-1] if len(cols) >= 6 else ""
        if pathname in ("", "[anon]") or pathname.startswith("[heap]"):
            addr_range = cols[0]
            start, end = addr_range.split("-")
            size_kb = (int(end, 16) - int(start, 16)) // 1024
            total_kb += size_kb
    return total_kb


def get_loaded_ml_libs(pid: str) -> list:
    maps = read_proc_file(pid, "maps")
    found = set()
    for line in maps.splitlines():
        for pattern in ML_LIB_PATTERNS:
            if pattern.search(line):
                found.add(pattern.pattern)
    return sorted(found)


def scan_processes():
    results = []
    no_access = 0
    for pid_dir in os.listdir("/proc"):
        if not pid_dir.isdigit():
            continue
        pid = pid_dir

        cmdline = read_proc_cmdline(pid)
        if not cmdline:
            no_access += 1
            continue

        rss_kb = get_process_rss_kb(pid)
        anon_kb = get_anon_mmap_total_kb(pid)
        ml_libs = get_loaded_ml_libs(pid)

        findings = []
        severity = 0

        if rss_kb >= RSS_SPIKE_THRESHOLD_KB:
            findings.append(
                f"Groot resident geheugengebruik: {rss_kb / (1024*1024):.1f} GB "
                f"(past bij geladen LLM-gewichten)"
            )
            severity += 2

        if anon_kb >= ANON_MMAP_THRESHOLD_KB:
            findings.append(
                f"Grote anonieme/RSS memory-mapping: {anon_kb / (1024*1024):.1f} GB"
            )
            severity += 2

        if ml_libs:
            findings.append(f"ML/GPU-bibliotheken geladen: {', '.join(ml_libs)}")
            severity += 3

        # extra verdacht: ML-libs geladen maar procesnaam claimt iets onschuldigs
        innocuous_names = {"svchost", "systemd", "cron", "bash", "sh", "explorer", "init"}
        proc_name = cmdline.split()[0].split("/")[-1].lower() if cmdline else ""
        if ml_libs and any(proc_name.startswith(n) for n in innocuous_names):
            findings.append(
                f"Proces '{proc_name}' claimt systeemtaak te zijn maar laadt ML-bibliotheken — sterk verdacht"
            )
            severity += 5

        if findings:
            results.append({
                "pid": pid,
                "cmdline": cmdline[:200],
                "rss_gb": round(rss_kb / (1024 * 1024), 2),
                "anon_mmap_gb": round(anon_kb / (1024 * 1024), 2),
                "ml_libs": ml_libs,
                "findings": findings,
                "severity": severity,
            })

    results.sort(key=lambda r: r["severity"], reverse=True)
    return results, no_access


# ──────────────────────────────────────────────────────────────
# Netwerkanalyse via /proc/net + inode->pid koppeling
# ──────────────────────────────────────────────────────────────

def build_inode_to_pid_map():
    inode_map = {}
    for pid_dir in os.listdir("/proc"):
        if not pid_dir.isdigit():
            continue
        fd_path = f"/proc/{pid_dir}/fd"
        try:
            for fd in os.listdir(fd_path):
                try:
                    target = os.readlink(f"{fd_path}/{fd}")
                except OSError:
                    continue
                m = re.match(r"socket:\[(\d+)\]", target)
                if m:
                    inode_map[m.group(1)] = pid_dir
        except (PermissionError, OSError):
            continue
    return inode_map


def parse_proc_net_tcp(path: str):
    """Parseer /proc/net/tcp of /proc/net/tcp6, geeft lijst van (local_port, state, inode) terug."""
    entries = []
    try:
        with open(path, "r", encoding="utf-8") as f:
            lines = f.readlines()[1:]
    except (OSError, PermissionError):
        return entries

    for line in lines:
        cols = line.split()
        if len(cols) < 10:
            continue
        local_addr = cols[1]
        state = cols[3]
        inode = cols[9]
        try:
            port_hex = local_addr.split(":")[1]
            port = int(port_hex, 16)
        except (IndexError, ValueError):
            continue
        entries.append((port, state, inode))
    return entries


TCP_STATE_LISTEN = "0A"


def scan_network():
    inode_map = build_inode_to_pid_map()
    findings = []

    for proc_net_path in ("/proc/net/tcp", "/proc/net/tcp6"):
        for port, state, inode in parse_proc_net_tcp(proc_net_path):
            if port not in SUSPECT_PORTS:
                continue
            pid = inode_map.get(inode, "onbekend")
            cmdline = read_proc_cmdline(pid) if pid != "onbekend" else ""
            is_listening = state == TCP_STATE_LISTEN

            findings.append({
                "port": port,
                "service_guess": SUSPECT_PORTS[port],
                "state": "LISTEN" if is_listening else state,
                "pid": pid,
                "cmdline": cmdline[:200],
                "severity": 3 if is_listening else 1,
            })

    findings.sort(key=lambda f: f["severity"], reverse=True)
    return findings


# ──────────────────────────────────────────────────────────────
# Correlatie
# ──────────────────────────────────────────────────────────────

def correlate(file_results, process_results, network_results):
    """
    Eenvoudige correlatiescore: als een PID zowel als 'process'-hit als
    'network'-hit voorkomt, verhoog confidence sterk. Bestandshits met hoge
    severity die niet aan een lopend proces gekoppeld zijn (bijv. offline
    modelbestand op disk) blijven apart gerapporteerd.
    """
    net_pids = {f["pid"] for f in network_results if f["pid"] != "onbekend"}
    correlated = []

    for proc in process_results:
        combined_severity = proc["severity"]
        reasons = list(proc["findings"])
        if proc["pid"] in net_pids:
            net_hits = [f for f in network_results if f["pid"] == proc["pid"]]
            for hit in net_hits:
                reasons.append(
                    f"Netwerk: luistert op poort {hit['port']} ({hit['service_guess']})"
                )
            combined_severity += 4

        if combined_severity > proc["severity"]:
            correlated.append({
                "pid": proc["pid"],
                "cmdline": proc["cmdline"],
                "combined_severity": combined_severity,
                "reasons": reasons,
            })

    correlated.sort(key=lambda c: c["combined_severity"], reverse=True)
    return correlated


# ──────────────────────────────────────────────────────────────
# Rapportage
# ──────────────────────────────────────────────────────────────

def severity_label(score: int) -> str:
    if score >= 8:
        return "KRITIEK"
    if score >= 4:
        return "HOOG"
    if score >= 2:
        return "MIDDEL"
    return "LAAG"


def print_file_report(results, skipped):
    print(f"\n── Bestandsscan ── ({len(results)} verdachte bestanden, {skipped} onleesbaar/overgeslagen)")
    if not results:
        print("  Geen verdachte modelbestanden aangetroffen.")
        return
    for r in results[:50]:
        print(f"\n  [{severity_label(r['severity'])}] {r['path']}  ({r['size_mb']} MB)")
        for finding in r["findings"]:
            print(f"      • {finding}")


def print_process_report(results, no_access):
    print(f"\n── Processcan ── ({len(results)} verdachte processen, {no_access} niet-toegankelijk)")
    if not results:
        print("  Geen verdachte processen aangetroffen.")
        return
    for r in results[:50]:
        print(f"\n  [{severity_label(r['severity'])}] PID {r['pid']}  {r['cmdline']}")
        for finding in r["findings"]:
            print(f"      • {finding}")


def print_network_report(results):
    print(f"\n── Netwerkscan ── ({len(results)} verdachte listeners/verbindingen)")
    if not results:
        print("  Geen verdachte ML-poorten actief.")
        return
    for r in results:
        print(f"\n  [{severity_label(r['severity'])}] poort {r['port']} — {r['service_guess']}")
        print(f"      status: {r['state']}, pid: {r['pid']}, cmdline: {r['cmdline']}")


def print_correlation_report(correlated):
    print(f"\n── Correlatie (proces + netwerk) ── ({len(correlated)} hoge-confidence hits)")
    if not correlated:
        print("  Geen gecorreleerde bevindingen.")
        return
    for c in correlated:
        print(f"\n  [{severity_label(c['combined_severity'])}] PID {c['pid']}  {c['cmdline']}")
        for reason in c["reasons"]:
            print(f"      • {reason}")


# ──────────────────────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Detectietool voor ongeautoriseerde/gedistribueerde LLM-inferentie (Ubuntu)."
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_files = sub.add_parser("files", help="Scan bestandssysteem op model-signaturen")
    p_files.add_argument("--path", default="/", help="Startpad voor de scan (default: / — de hele schijf, voor betrouwbaarheid; smaller pad kost tijd, niet volledigheid)")
    p_files.add_argument("--min-size", type=int, default=20, help="Minimale bestandsgrootte in MB (default: 20)")

    p_processes = sub.add_parser("processes", help="Scan lopende processen op ML-runtime-fingerprints")
    p_network = sub.add_parser("network", help="Scan netwerkverbindingen op verdachte ML-poorten")

    p_all = sub.add_parser("all", help="Voer alle scans uit en correleer")
    p_all.add_argument("--path", default="/", help="Startpad voor bestandsscan (default: / — de hele schijf, voor betrouwbaarheid; smaller pad kost tijd, niet volledigheid)")
    p_all.add_argument("--min-size", type=int, default=20, help="Minimale bestandsgrootte in MB")

    for p in (p_files, p_processes, p_network, p_all):
        p.add_argument("--json", default=None, help="Schrijf volledig rapport als JSON naar dit pad")

    args = parser.parse_args()
    t0 = time.time()
    report = {"generated_at": time.strftime("%Y-%m-%d %H:%M:%S"), "hostname": socket.gethostname()}

    if args.command == "files":
        results, skipped = scan_files(Path(args.path), args.min_size)
        print_file_report(results, skipped)
        report["files"] = results

    elif args.command == "processes":
        results, no_access = scan_processes()
        print_process_report(results, no_access)
        report["processes"] = results

    elif args.command == "network":
        results = scan_network()
        print_network_report(results)
        report["network"] = results

    elif args.command == "all":
        file_results, skipped = scan_files(Path(args.path), args.min_size)
        print_file_report(file_results, skipped)

        proc_results, no_access = scan_processes()
        print_process_report(proc_results, no_access)

        net_results = scan_network()
        print_network_report(net_results)

        correlated = correlate(file_results, proc_results, net_results)
        print_correlation_report(correlated)

        report["files"] = file_results
        report["processes"] = proc_results
        report["network"] = net_results
        report["correlated"] = correlated

    elapsed = time.time() - t0
    print(f"\n── Scan voltooid in {elapsed:.1f}s ──")

    json_path = getattr(args, "json", None)
    if json_path:
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2)
        try:
            import result_integrity as _ri
            _key_dir = _ri.resolve_key_dir()
            _priv = _ri.get_or_create_signing_key(_key_dir)
            _ri.sign_result_file(json_path, _priv)
        except Exception as _e:
            print(f"[!] Kon resultaat niet ondertekenen ({_e}) — bestand blijft ongesigneerd.")
        print(f"Volledig rapport geschreven naar: {json_path}")

    if os.geteuid() != 0 and args.command in ("processes", "all"):
        print(
            "\n[!] Let op: niet als root gedraaid — alleen processen van de huidige "
            "gebruiker zijn volledig inspecteerbaar. Voor een systeembrede scan: sudo."
        )


if __name__ == "__main__":
    main()
