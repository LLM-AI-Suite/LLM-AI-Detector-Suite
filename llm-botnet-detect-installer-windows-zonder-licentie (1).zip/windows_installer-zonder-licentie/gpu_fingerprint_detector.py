#!/usr/bin/env python3
"""
gpu_fingerprint_detector.py
==============================
Laag 4: GPU-computationele fingerprinting — onderscheidt LLM-inferentie van
gaming, rendering en idle-gebruik op basis van drie signalen die geen
content-inspectie vereisen (zie onderzoeksrapport, sectie "Hardware/Compute"):

  1. Memory-bandwidth-bound ratio  -> LLM-inferentie bij lage batchgrootte is
                                       memory-bandwidth-bound: gematigd compute-
                                       gebruik (40-70%) maar hoge geheugenbandbreedte-
                                       utilization. Gaming is bij benadering 1:1.
  2. Burst-ritme                    -> autoregressive token-decodering geeft een
                                       herkenbaar puls-patroon: korte GPU-burst per
                                       token (~20-50ms) gevolgd door een gat van
                                       ~100-500ms. Gedetecteerd via autocorrelatie
                                       op de utilization-tijdreeks.
  3. Sustained VRAM-allocatie       -> een stabiele, hoge VRAM-allocatie (4-40GB)
                                       met lage variantie past bij geladen model-
                                       gewichten; gaming/rendering-VRAM fluctueert
                                       veel sterker (textures/framebuffers wisselen).

Databronnen (in volgorde van voorkeur):
  - pynvml   (NVIDIA Management Library, python-bindings) — laagste overhead
  - nvidia-smi CLI via subprocess — overal beschikbaar waar de driver draait
  - DCGM (dcgmi) — voor tensor-core-specifieke profiling metrics (DCGM_FI_PROF_*),
    niet geïmplementeerd hier maar aanbevolen als productie-upgrade; geeft direct
    tensor-core-activatie los van algemene SM-utilization.

BELANGRIJKE KANTTEKENING:
  Deze ontwikkelomgeving heeft geen GPU en geen nvidia-smi/pynvml. De databron-
  functies (read_via_pynvml, read_via_nvidia_smi) zijn daarom geschreven volgens
  de officiële CLI/API-documentatie maar hier ongetest tegen echte hardware.
  De detectielogica zelf (drie signalen hierboven) is wel getest, tegen een
  synthetische telemetriegenerator die drie realistische scenario's simuleert:
  gaming, LLM-inferentie en idle. Zie --generate-synthetic.

Gebruik:
  python3 gpu_fingerprint_detector.py --live --duration 60          # echte GPU
  python3 gpu_fingerprint_detector.py --generate-synthetic llm_inference > samples.json
  python3 gpu_fingerprint_detector.py --input samples.json
"""

import argparse
import json
import os
import random
import statistics
import subprocess
import sys
import time

try:
    import numpy as np
    HAVE_NUMPY = True
except ImportError:
    HAVE_NUMPY = False


# ──────────────────────────────────────────────────────────────
# Drempelwaarden (zie rapport, sectie "Hardware/Compute")
# ──────────────────────────────────────────────────────────────

MEM_COMPUTE_RATIO_THRESHOLD = 1.4     # mem_bw_util / compute_util
BURST_PERIOD_MIN_MS = 80
BURST_PERIOD_MAX_MS = 600
BURST_AUTOCORR_THRESHOLD = 0.45
BURST_AMPLITUDE_MIN_PCT = 35           # verschil tussen piek en dal in utilization%

VRAM_MODEL_MIN_MB = 3_500              # kleinste kwantiseerde 7B-modellen
VRAM_MODEL_MAX_MB = 45_000             # ruim boven grootste consumer-GPU's
VRAM_STABILITY_CV_MAX = 0.08           # variatiecoëfficiënt — laag = stabiele allocatie
SUSTAINED_WINDOW_SEC = 10              # minimale duur voor "sustained" allocatie


# ──────────────────────────────────────────────────────────────
# Databron 1: pynvml (voorkeur — geen subprocess-overhead)
# ──────────────────────────────────────────────────────────────

def read_via_pynvml(duration_sec: float, interval_sec: float) -> list:
    """
    Verzamel telemetrie via pynvml. Vereist: pip install nvidia-ml-py
    (of het oudere pynvml-package) en een geïnstalleerde NVIDIA-driver.
    """
    import pynvml
    pynvml.nvmlInit()
    handle = pynvml.nvmlDeviceGetHandleByIndex(0)

    samples = []
    start = time.time()
    while time.time() - start < duration_sec:
        util = pynvml.nvmlDeviceGetUtilizationRates(handle)
        mem = pynvml.nvmlDeviceGetMemoryInfo(handle)
        samples.append({
            "ts": time.time(),
            "gpu_util_pct": util.gpu,
            "mem_bw_util_pct": util.memory,   # pynvml: memory-controller utilization%
            "mem_used_mb": mem.used / (1024 * 1024),
            "mem_total_mb": mem.total / (1024 * 1024),
        })
        time.sleep(interval_sec)

    pynvml.nvmlShutdown()
    return samples


# ──────────────────────────────────────────────────────────────
# Databron 2: nvidia-smi CLI (fallback, overal beschikbaar)
# ──────────────────────────────────────────────────────────────

def read_via_nvidia_smi(duration_sec: float, interval_sec: float) -> list:
    """
    Poll nvidia-smi in een Python-lus (in plaats van diens eigen -l loop-modus)
    zodat we exacte controle houden over sampling-timing en direct in-memory
    kunnen verwerken zonder tussentijdse bestand-I/O.
    """
    query = "utilization.gpu,utilization.memory,memory.used,memory.total"
    cmd = ["nvidia-smi", f"--query-gpu={query}", "--format=csv,noheader,nounits"]

    samples = []
    start = time.time()
    while time.time() - start < duration_sec:
        ts = time.time()
        try:
            out = subprocess.run(cmd, capture_output=True, text=True, timeout=2).stdout.strip()
        except (subprocess.SubprocessError, FileNotFoundError):
            break
        parts = [p.strip() for p in out.split(",")]
        if len(parts) == 4:
            gpu_util, mem_util, mem_used, mem_total = (float(p) for p in parts)
            samples.append({
                "ts": ts,
                "gpu_util_pct": gpu_util,
                "mem_bw_util_pct": mem_util,
                "mem_used_mb": mem_used,
                "mem_total_mb": mem_total,
            })
        time.sleep(interval_sec)
    return samples


def collect_live_samples(duration_sec: float, interval_sec: float) -> list:
    try:
        return read_via_pynvml(duration_sec, interval_sec)
    except ImportError:
        pass
    except Exception as e:
        print(f"[!] pynvml faalde ({e}), val terug op nvidia-smi", file=sys.stderr)

    samples = read_via_nvidia_smi(duration_sec, interval_sec)
    if not samples:
        print("[!] Geen GPU-telemetrie beschikbaar — geen NVIDIA-GPU/driver gevonden.", file=sys.stderr)
    return samples


# ──────────────────────────────────────────────────────────────
# Signaal 1: memory-bandwidth-bound ratio
# ──────────────────────────────────────────────────────────────

def analyze_mem_compute_ratio(samples: list) -> dict:
    active = [s for s in samples if s["gpu_util_pct"] > 5]  # negeer idle-periodes
    if len(active) < 3:
        return {"ratio": None, "is_memory_bound": False}

    mean_gpu = statistics.mean(s["gpu_util_pct"] for s in active)
    mean_mem = statistics.mean(s["mem_bw_util_pct"] for s in active)
    if mean_gpu == 0:
        return {"ratio": None, "is_memory_bound": False}

    ratio = mean_mem / mean_gpu
    return {
        "ratio": round(ratio, 3),
        "mean_gpu_util": round(mean_gpu, 1),
        "mean_mem_bw_util": round(mean_mem, 1),
        "is_memory_bound": ratio >= MEM_COMPUTE_RATIO_THRESHOLD,
    }


# ──────────────────────────────────────────────────────────────
# Signaal 2: burst-ritme via autocorrelatie
# ──────────────────────────────────────────────────────────────

def analyze_burst_rhythm(samples: list) -> dict:
    if len(samples) < 10:
        return {"is_burst_pattern": False, "reason": "te weinig samples"}

    ts = [s["ts"] for s in samples]
    util = [s["gpu_util_pct"] for s in samples]

    # sampling-interval schatten uit de tijdstempels (kan onregelmatig zijn bij nvidia-smi-subprocess-jitter)
    intervals = [ts[i + 1] - ts[i] for i in range(len(ts) - 1)]
    dt = statistics.median(intervals)
    if dt <= 0:
        return {"is_burst_pattern": False, "reason": "ongeldige sampling-interval"}

    amplitude = max(util) - min(util)
    if amplitude < BURST_AMPLITUDE_MIN_PCT:
        return {"is_burst_pattern": False, "reason": "te lage amplitude voor burst-detectie", "amplitude": amplitude}

    if not HAVE_NUMPY:
        return {"is_burst_pattern": False, "reason": "numpy niet beschikbaar, autocorrelatie overgeslagen"}

    arr = np.array(util, dtype=float)
    arr = arr - arr.mean()
    autocorr = np.correlate(arr, arr, mode="full")
    mid = len(autocorr) // 2
    autocorr = autocorr[mid:]
    if autocorr[0] == 0:
        return {"is_burst_pattern": False, "reason": "geen variantie in signaal"}
    autocorr = autocorr / autocorr[0]

    min_lag = max(1, int(BURST_PERIOD_MIN_MS / 1000 / dt))
    max_lag = min(len(autocorr) - 1, int(BURST_PERIOD_MAX_MS / 1000 / dt))
    if min_lag >= max_lag:
        return {"is_burst_pattern": False, "reason": "sampling-interval te grof voor dit periodebereik"}

    window = autocorr[min_lag:max_lag + 1]

    # Zoek de EERSTE lokale piek boven de drempel, niet het globale maximum.
    # Bij korte, smalle pulsen (lage duty-cycle) kan een hogere harmonische
    # (bijv. 2x de werkelijke periode) een licht hogere autocorrelatie-waarde
    # geven dan de fundamentele periode zelf — dat gaf hier foutief 440ms i.p.v.
    # de werkelijke 220ms bij een test met een 220ms token-periode. Door vanaf
    # de kortste periode te zoeken naar de eerste piece die de drempel haalt,
    # vinden we de fundamentele periode in plaats van een harmonische.
    peak_idx = None
    peak_value = None
    for offset in range(1, len(window) - 1):
        val = window[offset]
        if val >= BURST_AUTOCORR_THRESHOLD and val >= window[offset - 1] and val >= window[offset + 1]:
            peak_idx = offset + min_lag
            peak_value = float(val)
            break

    if peak_idx is None:
        # geen duidelijke lokale piek gevonden boven de drempel; val terug op het
        # globale maximum in het venster zodat we toch een waarde rapporteren
        peak_idx = int(np.argmax(window)) + min_lag
        peak_value = float(window.max())

    peak_period_ms = peak_idx * dt * 1000

    return {
        "is_burst_pattern": peak_value >= BURST_AUTOCORR_THRESHOLD,
        "peak_autocorrelation": round(peak_value, 3),
        "peak_period_ms": round(peak_period_ms, 1),
        "amplitude_pct": round(amplitude, 1),
        "sampling_dt_ms": round(dt * 1000, 1),
    }


# ──────────────────────────────────────────────────────────────
# Signaal 3: sustained VRAM-allocatie
# ──────────────────────────────────────────────────────────────

def analyze_sustained_vram(samples: list) -> dict:
    if len(samples) < 3:
        return {"is_sustained_model_alloc": False, "reason": "te weinig samples"}

    duration = samples[-1]["ts"] - samples[0]["ts"]
    mem_used = [s["mem_used_mb"] for s in samples]
    mean_mem = statistics.mean(mem_used)
    stddev_mem = statistics.pstdev(mem_used)
    cv = stddev_mem / mean_mem if mean_mem > 0 else 1.0

    in_model_range = VRAM_MODEL_MIN_MB <= mean_mem <= VRAM_MODEL_MAX_MB
    is_stable = cv <= VRAM_STABILITY_CV_MAX
    is_sustained = duration >= SUSTAINED_WINDOW_SEC

    return {
        "mean_vram_mb": round(mean_mem, 1),
        "coefficient_of_variation": round(cv, 4),
        "duration_sec": round(duration, 1),
        "in_model_size_range": in_model_range,
        "is_stable": is_stable,
        "is_sustained_model_alloc": in_model_range and is_stable and is_sustained,
    }


# ──────────────────────────────────────────────────────────────
# Correlatie & rapportage
# ──────────────────────────────────────────────────────────────

def analyze(samples: list) -> dict:
    ratio_result = analyze_mem_compute_ratio(samples)
    burst_result = analyze_burst_rhythm(samples)
    vram_result = analyze_sustained_vram(samples)

    findings = []
    severity = 0

    if ratio_result["is_memory_bound"]:
        findings.append(
            f"Memory-bandwidth-bound profiel: ratio={ratio_result['ratio']} "
            f"(mem_bw={ratio_result['mean_mem_bw_util']}%, compute={ratio_result['mean_gpu_util']}%) "
            f"— past bij LLM-inferentie bij lage batchgrootte"
        )
        severity += 3

    if burst_result.get("is_burst_pattern"):
        findings.append(
            f"Autoregressive burst-ritme: periode~{burst_result['peak_period_ms']}ms "
            f"(autocorr={burst_result['peak_autocorrelation']}, amplitude={burst_result['amplitude_pct']}%) "
            f"— past bij token-voor-token decodering"
        )
        severity += 4

    if vram_result["is_sustained_model_alloc"]:
        findings.append(
            f"Stabiele VRAM-allocatie in modelgrootte-bereik: {vram_result['mean_vram_mb']:.0f} MB "
            f"(CV={vram_result['coefficient_of_variation']}, {vram_result['duration_sec']:.0f}s sustained) "
            f"— past bij geladen modelgewichten"
        )
        severity += 2

    return {
        "n_samples": len(samples),
        "mem_compute_ratio": ratio_result,
        "burst_rhythm": burst_result,
        "sustained_vram": vram_result,
        "findings": findings,
        "severity": severity,
    }


def severity_label(score: int) -> str:
    if score >= 7:
        return "KRITIEK"
    if score >= 4:
        return "HOOG"
    if score >= 2:
        return "MIDDEL"
    return "LAAG"


def print_report(result: dict):
    print(f"\n── GPU-fingerprint analyse ── ({result['n_samples']} samples)")
    if not result["findings"]:
        print(f"  [{severity_label(0)}] Geen LLM-inferentie-signatuur gedetecteerd.")
        return
    print(f"  [{severity_label(result['severity'])}] Score: {result['severity']}")
    for finding in result["findings"]:
        print(f"      • {finding}")


# ──────────────────────────────────────────────────────────────
# Synthetische telemetrie (voor testen zonder GPU-hardware)
# ──────────────────────────────────────────────────────────────

def generate_gaming_samples(duration_sec=20, dt=0.05, seed=1) -> list:
    """Gaming: hoog compute EN hoge mem-bandbreedte, sterk fluctuerend VRAM (textures)."""
    rnd = random.Random(seed)
    samples = []
    t0 = time.time()
    n = int(duration_sec / dt)
    for i in range(n):
        ts = t0 + i * dt
        gpu = 75 + rnd.uniform(-10, 15)
        mem_bw = gpu * rnd.uniform(0.85, 1.05)   # ~1:1 ratio, geen memory-bound signatuur
        vram = 6000 + rnd.uniform(-800, 1500)     # fluctuerend: level-streaming, textures
        samples.append({"ts": ts, "gpu_util_pct": max(0, min(100, gpu)),
                          "mem_bw_util_pct": max(0, min(100, mem_bw)),
                          "mem_used_mb": vram, "mem_total_mb": 12000})
    return samples


def generate_idle_samples(duration_sec=20, dt=0.05, seed=2) -> list:
    """Idle: laag compute, laag mem-bw, laag stabiel VRAM (desktop-compositor)."""
    rnd = random.Random(seed)
    samples = []
    t0 = time.time()
    n = int(duration_sec / dt)
    for i in range(n):
        ts = t0 + i * dt
        gpu = rnd.uniform(0, 4)
        mem_bw = rnd.uniform(0, 3)
        vram = 400 + rnd.uniform(-20, 20)
        samples.append({"ts": ts, "gpu_util_pct": gpu, "mem_bw_util_pct": mem_bw,
                          "mem_used_mb": vram, "mem_total_mb": 12000})
    return samples


def generate_llm_inference_samples(duration_sec=20, dt=0.02, seed=3) -> list:
    """
    LLM-inferentie: autoregressive decodering. Elke ~220ms een korte burst
    (~30ms) van hoge activiteit (token forward-pass), daartussen een gat met
    lage activiteit. Memory-bandwidth-utilization ligt hoger dan compute-
    utilization tijdens de burst (memory-bound bij lage batchgrootte).
    VRAM blijft stabiel hoog (model blijft volledig geladen).
    """
    rnd = random.Random(seed)
    samples = []
    t0 = time.time()
    n = int(duration_sec / dt)
    token_period = 0.22       # 220ms per token — binnen BURST_PERIOD range
    burst_duration = 0.03
    vram_base = 14000          # bijv. een 13B-model in 4-bit kwantisatie

    for i in range(n):
        ts = t0 + i * dt
        phase = (i * dt) % token_period
        in_burst = phase < burst_duration

        if in_burst:
            gpu = 55 + rnd.uniform(-8, 10)          # gematigd compute tijdens burst
            mem_bw = 88 + rnd.uniform(-6, 8)         # hoge bandbreedte-utilization
        else:
            gpu = 3 + rnd.uniform(0, 4)
            mem_bw = 5 + rnd.uniform(0, 5)

        vram = vram_base + rnd.uniform(-50, 50)      # zeer stabiel, model blijft geladen

        samples.append({"ts": ts, "gpu_util_pct": max(0, min(100, gpu)),
                          "mem_bw_util_pct": max(0, min(100, mem_bw)),
                          "mem_used_mb": vram, "mem_total_mb": 24000})
    return samples


SYNTHETIC_GENERATORS = {
    "gaming": generate_gaming_samples,
    "idle": generate_idle_samples,
    "llm_inference": generate_llm_inference_samples,
}


# ──────────────────────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="GPU-computationele fingerprinting voor LLM-inferentie-detectie")
    parser.add_argument("--live", action="store_true", help="Verzamel live telemetrie via pynvml/nvidia-smi")
    parser.add_argument("--duration", type=float, default=20, help="Meetduur in seconden (bij --live of synthetisch)")
    parser.add_argument("--interval", type=float, default=0.1, help="Sampling-interval in seconden (bij --live)")
    parser.add_argument("--input", help="Pad naar JSON-bestand met samples (i.p.v. live meten)")
    parser.add_argument("--generate-synthetic", choices=list(SYNTHETIC_GENERATORS.keys()),
                         help="Genereer synthetische testdata naar stdout")
    parser.add_argument("--seed", type=int, default=None,
                         help="Vaste seed voor --generate-synthetic (default: functie-eigen vaste waarde — "
                              "geef dit expliciet op als je bij herhaalde runs GEEN identieke testdata wilt)")
    parser.add_argument("--json", help="Schrijf volledig analyseresultaat als JSON naar dit pad")
    args = parser.parse_args()

    if args.generate_synthetic:
        seed_kwargs = {"seed": args.seed} if args.seed is not None else {}
        samples = SYNTHETIC_GENERATORS[args.generate_synthetic](duration_sec=args.duration, **seed_kwargs)
        json.dump(samples, sys.stdout, indent=2)
        return

    if args.input:
        with open(args.input, encoding="utf-8") as f:
            samples = json.load(f)
    elif args.live:
        samples = collect_live_samples(args.duration, args.interval)
    else:
        parser.error("Gebruik --live, --input, of --generate-synthetic")
        return

    if not samples:
        print("Geen samples om te analyseren.")
        return

    result = analyze(samples)
    print_report(result)

    if args.json:
        with open(args.json, "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2)
        print(f"\nVolledig rapport geschreven naar: {args.json}")
        try:
            import result_integrity as _ri
            _key_dir = _ri.resolve_key_dir()
            _priv = _ri.get_or_create_signing_key(_key_dir)
            _ri.sign_result_file(args.json, _priv)
        except Exception as _e:
            print(f"[!] Kon resultaat niet ondertekenen ({_e}) — bestand blijft ongesigneerd.")


if __name__ == "__main__":
    main()
