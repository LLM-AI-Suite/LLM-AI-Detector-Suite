#!/usr/bin/env python3
"""
ai_service_monitor.py
========================
Detecteert welke apparaten in het netwerk met welke cloud-AI-diensten praten
(Claude, ChatGPT, Gemini, enz.) — zonder de inhoud van die gesprekken te
kunnen lezen.

Werkingsprincipe: een TLS-verbinding begint met een onversleutelde
'ClientHello'-handshake, die een SNI-extensie (Server Name Indication) bevat
— de hostnaam waarmee verbinding wordt gemaakt. Dit staat letterlijk in
platte tekst in de eerste paar honderd bytes van elke HTTPS-verbinding,
ongeacht hoe versleuteld de rest van het verkeer is. Dit is dus geen
'meekijken', maar het lezen van informatie die sowieso al onversleuteld
over de lijn gaat.

Dit is bewust een APART instrument, los van de vijf botnet-detectielagen:
het beantwoordt een andere vraag ("welke legitieme AI-diensten worden er
gebruikt, door wie") dan de botnet-detectie ("draait er een verborgen,
ongeautoriseerde AI"). Cloud-AI-gebruik via de browser (zoals dit gesprek
met Claude) is voor de botnet-lagen onzichtbaar EN onschadelijk — dit
instrument maakt het juist zichtbaar, als apart controle-instrument.

Twee gebruiksmodi:
  1. Analyseer een bestaand pcap-bestand (--pcap)
  2. Live meeluisteren via tcpdump, dan analyseren (--capture --interface)

Gebruik:
  python3 ai_service_monitor.py --pcap capture.pcap --json rapport.json
  sudo python3 ai_service_monitor.py --capture --interface eth0 --duration 300 --json rapport.json
"""

import argparse
import json
import os
import platform
import socket
import struct
import subprocess
import sys
import tempfile
import time
from collections import defaultdict
from datetime import datetime

# ──────────────────────────────────────────────────────────────
# Bekende AI-dienst-hostnamen
# ──────────────────────────────────────────────────────────────

AI_SERVICE_DOMAINS = {
    "claude.ai": "Anthropic Claude",
    "api.anthropic.com": "Anthropic Claude (API)",
    "claude.com": "Anthropic Claude",
    "chatgpt.com": "OpenAI ChatGPT",
    "chat.openai.com": "OpenAI ChatGPT",
    "api.openai.com": "OpenAI (API)",
    "gemini.google.com": "Google Gemini",
    "generativelanguage.googleapis.com": "Google Gemini (API)",
    "bard.google.com": "Google Gemini (voorheen Bard)",
    "copilot.microsoft.com": "Microsoft Copilot",
    "huggingface.co": "Hugging Face",
    "poe.com": "Poe (Quora)",
    "perplexity.ai": "Perplexity AI",
    "character.ai": "Character.AI",
    "x.ai": "xAI / Grok",
    "grok.com": "xAI / Grok",
    "mistral.ai": "Mistral AI",
    "console.mistral.ai": "Mistral AI (API)",
    "cohere.com": "Cohere",
    "api.cohere.ai": "Cohere (API)",
}


def hostname_matches_ai_service(hostname: str):
    """Exacte match of subdomein-match tegen de bekende dienstenlijst."""
    hostname = hostname.lower().rstrip(".")
    if hostname in AI_SERVICE_DOMAINS:
        return AI_SERVICE_DOMAINS[hostname]
    for domain, name in AI_SERVICE_DOMAINS.items():
        if hostname.endswith("." + domain):
            return name
    return None


# ──────────────────────────────────────────────────────────────
# PCAP-bestandsparser (handmatig, geen externe dependency)
# ──────────────────────────────────────────────────────────────

PCAP_MAGIC_LE = 0xA1B2C3D4
PCAP_MAGIC_LE_NS = 0xA1B23C4D
PCAP_MAGIC_BE = 0xD4C3B2A1


def read_pcap_packets(path: str):
    """
    Leest een klassiek pcap-bestand (niet pcapng) en geeft per pakket
    (timestamp, ruwe_bytes) terug. Ondersteunt zowel little- als big-endian
    bestanden (afhankelijk van de capture-machine).
    """
    if not os.path.isfile(path):
        raise RuntimeError(
            f"Pcap-bestand niet gevonden: {path}\n"
            f"Het ingevulde pad is een VOORBEELD, geen bestaand bestand — vul het pad in naar een "
            f"echte capture (bijv. gemaakt met Wireshark of via 'Live meeluisteren' hierboven)."
        )
    with open(path, "rb") as f:
        header = f.read(24)
        if len(header) < 24:
            raise ValueError("Bestand te kort om een geldige pcap-header te bevatten")

        magic = struct.unpack("<I", header[:4])[0]
        if magic in (PCAP_MAGIC_LE, PCAP_MAGIC_LE_NS):
            endian = "<"
        elif magic == PCAP_MAGIC_BE:
            endian = ">"
        else:
            raise ValueError(f"Onbekend pcap-magic-getal: {hex(magic)} — is dit een pcapng-bestand? Dat wordt niet ondersteund.")

        while True:
            rec_header = f.read(16)
            if len(rec_header) < 16:
                break
            ts_sec, ts_usec, incl_len, orig_len = struct.unpack(endian + "IIII", rec_header)
            data = f.read(incl_len)
            if len(data) < incl_len:
                break
            yield ts_sec + ts_usec / 1_000_000, data


# ──────────────────────────────────────────────────────────────
# Ethernet -> IPv4 -> TCP -> TLS ClientHello -> SNI
# ──────────────────────────────────────────────────────────────

def extract_sni_from_packet(raw: bytes):
    """
    Probeert een SNI-hostnaam uit één ruw netwerkpakket te halen. Geeft
    (src_ip, dst_ip, dst_port, hostname) terug, of None als dit pakket geen
    (herkenbare) TLS ClientHello met SNI bevat.
    """
    if len(raw) < 14 + 20 + 20:  # minimaal Ethernet + IPv4 + TCP-header
        return None

    # Ethernet-header (14 bytes): dst_mac(6) + src_mac(6) + ethertype(2)
    ethertype = struct.unpack(">H", raw[12:14])[0]
    if ethertype != 0x0800:  # alleen IPv4
        return None

    ip_start = 14
    version_ihl = raw[ip_start]
    ip_version = version_ihl >> 4
    if ip_version != 4:
        return None
    ihl = (version_ihl & 0x0F) * 4
    if ihl < 20:
        return None

    protocol = raw[ip_start + 9]
    if protocol != 6:  # alleen TCP
        return None

    src_ip = socket.inet_ntoa(raw[ip_start + 12:ip_start + 16])
    dst_ip = socket.inet_ntoa(raw[ip_start + 16:ip_start + 20])

    tcp_start = ip_start + ihl
    if len(raw) < tcp_start + 20:
        return None

    dst_port = struct.unpack(">H", raw[tcp_start + 2:tcp_start + 4])[0]
    data_offset = (raw[tcp_start + 12] >> 4) * 4
    if data_offset < 20:
        return None

    payload_start = tcp_start + data_offset
    payload = raw[payload_start:]

    hostname = extract_sni_from_tls_payload(payload)
    if hostname:
        return src_ip, dst_ip, dst_port, hostname
    return None


def extract_sni_from_tls_payload(payload: bytes):
    """
    Parseert een TLS-record en zoekt, als het een ClientHello is, naar de
    SNI-extensie (extension_type 0x0000). Geeft de hostnaam terug, of None.
    """
    if len(payload) < 5:
        return None

    # TLS-record-header: content_type(1) + version(2) + length(2)
    content_type = payload[0]
    if content_type != 0x16:  # 0x16 = Handshake
        return None

    record_length = struct.unpack(">H", payload[3:5])[0]
    handshake = payload[5:5 + record_length]
    if len(handshake) < 4:
        return None

    # Handshake-header: msg_type(1) + length(3)
    msg_type = handshake[0]
    if msg_type != 0x01:  # 0x01 = ClientHello
        return None

    pos = 4  # na msg_type + length
    pos += 2  # legacy_version
    pos += 32  # random
    if pos >= len(handshake):
        return None

    session_id_len = handshake[pos]
    pos += 1 + session_id_len
    if pos + 2 > len(handshake):
        return None

    cipher_suites_len = struct.unpack(">H", handshake[pos:pos + 2])[0]
    pos += 2 + cipher_suites_len
    if pos >= len(handshake):
        return None

    compression_methods_len = handshake[pos]
    pos += 1 + compression_methods_len
    if pos + 2 > len(handshake):
        return None

    extensions_len = struct.unpack(">H", handshake[pos:pos + 2])[0]
    pos += 2
    extensions_end = pos + extensions_len

    while pos + 4 <= min(extensions_end, len(handshake)):
        ext_type = struct.unpack(">H", handshake[pos:pos + 2])[0]
        ext_len = struct.unpack(">H", handshake[pos + 2:pos + 4])[0]
        ext_data = handshake[pos + 4:pos + 4 + ext_len]

        if ext_type == 0x0000:  # server_name
            return parse_sni_extension(ext_data)

        pos += 4 + ext_len

    return None


def parse_sni_extension(ext_data: bytes):
    """Parseert de server_name-extensie-inhoud naar de daadwerkelijke hostnaam-string."""
    if len(ext_data) < 5:
        return None
    # server_name_list_length(2) + name_type(1) + name_length(2) + name
    name_type = ext_data[2]
    if name_type != 0x00:  # 0x00 = host_name
        return None
    name_len = struct.unpack(">H", ext_data[3:5])[0]
    hostname_bytes = ext_data[5:5 + name_len]
    try:
        return hostname_bytes.decode("ascii")
    except UnicodeDecodeError:
        return None


# ──────────────────────────────────────────────────────────────
# Analyse over een volledige capture
# ──────────────────────────────────────────────────────────────

def analyze_pcap(path: str):
    """Analyseert een volledig pcap-bestand en groepeert AI-dienst-verbindingen per bronapparaat."""
    device_services = defaultdict(lambda: defaultdict(lambda: {"count": 0, "first_seen": None, "last_seen": None, "dst_ip": None}))
    total_packets = 0
    tls_packets_seen = 0

    for ts, raw in read_pcap_packets(path):
        total_packets += 1
        result = extract_sni_from_packet(raw)
        if result is None:
            continue
        tls_packets_seen += 1
        src_ip, dst_ip, dst_port, hostname = result

        service_name = hostname_matches_ai_service(hostname)
        if service_name is None:
            continue

        entry = device_services[src_ip][service_name]
        entry["count"] += 1
        entry["dst_ip"] = dst_ip
        entry["hostname"] = hostname
        if entry["first_seen"] is None or ts < entry["first_seen"]:
            entry["first_seen"] = ts
        if entry["last_seen"] is None or ts > entry["last_seen"]:
            entry["last_seen"] = ts

    report = []
    for device_ip, services in device_services.items():
        for service_name, info in services.items():
            report.append({
                "device_ip": device_ip,
                "service": service_name,
                "hostname": info["hostname"],
                "connection_count": info["count"],
                "first_seen": datetime.fromtimestamp(info["first_seen"]).isoformat() if info["first_seen"] else None,
                "last_seen": datetime.fromtimestamp(info["last_seen"]).isoformat() if info["last_seen"] else None,
            })

    report.sort(key=lambda r: r["last_seen"] or "", reverse=True)
    return {
        "generated_at": datetime.now().isoformat(),
        "total_packets_scanned": total_packets,
        "tls_hellos_with_sni": tls_packets_seen,
        "ai_service_usage": report,
    }


def print_report(report: dict):
    usage = report["ai_service_usage"]
    print(f"\n── AI-dienstgebruik-monitor ── ({report['total_packets_scanned']} pakketten gescand, {report['tls_hellos_with_sni']} TLS-hello's met SNI gezien)")
    if not usage:
        print("  Geen bekende AI-diensten gedetecteerd in deze capture.")
        return
    for r in usage:
        print(f"  {r['device_ip']} → {r['service']} ({r['hostname']})")
        print(f"      {r['connection_count']}x, laatst gezien: {r['last_seen']}")


# ──────────────────────────────────────────────────────────────
# Live capture via tcpdump (zelfde architectuurpatroon als softflowd elders)
# ──────────────────────────────────────────────────────────────

def live_capture(interface: str, duration: int, pcap_out: str):
    """
    Vangt live verkeer op poort 443 (HTTPS) via tcpdump, en slaat het op als
    pcap voor analyse. tcpdump zelf ontsleutelt niets — dit legt exact
    dezelfde bytes vast die toch al over de lijn gaan.

    Controleert EXPLICIET of tcpdump daadwerkelijk is geslaagd (exitcode +
    of het bestand echt gevuld is), i.p.v. stilzwijgend door te gaan naar de
    analysestap — een permissiefout (tcpdump heeft root/CAP_NET_RAW nodig,
    en de GUI-service draait doorgaans als gewone gebruiker) gaf anders een
    verwarrende 'bestand te kort'-melding in plaats van de echte oorzaak.
    """
    cmd = [
        "tcpdump", "-i", interface, "-w", pcap_out,
        "-s", "1500",  # snaplen: genoeg voor een volledige ClientHello, geen volledige payload nodig
        "port 443", "-G", str(duration), "-W", "1",
    ]
    print(f"[!] Live capture gestart op interface {interface} voor {duration}s — vereist root/CAP_NET_RAW.")
    try:
        result = subprocess.run(cmd, timeout=duration + 10, capture_output=True, text=True)
    except subprocess.TimeoutExpired:
        result = None  # tcpdump's eigen -G/-W regelt de duur; timeout hier is een vangnet, geen fout op zich
    except FileNotFoundError:
        if platform.system() == "Windows":
            raise RuntimeError(
                "tcpdump niet gevonden. Live meeluisteren is op Windows nog niet ondersteund "
                "(vereist Npcap, niet meegeleverd) — gebruik in plaats daarvan een bestaand "
                "pcap-bestand (bijv. gemaakt met Wireshark) via de 'Bestaand pcap-bestand "
                "analyseren'-modus."
            )
        raise RuntimeError("tcpdump niet gevonden. Installeer met: sudo apt install tcpdump")

    if result is not None and result.returncode != 0:
        stderr = (result.stderr or "").strip()
        stderr_lower = stderr.lower()
        if "no such device" in stderr_lower:
            raise RuntimeError(
                f"tcpdump kon niet meeluisteren: interface '{interface}' bestaat niet (meer) op dit systeem.\n"
                f"Dit is GEEN rechtenprobleem. Ververs de interfacelijst in de GUI (herlaad de pagina) en "
                f"kies opnieuw een interface uit de dropdown — typ de naam niet handmatig over, deze kan "
                f"veranderen (bijv. na het wisselen van een USB-ethernet-adapter)."
            )
        if "permission" in stderr_lower or "operation not permitted" in stderr_lower:
            raise RuntimeError(
                f"tcpdump kon niet meeluisteren (exitcode {result.returncode}): {stderr or '(geen foutdetails)'}\n"
                f"Dit is een RECHTEN-probleem: de GUI-service draait als gewone gebruiker, "
                f"maar packet capture vereist root of CAP_NET_RAW. Los dit eenmalig op met:\n"
                f"  sudo setcap cap_net_raw,cap_net_admin=eip $(which tcpdump)\n"
                f"(daarna herstart je de GUI-service niet eens nodig — dit geldt voor het tcpdump-programma zelf)"
            )
        raise RuntimeError(f"tcpdump eindigde met fout (exitcode {result.returncode}): {stderr or '(geen foutdetails)'}")

    if not os.path.exists(pcap_out) or os.path.getsize(pcap_out) < 24:
        raise RuntimeError(
            f"tcpdump lijkt te zijn gestart maar er is geen (gevuld) capture-bestand ontstaan op {pcap_out}. "
            f"Controleer of interface '{interface}' bestaat (check met: ip -4 addr show) en of er "
            f"daadwerkelijk HTTPS-verkeer (poort 443) langskwam tijdens de meetduur."
        )


def main():
    parser = argparse.ArgumentParser(description="Monitort welke apparaten met welke cloud-AI-diensten praten (via SNI, niet-ontsleutelend)")
    parser.add_argument("--pcap", help="Analyseer een bestaand pcap-bestand")
    parser.add_argument("--capture", action="store_true", help="Vang live verkeer op (vereist root)")
    parser.add_argument("--interface", default="eth0", help="Netwerkinterface voor live capture")
    parser.add_argument("--duration", type=int, default=300, help="Duur van live capture in seconden")
    parser.add_argument("--json", default=None, help="Schrijf volledig rapport als JSON naar dit pad")
    args = parser.parse_args()

    if args.capture:
        with tempfile.NamedTemporaryFile(suffix=".pcap", delete=False) as tmp:
            pcap_path = tmp.name
        try:
            live_capture(args.interface, args.duration, pcap_path)
            report = analyze_pcap(pcap_path)
        finally:
            if os.path.exists(pcap_path):
                os.unlink(pcap_path)
    elif args.pcap:
        report = analyze_pcap(args.pcap)
    else:
        parser.error("Geef --pcap <bestand> of --capture op.")

    print_report(report)

    if args.json:
        with open(args.json, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2)
        print(f"\nVolledig rapport geschreven naar: {args.json}")


if __name__ == "__main__":
    main()
