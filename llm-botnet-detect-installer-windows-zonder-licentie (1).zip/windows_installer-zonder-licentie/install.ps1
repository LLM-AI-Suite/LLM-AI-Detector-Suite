﻿# ==============================================================
# install.ps1  -  LLM-Botnet Detection System (Windows)
# ==============================================================
# IMPORTANT NOTE: this script has been written but NOT executed or
# tested  -  the development environment this project was built in has
# no access to PowerShell or a Windows machine. Unlike install.sh (which
# HAS been actually run and tested repeatedly), this script has only
# been carefully written based on knowledge of PowerShell syntax. Test
# this first on a non-critical machine.
#
# Scope (deliberately narrower than the Linux version):
#   - Layers 1, 2, 3, 4, 5 + GUI + correlation engine
#   - Layer 2 (netflow) live capture requires Npcap + dumpcap.exe (part of
#     Wireshark) - the capture pipeline itself (netflow_capture_windows.py)
#     is NEW and, unlike the rest of this script, has not been tested
#     against real Windows network traffic. Analyzing an existing netflow
#     JSON file works regardless, no extra dependencies needed for that.
#   - AI Service Usage monitor: only analyzing existing pcap files
#     (live listening via tcpdump doesn't work on Windows without Npcap -
#     not yet implemented)
#   - No background automation (no Windows Service/Task Scheduler)  -
#     per earlier explicit request: you start the GUI manually
#
# Usage:
#   Open PowerShell (doesn't need to be Administrator, except for
#   system-wide scans), go to the extracted package folder, and run:
#     .\install.ps1
#
# If PowerShell blocks script execution, once:
#   Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
# ==============================================================

param(
    [switch]$Wachter
)

$ErrorActionPreference = "Stop"

# ---------------------------------------------------------------
# Language detection - Dutch if the system locale is Dutch, English
# for everything else. No manual override by design - keep it simple.
# ---------------------------------------------------------------
try {
    $DetectedLang = (Get-Culture).TwoLetterISOLanguageName
} catch {
    $DetectedLang = "en"
}
if ($DetectedLang -eq "nl") {
    $UiLang = "nl"
} else {
    $UiLang = "en"
}

$T_NL = @{
    title = "LLM-Botnet Detectiesysteem  -  Windows-installatie"
    title_wachter = "LLM-Botnet Detectiesysteem  -  Wachter-installatie (alleen Laag 2)"
    install_dir = "Installatiemap:"
    results_dir = "Resultatenmap:"
    existing_install_1 = "Er lijkt al een installatie te bestaan op"
    existing_install_2 = "Dit script opnieuw draaien over een bestaande installatie heen kan"
    existing_install_3 = "verwarrende, gedeeltelijk-bijgewerkte situaties opleveren."
    existing_install_4 = "Aanbevolen: gebruik .\uninstall.ps1 eerst, of .\update.ps1 als je"
    existing_install_5 = "alleen wilt bijwerken naar een nieuwere versie (sneller, en je"
    existing_install_6 = "sleutels/geschiedenis blijven dan gegarandeerd ongewijzigd)."
    continue_prompt = "Toch doorgaan met een volledige herinstallatie? [j/n, leeg = n]"
    aborted = "Afgebroken - niets gewijzigd. Gebruik .\update.ps1 of .\uninstall.ps1 + .\install.ps1."
    continue_risk = "Doorgaan op eigen risico - bestaande bestanden worden overschreven."

    step1 = "Stap 1/9  -  Vereisten controleren"
    err_no_python_1 = "Python is niet gevonden in PATH."
    err_no_python_2 = "Installeer Python van https://www.python.org/downloads/ (vink 'Add python.exe to PATH' aan) en probeer opnieuw."
    ok_python_found = "Python gevonden:"
    err_no_pip = "pip niet gevonden. Herinstalleer Python met pip inbegrepen."
    ok_pip_available = "pip beschikbaar"

    step2 = "Stap 2/9  -  Python-dependencies installeren"
    err_deps_1 = "Kon psutil/numpy/cryptography/flask/pystray/Pillow niet installeren."
    err_deps_2 = "Probeer handmatig: pip install psutil numpy cryptography flask pystray Pillow scapy"
    ok_deps = "Python-dependencies geinstalleerd"
    npcap_notice_1 = "Voor Laag 2 (netflow) live-capture is Npcap nodig - dit installeert pip NIET automatisch."
    npcap_notice_2 = "Installeer Wireshark (bevat Npcap + dumpcap.exe): https://www.wireshark.org/download.html"
    npcap_notice_3 = "Zonder Npcap werkt Laag 2 nog steeds voor het analyseren van een BESTAAND netflow-bestand."

    step3 = "Stap 3/9  -  Licentie"
    license_not_required = "Geen licentiecode nodig in deze editie"

    step4 = "Stap 4/9  -  Programmabestanden installeren naar"
    ok_files_installed = "Bestanden geinstalleerd"

    step5 = "Stap 5/9  -  Configuratie"
    username_expl_1 = "De naam tussen [blokhaken] hieronder komt van je Windows-account."
    username_expl_2 = "Windows genereert die naam soms zelf automatisch en verkort -"
    username_expl_3 = "dat is normaal. Druk op Enter om die naam te gebruiken, of typ"
    username_expl_4 = "gewoon een andere naam als je liever iets anders gebruikt."
    gui_user_prompt = "Gebruikersnaam voor GUI-login"
    gui_user_confirm_prompt = "Bevestig gebruikersnaam (nogmaals intypen)"
    user_mismatch = "De twee gebruikersnamen komen niet overeen - probeer het opnieuw."
    gui_pass_prompt = "Wachtwoord voor GUI-login (leeg = GUI ONBEVEILIGD, alleen voor localhost-gebruik)"
    gui_pass_confirm_prompt = "Bevestig wachtwoord (nogmaals intypen)"
    pass_mismatch = "De twee wachtwoorden komen niet overeen - probeer het opnieuw."
    tls_question = "Hoe moet de GUI-verbinding beveiligd worden?"
    tls_opt1_title = "  1) HTTPS met een zelfondertekend certificaat (aanbevolen, standaard)"
    tls_opt1_l1 = "     Je browser toont hierbij een 'niet veilig'-waarschuwing - dat is normaal"
    tls_opt1_l2 = "     voor een lokaal hulpmiddel zonder publiek domein en betekent NIET dat de"
    tls_opt1_l3 = "     verbinding zelf onveilig is; de versleuteling werkt gewoon, alleen de"
    tls_opt1_l4 = "     'wie garandeert dit certificaat'-check ontbreekt. Bereikbaar vanaf elk"
    tls_opt1_l5 = "     apparaat in je netwerk."
    tls_opt2_title = "  2) Gewoon HTTP, maar dan alleen bereikbaar via Tailscale of localhost"
    tls_opt2_l1 = "     Geen browserwaarschuwing, maar dan is de GUI NIET bereikbaar via je"
    tls_opt2_l2 = "     gewone LAN-IP - alleen via Tailscale of vanaf de machine zelf."
    tls_choice_prompt = "Keuze [1/2, leeg = 1]"

    step6 = "Stap 6/9  -  Startscript aanmaken"
    ok_launcher_created = "Startscript aangemaakt:"
    ok_tls_mode = "Verbindingsmodus:"
    warn_no_pass = "Geen wachtwoord ingesteld  -  de GUI draait ONBEVEILIGD (0.0.0.0:5000, elk apparaat in je netwerk kan erbij)."
    tray_comment_1 = "Systeemtray-icoontje toont voortaan of de GUI actief is."
    tray_fail = "[!] Kon systemtray-icoontje niet starten (niet kritiek, de GUI werkt gewoon door)."
    launcher_comment_1 = "Start de LLM-Botnet Detectie GUI. Dubbelklik dit bestand (of rechtermuisknop"
    launcher_comment_2 = "-> Uitvoeren met PowerShell), of voer uit vanuit een PowerShell-venster."
    launcher_comment_3 = "Opent na een paar seconden automatisch je browser op de GUI - laat dit"
    launcher_comment_4 = "venster gewoon open staan, dat IS de server (Ctrl+C om te stoppen)."

    step7 = "Stap 7/9  -  Snelkoppeling aanmaken"
    ok_shortcut_gui = "Snelkoppeling op het bureaublad aangemaakt (GUI starten)"
    warn_shortcut_fail = "Kon geen snelkoppeling aanmaken  -  start de GUI voortaan handmatig via"
    ok_shortcut_uninstall = "Snelkoppeling voor verwijderen aangemaakt op het bureaublad"
    warn_shortcut_uninstall_fail = "Kon geen snelkoppeling voor verwijderen aanmaken - uninstall.ps1 staat wel in"
    howto_update_content = @"
Om deze installatie bij te werken naar een nieuwere versie:
1. Download het nieuwste installatiepakket
2. Pak het uit
3. Open PowerShell in de uitgepakte windows_installer-zonder-licentie-map
4. Voer uit: .\update.ps1

(update.ps1 moet uit een VERSE download komen om iets bij te kunnen
werken - een permanente snelkoppeling zou daarom niet werken.)
"@
    ok_howto_update = "Toelichting 'hoe bijwerken' op het bureaublad gezet"
    warn_howto_update_fail = "Kon geen toelichtingsbestand aanmaken op het bureaublad (niet kritiek)."

    step8 = "Stap 8/9  -  Notificaties"
    ok_notifications = "Desktop-toast-notificaties werken via PowerShell (geen extra installatie nodig)"
    tip_ntfy_1 = "  Tip: wil je ook pushberichten naar je telefoon? Ga naar het Dashboard-tabblad"
    tip_ntfy_2 = "  in de GUI na installatie, sectie 'Alarm-instellingen', en vul een ntfy.sh-topic in."

    step9 = "Stap 9/9  -  AI-Dienstgebruik-monitor"
    warn_no_live_listen = "Live meeluisteren is op Windows nog niet ondersteund (vereist Npcap, niet meegeleverd)."
    warn_pcap_works = "Het analyseren van een BESTAAND pcap-bestand (bijv. gemaakt met Wireshark) werkt wel."

    done_title = "Installatie voltooid!"
    gui_start_title = "GUI starten:"
    gui_start_1 = "  Dubbelklik de snelkoppeling 'LLM-Botnet Detectie GUI' op je bureaublad,"
    gui_start_2 = "  of voer handmatig uit: powershell -File"
    gui_reachable = "GUI bereikbaar op:"
    tls_warning_1 = "  Je browser toont een 'niet veilig'-waarschuwing - dat is verwacht bij een"
    tls_warning_2 = "  zelfondertekend certificaat. Klik 'Geavanceerd' -> 'Toch doorgaan'."
    login_line = "  Login:"
    login_pass_note = "(het wachtwoord dat je net hebt ingevoerd)"
    tray_summary = "Een systemtray-icoontje toont voortaan of de GUI actief is (groen) of niet (rood)."
    todo_title = "Nog te doen (handmatig):"
    todo_1 = "  1. TPM-sleutels genereren en je eigen model(len) signeren:"
    todo_1b = "     (kan ook via het Laag 5-tabblad in de GUI)"
    calib_1 = "Kalibratie-advies: laat het systeem 2-4 weken in observeer-modus draaien"
    calib_2 = "voordat je automatische respons aan de correlatie-score koppelt."
    calib_2_wachter = "voordat je Laag 2's bevindingen als basis voor verdere actie gebruikt."
    wachter_summary = "Je bent nu een Wachter: Laag 2 luistert mee naar gossip-botnet-verkeer op dit netwerk. Hoe meer wachters er actief zijn, hoe groter de kans dat iemand een poging tot besmetting daadwerkelijk oppikt - net als bij SETI, waar meer luisteraars een groter deel van de hemel bestrijken."
}

$T_EN = @{
    title = "LLM-Botnet Detection System  -  Windows installation"
    title_wachter = "LLM-Botnet Detection System  -  Sentinel installation (Layer 2 only)"
    install_dir = "Install directory:"
    results_dir = "Results directory:"
    existing_install_1 = "An installation already appears to exist at"
    existing_install_2 = "Running this script again over an existing installation can"
    existing_install_3 = "result in a confusing, partially-updated state."
    existing_install_4 = "Recommended: use .\uninstall.ps1 first, or .\update.ps1 if you"
    existing_install_5 = "only want to update to a newer version (faster, and your"
    existing_install_6 = "keys/history are then guaranteed to remain unchanged)."
    continue_prompt = "Proceed with a full reinstall anyway? [y/n, blank = n]"
    aborted = "Aborted - nothing changed. Use .\update.ps1 or .\uninstall.ps1 + .\install.ps1."
    continue_risk = "Proceeding at your own risk - existing files will be overwritten."

    step1 = "Step 1/9  -  Checking requirements"
    err_no_python_1 = "Python was not found in PATH."
    err_no_python_2 = "Install Python from https://www.python.org/downloads/ (check 'Add python.exe to PATH') and try again."
    ok_python_found = "Python found:"
    err_no_pip = "pip not found. Reinstall Python with pip included."
    ok_pip_available = "pip available"

    step2 = "Step 2/9  -  Installing Python dependencies"
    err_deps_1 = "Could not install psutil/numpy/cryptography/flask/pystray/Pillow."
    err_deps_2 = "Try manually: pip install psutil numpy cryptography flask pystray Pillow scapy"
    ok_deps = "Python dependencies installed"
    npcap_notice_1 = "Layer 2 (netflow) live capture requires Npcap - pip does NOT install this automatically."
    npcap_notice_2 = "Install Wireshark (includes Npcap + dumpcap.exe): https://www.wireshark.org/download.html"
    npcap_notice_3 = "Without Npcap, Layer 2 still works for analyzing an EXISTING netflow file."

    step3 = "Step 3/9  -  License"
    license_not_required = "No license code required in this edition"

    step4 = "Step 4/9  -  Installing program files to"
    ok_files_installed = "Files installed"

    step5 = "Step 5/9  -  Configuration"
    username_expl_1 = "The name between [brackets] below comes from your Windows account."
    username_expl_2 = "Windows sometimes auto-generates and shortens that name itself -"
    username_expl_3 = "that's normal. Press Enter to use that name, or type"
    username_expl_4 = "a different name if you'd prefer to use something else."
    gui_user_prompt = "Username for GUI login"
    gui_user_confirm_prompt = "Confirm username (type it again)"
    user_mismatch = "The two usernames don't match - please try again."
    gui_pass_prompt = "Password for GUI login (blank = GUI UNSECURED, localhost-only use)"
    gui_pass_confirm_prompt = "Confirm password (type it again)"
    pass_mismatch = "The two passwords don't match - please try again."
    tls_question = "How should the GUI connection be secured?"
    tls_opt1_title = "  1) HTTPS with a self-signed certificate (recommended, default)"
    tls_opt1_l1 = "     Your browser will show a 'not secure' warning - this is normal for"
    tls_opt1_l2 = "     a local tool without a public domain, and does NOT mean the"
    tls_opt1_l3 = "     connection itself is insecure; encryption works fine, only the"
    tls_opt1_l4 = "     'who vouches for this certificate' check is missing. Reachable from any"
    tls_opt1_l5 = "     device on your network."
    tls_opt2_title = "  2) Plain HTTP, but only reachable via Tailscale or localhost"
    tls_opt2_l1 = "     No browser warning, but then the GUI is NOT reachable via your"
    tls_opt2_l2 = "     regular LAN IP - only via Tailscale or from the machine itself."
    tls_choice_prompt = "Choice [1/2, blank = 1]"

    step6 = "Step 6/9  -  Creating launcher script"
    ok_launcher_created = "Launcher script created:"
    ok_tls_mode = "Connection mode:"
    warn_no_pass = "No password set  -  the GUI runs UNSECURED (0.0.0.0:5000, any device on your network can reach it)."
    tray_comment_1 = "Systemtray icon will now show whether the GUI is active."
    tray_fail = "[!] Could not start systemtray icon (not critical, the GUI works fine regardless)."
    launcher_comment_1 = "Start the LLM-Botnet Detection GUI. Double-click this file (or right-click"
    launcher_comment_2 = "-> Run with PowerShell), or run it from a PowerShell window."
    launcher_comment_3 = "Opens your browser to the GUI automatically after a few seconds - just"
    launcher_comment_4 = "leave this window open, it IS the server (Ctrl+C to stop)."

    step7 = "Step 7/9  -  Creating shortcut"
    ok_shortcut_gui = "Desktop shortcut created (starts the GUI)"
    warn_shortcut_fail = "Could not create a shortcut  -  start the GUI manually from now on via"
    ok_shortcut_uninstall = "Uninstall shortcut created on the desktop"
    warn_shortcut_uninstall_fail = "Could not create an uninstall shortcut - uninstall.ps1 is still located in"
    howto_update_content = @"
To update this installation to a newer version:
1. Download the latest installation package
2. Extract it
3. Open PowerShell in the extracted windows_installer-zonder-licentie folder
4. Run: .\update.ps1

(update.ps1 needs to come from a FRESH download to have anything to
update with - a permanent shortcut wouldn't work for this reason.)
"@
    ok_howto_update = "'How to update' note placed on the desktop"
    warn_howto_update_fail = "Could not create the explanation file on the desktop (not critical)."

    step8 = "Step 8/9  -  Notifications"
    ok_notifications = "Desktop toast notifications work via PowerShell (no extra install needed)"
    tip_ntfy_1 = "  Tip: want push notifications to your phone too? Go to the Dashboard tab"
    tip_ntfy_2 = "  in the GUI after installation, 'Alert settings' section, and fill in an ntfy.sh topic."

    step9 = "Step 9/9  -  AI Service Usage monitor"
    warn_no_live_listen = "Live listening is not yet supported on Windows (requires Npcap, not included)."
    warn_pcap_works = "Analyzing an EXISTING pcap file (e.g. created with Wireshark) does work."

    done_title = "Installation complete!"
    gui_start_title = "Starting the GUI:"
    gui_start_1 = "  Double-click the 'LLM-Botnet Detectie GUI' shortcut on your desktop,"
    gui_start_2 = "  or run manually: powershell -File"
    gui_reachable = "GUI reachable at:"
    tls_warning_1 = "  Your browser will show a 'not secure' warning - this is expected with a"
    tls_warning_2 = "  self-signed certificate. Click 'Advanced' -> 'Proceed anyway'."
    login_line = "  Login:"
    login_pass_note = "(the password you just entered)"
    tray_summary = "A systemtray icon will now show whether the GUI is active (green) or not (red)."
    todo_title = "Still to do (manually):"
    todo_1 = "  1. Generate TPM keys and sign your own model(s):"
    todo_1b = "     (can also be done via the Layer 5 tab in the GUI)"
    calib_1 = "Calibration advice: let the system run in observation mode for 2-4 weeks"
    calib_2 = "before you tie automatic response to the correlation score."
    calib_2_wachter = "before you use Layer 2's findings as a basis for further action."
    wachter_summary = "You are now a Sentinel: Layer 2 listens for gossip-botnet traffic on this network. The more sentinels are active, the greater the chance that someone actually picks up an infection attempt - much like SETI, where more listeners cover a larger part of the sky."
}

function T($key) {
    if ($UiLang -eq "nl") { return $T_NL[$key] } else { return $T_EN[$key] }
}

$InstallDir = "$env:LOCALAPPDATA\llm-botnet-detect"
$ScriptDir = $PSScriptRoot
$ResultsDir = "$env:USERPROFILE\llm-detect-results"
$KeysDir = "$env:USERPROFILE\llm-detect-keys"
$ConfigDir = "$env:USERPROFILE\.llm-detect"

function Step($msg) { Write-Host "`n==> $msg" -ForegroundColor Green }
function Ok($msg) { Write-Host "[OK] $msg" -ForegroundColor Green }
function WarnMsg($msg) { Write-Host "[WARN]  $msg" -ForegroundColor Yellow }
function ErrorMsg($msg) { Write-Host "[FAIL] $msg" -ForegroundColor Red }

if ($Wachter) {
    Write-Host (T "title_wachter") -ForegroundColor Green
} else {
    Write-Host (T "title") -ForegroundColor Green
}
Write-Host "=================================================="
Write-Host "$(T 'install_dir') $InstallDir"
Write-Host "$(T 'results_dir') $ResultsDir"
Write-Host ""

# ==============================================================
# 0. Bestaande installatie detecteren (voorkomt een dubbele/verwarde staat)
# ==============================================================
if (Test-Path "$InstallDir\llm_detect_gui.py") {
    WarnMsg "$(T 'existing_install_1') $InstallDir."
    WarnMsg (T "existing_install_2")
    WarnMsg (T "existing_install_3")
    Write-Host ""
    Write-Host (T "existing_install_4")
    Write-Host (T "existing_install_5")
    Write-Host (T "existing_install_6")
    Write-Host ""
    $ContinueChoice = Read-Host (T "continue_prompt")
    if ($ContinueChoice -ne "j" -and $ContinueChoice -ne "y") {
        Write-Host (T "aborted")
        exit 0
    }
    WarnMsg (T "continue_risk")
}

# ==============================================================
# 1. Vereisten
# ==============================================================
Step (T "step1")

if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    ErrorMsg (T "err_no_python_1")
    ErrorMsg (T "err_no_python_2")
    exit 1
}
$PythonVersion = python --version 2>&1
Ok "$(T 'ok_python_found') $PythonVersion"

if (-not (Get-Command pip -ErrorAction SilentlyContinue)) {
    ErrorMsg (T "err_no_pip")
    exit 1
}
Ok (T "ok_pip_available")

# ==============================================================
# 2. Python-dependencies
# ==============================================================
# NOTE: dependencies (incl. 'cryptography', needed for the Ed25519 result
# signing that every layer uses) are installed here, before any later step
# needs them - keep this order.
Step (T "step2")

pip install psutil numpy cryptography flask pystray Pillow scapy 2>&1 | Select-Object -Last 8
if ($LASTEXITCODE -ne 0) {
    ErrorMsg (T "err_deps_1")
    ErrorMsg (T "err_deps_2")
    exit 1
}
Ok (T "ok_deps")
Write-Host ""
WarnMsg (T "npcap_notice_1")
Write-Host "  $(T 'npcap_notice_2')"
Write-Host "  $(T 'npcap_notice_3')"

# ==============================================================
# 3. Licentie
# ==============================================================
# Deze editie ("zonder licentie") vraagt bewust GEEN licentiecode en
# controleert er ook geen - license_verify.py en license_authority_public.pem
# zijn niet meegeleverd. De stap blijft bestaan (als bevestiging) zodat de
# stapnummering (x/9) gelijk blijft aan de gelicentieerde editie.
Step (T "step3")
Ok (T "license_not_required")

# ==============================================================
# 4. Bestanden installeren
# ==============================================================
Step "$(T 'step4') $InstallDir"

New-Item -ItemType Directory -Force -Path "$InstallDir\templates" | Out-Null
if ($Wachter) {
    # Alleen wat Laag 2 + GUI daadwerkelijk nodig hebben.
    $WachterFiles = @("llm_detect_gui.py", "netflow_gossip_detector.py", "netflow_capture_windows.py",
                       "result_integrity.py", "notification_helper.py", "tls_utils.py",
                       "tray_indicator.py")
    foreach ($f in $WachterFiles) {
        $src = Join-Path $ScriptDir $f
        if (Test-Path $src) { Copy-Item $src -Destination $InstallDir -Force }
    }
} else {
    Copy-Item "$ScriptDir\*.py" -Destination $InstallDir -Force
}
Copy-Item "$ScriptDir\templates\index.html" -Destination "$InstallDir\templates\" -Force
if (Test-Path "$ScriptDir\documentatie") {
    New-Item -ItemType Directory -Force -Path "$InstallDir\documentatie" | Out-Null
    Copy-Item "$ScriptDir\documentatie\*" -Destination "$InstallDir\documentatie\" -Recurse -Force
}
if (Test-Path "$ScriptDir\VERSION") {
    Copy-Item "$ScriptDir\VERSION" -Destination "$InstallDir\VERSION" -Force
}
# uninstall.ps1 ook meekopieren naar de STABIELE installatiemap (niet
# alleen de uitgepakte downloadmap) - anders breekt de zo dadelijk
# aangemaakte bureaubladsnelkoppeling zodra iemand de downloadmap opruimt.
# (update.ps1 NIET meekopieren: dat script moet juist NIEUWE bestanden
# ophalen uit een vers uitgepakte download - een kopie hier zou zichzelf
# alleen maar overschrijven zonder ooit iets bij te werken.)
if (Test-Path "$ScriptDir\uninstall.ps1") {
    Copy-Item "$ScriptDir\uninstall.ps1" -Destination "$InstallDir\uninstall.ps1" -Force
}
Ok (T "ok_files_installed")

# ==============================================================
# 5. Configuratie
# ==============================================================
Step (T "step5")

Write-Host ""
Write-Host (T "username_expl_1")
Write-Host (T "username_expl_2")
Write-Host (T "username_expl_3")
Write-Host (T "username_expl_4")

$UsersMatch = $false
do {
    $GuiUserInput = Read-Host "$(T 'gui_user_prompt') [$env:USERNAME]"
    if ([string]::IsNullOrWhiteSpace($GuiUserInput)) {
        # Standaardwaarde geaccepteerd (lege invoer) - geen typfout-risico, geen bevestiging nodig.
        $GuiUser = $env:USERNAME
        $UsersMatch = $true
    } else {
        $GuiUserConfirm = Read-Host (T "gui_user_confirm_prompt")
        if ($GuiUserInput -ne $GuiUserConfirm) {
            Write-Host ""
            WarnMsg (T "user_mismatch")
            Write-Host ""
        } else {
            $GuiUser = $GuiUserInput
            $UsersMatch = $true
        }
    }
} while (-not $UsersMatch)

$PasswordsMatch = $false
do {
    $GuiPassSecure = Read-Host (T "gui_pass_prompt") -AsSecureString
    $GuiPassBSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($GuiPassSecure)
    $GuiPass = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($GuiPassBSTR)

    if ([string]::IsNullOrEmpty($GuiPass)) {
        # Bewust leeg = onbeveiligde GUI - geen bevestiging nodig, dat is al een expliciete keuze
        $PasswordsMatch = $true
    } else {
        $GuiPassConfirmSecure = Read-Host (T "gui_pass_confirm_prompt") -AsSecureString
        $GuiPassConfirmBSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($GuiPassConfirmSecure)
        $GuiPassConfirm = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($GuiPassConfirmBSTR)

        if ($GuiPass -ne $GuiPassConfirm) {
            Write-Host ""
            WarnMsg (T "pass_mismatch")
            Write-Host ""
        } else {
            $PasswordsMatch = $true
        }
    }
} while (-not $PasswordsMatch)

Write-Host ""
Write-Host (T "tls_question")
Write-Host (T "tls_opt1_title")
Write-Host (T "tls_opt1_l1")
Write-Host (T "tls_opt1_l2")
Write-Host (T "tls_opt1_l3")
Write-Host (T "tls_opt1_l4")
Write-Host (T "tls_opt1_l5")
Write-Host (T "tls_opt2_title")
Write-Host (T "tls_opt2_l1")
Write-Host (T "tls_opt2_l2")
$TlsChoice = Read-Host (T "tls_choice_prompt")
if ($TlsChoice -eq "2") {
    $GuiTlsMode = "tailscale-only"
    $GuiProtocol = "http"
} else {
    $GuiTlsMode = "https"
    $GuiProtocol = "https"
}

# ==============================================================
# 6. Startscript aanmaken (i.p.v. een achtergrondservice, zoals afgesproken)
# ==============================================================
Step (T "step6")

New-Item -ItemType Directory -Force -Path $ConfigDir | Out-Null
New-Item -ItemType Directory -Force -Path $ResultsDir | Out-Null
New-Item -ItemType Directory -Force -Path $KeysDir | Out-Null

$LauncherPath = "$InstallDir\start-gui.ps1"
$LauncherComment1 = T "launcher_comment_1"
$LauncherComment2 = T "launcher_comment_2"
$LauncherComment3 = T "launcher_comment_3"
$LauncherComment4 = T "launcher_comment_4"
$TrayFailMsg = T "tray_fail"
$LauncherContent = @"
# $LauncherComment1
# $LauncherComment2
# $LauncherComment3
# $LauncherComment4
`$env:LLM_GUI_USER = "$GuiUser"
`$env:LLM_GUI_PASS = "$GuiPass"
`$env:LLM_GUI_TLS_MODE = "$GuiTlsMode"
Set-Location "$InstallDir"
Start-Job -ScriptBlock { Start-Sleep -Seconds 3; Start-Process "$GuiProtocol`://localhost:5000" } | Out-Null
# Systemtray-icoontje als ONAFHANKELIJK proces starten (niet gekoppeld aan
# dit venster) - zo blijft het rood/'niet actief' tonen als je de GUI
# afsluit, wat precies het signaal is dat je dan wilt zien.
try {
    Start-Process -FilePath "python" -ArgumentList "`"$InstallDir\tray_indicator.py`"" -WindowStyle Hidden
} catch {
    Write-Host "$TrayFailMsg"
}
python llm_detect_gui.py
"@
Set-Content -Path $LauncherPath -Value $LauncherContent
Ok "$(T 'ok_launcher_created') $LauncherPath"
Ok "$(T 'ok_tls_mode') $GuiTlsMode"

if ([string]::IsNullOrWhiteSpace($GuiPass)) {
    WarnMsg (T "warn_no_pass")
}

# ==============================================================
# 7. Snelkoppeling op het bureaublad (optioneel, voor het gemak)
# ==============================================================
Step (T "step7")

try {
    $WshShell = New-Object -ComObject WScript.Shell
    $Shortcut = $WshShell.CreateShortcut("$env:USERPROFILE\Desktop\LLM-Botnet Detectie GUI.lnk")
    $Shortcut.TargetPath = "powershell.exe"
    $Shortcut.Arguments = "-ExecutionPolicy Bypass -File `"$LauncherPath`""
    $Shortcut.WorkingDirectory = $InstallDir
    $Shortcut.IconLocation = "shell32.dll,13"
    $Shortcut.Save()
    Ok (T "ok_shortcut_gui")
} catch {
    WarnMsg "$(T 'warn_shortcut_fail') $LauncherPath"
}

# Snelkoppeling voor uninstall - bewust ook zichtbaar op het bureaublad,
# want dit script bleek eerder lastig terug te vinden diep in een
# uitgepakte downloadmap. (Geen snelkoppeling voor update.ps1: dat script
# moet juist NIEUWE bestanden ophalen uit een vers uitgepakte download -
# een permanente snelkoppeling naar een vaste map zou daar niets nieuws
# vinden en zou dus misleidend zijn.)
try {
    $WshShell = New-Object -ComObject WScript.Shell
    $UninstallShortcut = $WshShell.CreateShortcut("$env:USERPROFILE\Desktop\LLM-Botnet Detectie - Verwijderen.lnk")
    $UninstallShortcut.TargetPath = "powershell.exe"
    $UninstallShortcut.Arguments = "-ExecutionPolicy Bypass -File `"$InstallDir\uninstall.ps1`""
    $UninstallShortcut.WorkingDirectory = $InstallDir
    $UninstallShortcut.IconLocation = "shell32.dll,131"
    $UninstallShortcut.Save()
    Ok (T "ok_shortcut_uninstall")
} catch {
    WarnMsg "$(T 'warn_shortcut_uninstall_fail') $InstallDir."
}

# Een tekstbestand op het bureaublad dat uitlegt waar update.ps1 te vinden
# is NA een nieuwe download - kan geen vaste snelkoppeling zijn (zie boven),
# maar dit voorkomt alsnog het "waar is dat ook alweer"-probleem.
try {
    Set-Content -Path "$env:USERPROFILE\Desktop\LLM-Botnet Detectie - hoe bijwerken.txt" -Value (T "howto_update_content")
    Ok (T "ok_howto_update")
} catch {
    WarnMsg (T "warn_howto_update_fail")
}

# ==============================================================
# 8. Notificaties (ntfy.sh werkt hetzelfde als op Linux, geen extra setup)
# ==============================================================
Step (T "step8")

Ok (T "ok_notifications")
Write-Host (T "tip_ntfy_1")
Write-Host (T "tip_ntfy_2")

# ==============================================================
# 9. AI-Dienstgebruik-monitor (beperkte Windows-ondersteuning)
# ==============================================================
Step (T "step9")

WarnMsg (T "warn_no_live_listen")
WarnMsg (T "warn_pcap_works")

# ==============================================================
# Samenvatting
# ==============================================================
Write-Host ""
Write-Host "==================================================" -ForegroundColor Green
Write-Host (T "done_title") -ForegroundColor Green
Write-Host "==================================================" -ForegroundColor Green
Write-Host ""
Write-Host (T "gui_start_title")
Write-Host (T "gui_start_1")
Write-Host "$(T 'gui_start_2') `"$LauncherPath`""
Write-Host ""
Write-Host (T "gui_reachable")
Write-Host "  - $GuiProtocol`://localhost:5000"
if ($GuiTlsMode -eq "https") {
    Write-Host (T "tls_warning_1")
    Write-Host (T "tls_warning_2")
}
if ($GuiPass) { Write-Host "$(T 'login_line') $GuiUser / $(T 'login_pass_note')" }
Write-Host ""
Write-Host (T "tray_summary")
Write-Host ""
if ($Wachter) {
    Write-Host (T "wachter_summary")
    Write-Host ""
    WarnMsg (T "calib_1")
    WarnMsg (T "calib_2_wachter")
} else {
    Write-Host (T "todo_title")
    Write-Host (T "todo_1")
    Write-Host "       python $InstallDir\tpm_model_attestation.py init-authority --out $KeysDir\authority_keys"
    Write-Host "       python $InstallDir\tpm_model_attestation.py init-endpoint --out $KeysDir\endpoint_keys"
    Write-Host (T "todo_1b")
    Write-Host ""
    WarnMsg (T "calib_1")
    WarnMsg (T "calib_2")
}
