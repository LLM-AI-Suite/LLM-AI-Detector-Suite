#!/usr/bin/env python3
"""
notification_helper.py
=========================
Gedeelde alarm-/notificatielogica, gebruikt door zowel llm_detect_gui.py
(handmatige correlatie via de GUI) als scheduled_correlation_check.py (de
periodieke, via systemd-timer gedraaide controle). Eén module zodat beide
consistent dezelfde drempel-instellingen en kanalen gebruiken.

Kanalen:
  - Desktop (notify-send op Linux, PowerShell-toast op Windows) — bestond al,
    hierheen verplaatst voor hergebruik.
  - ntfy.sh — gratis, accountloos pushbericht-systeem. Werkt via een simpele
    HTTP POST naar https://ntfy.sh/<topic>; wie de topic-naam kent (en 'm in
    de ntfy-app of -website volgt) ontvangt het bericht op zijn telefoon.

BELANGRIJKE KANTTEKENING: deze sandbox heeft geen netwerktoegang tot ntfy.sh
(geblokkeerd door de egress-proxy, bevestigd met een 403). De opbouw van het
HTTP-verzoek is hier getest tegen een lokale mock-server (juiste URL-vorm,
headers, body) — de daadwerkelijke aflevering naar een echte telefoon is
niet vanuit deze omgeving te bevestigen.

Instellingen worden weggeschreven naar ~/.config/llm-detect/notify_settings.json.
"""

import json
import os
import platform
import subprocess
import urllib.request
import urllib.error
from pathlib import Path

IS_WINDOWS = platform.system() == "Windows"

SEVERITY_ORDER = ["LAAG", "MIDDEL", "HOOG", "KRITIEK"]

DEFAULT_SETTINGS = {
    "desktop_enabled": True,
    "ntfy_enabled": False,
    "ntfy_topic": "",
    "ntfy_server": "https://ntfy.sh",
    "min_severity": "KRITIEK",
}

SETTINGS_PATH = Path.home() / ".config" / "llm-detect" / "notify_settings.json"


def verdict_tier(score: float) -> str:
    """
    Zelfde drempelwaarden als correlation_engine.py's verdict_label(), maar
    zonder de '— CRYPTOGRAFISCH BEWEZEN'-suffix — voor drempelvergelijking
    volstaat de basis-tier (KRITIEK, ook bij score >= 100).
    """
    if score >= 40:
        return "KRITIEK"
    if score >= 15:
        return "HOOG"
    if score >= 5:
        return "MIDDEL"
    return "LAAG"


def load_settings() -> dict:
    if not SETTINGS_PATH.exists():
        return dict(DEFAULT_SETTINGS)
    try:
        with open(SETTINGS_PATH, encoding="utf-8") as f:
            saved = json.load(f)
        settings = dict(DEFAULT_SETTINGS)
        settings.update(saved)
        return settings
    except (json.JSONDecodeError, OSError):
        return dict(DEFAULT_SETTINGS)


def save_settings(settings: dict):
    SETTINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
    merged = dict(DEFAULT_SETTINGS)
    merged.update(settings)
    with open(SETTINGS_PATH, "w", encoding="utf-8") as f:
        json.dump(merged, f, indent=2)
    return merged


def send_desktop_notification(title: str, message: str, urgency: str = "critical") -> dict:
    """Stuurt een desktop-melding. Geeft {"ok": bool, "error": str|None} terug."""
    if IS_WINDOWS:
        ps_script = f'''
        [Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] > $null
        $template = @"
<toast><visual><binding template="ToastGeneric"><text>{title}</text><text>{message}</text></binding></visual></toast>
"@
        $xml = New-Object Windows.Data.Xml.Dom.XmlDocument
        $xml.LoadXml($template)
        $toast = New-Object Windows.UI.Notifications.ToastNotification $xml
        [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("LLM-Botnet Detectie").Show($toast)
        '''
        try:
            subprocess.run(["powershell", "-NoProfile", "-Command", ps_script], timeout=5, capture_output=True)
            return {"ok": True, "error": None}
        except FileNotFoundError:
            return {"ok": False, "error": "PowerShell niet gevonden"}
        except Exception as e:
            try:
                import ctypes
                ctypes.windll.user32.MessageBoxW(0, message, title, 0x30)
                return {"ok": True, "error": None}
            except Exception as e2:
                return {"ok": False, "error": f"Toast en fallback-popup beide mislukt: {e2}"}
    else:
        try:
            subprocess.run(
                ["notify-send", "--urgency", urgency, "--app-name", "LLM-Botnet Detectie", title, message],
                timeout=5, capture_output=True,
            )
            return {"ok": True, "error": None}
        except FileNotFoundError:
            return {"ok": False, "error": "notify-send niet gevonden — installeer met: sudo apt install libnotify-bin"}
        except Exception as e:
            return {"ok": False, "error": str(e)}


# ntfy.sh-prioriteitsniveaus: min/low/default/high/urgent (of 1-5)
# ntfy.sh's JSON-publiceerformaat verwacht een NUMERIEKE prioriteit (1-5),
# niet de tekstuele vorm ("urgent"/"high"/...) — die tekstuele namen gelden
# alleen voor de header-gebaseerde vorm (X-Priority) of als leesbare labels
# in de ntfy-documentatie, niet als geldige JSON-waarde. Dit gaf bij het
# eerste gebruik een "400 Bad Request" — hier gecorrigeerd naar de juiste
# numerieke schaal: 1=min, 2=low, 3=default, 4=high, 5=urgent.
_NTFY_PRIORITY_MAP = {"LAAG": 2, "MIDDEL": 3, "HOOG": 4, "KRITIEK": 5}


def send_ntfy_notification(topic: str, title: str, message: str, tier: str = "KRITIEK", server: str = "https://ntfy.sh") -> dict:
    """
    Stuurt een pushbericht via ntfy.sh. Geen account nodig — wie de topic-naam
    kent en volgt (via de ntfy-app of -website), ontvangt het bericht.

    Gebruikt bewust ntfy's JSON-publiceervorm (POST naar de servercoot met
    het onderwerp als JSON-veld) in plaats van de header-gebaseerde vorm
    (POST naar /<topic> met Title/Priority/Tags als HTTP-headers) — HTTP-
    headers zijn per specificatie latin-1, wat een titel met emoji's of een
    gedachtestreepje (zoals "🚨 KRITIEK — host") corrumpeert. Bevestigd tijdens
    het testen: de header-vorm gaf "ð¨ KRITIEK â host" i.p.v. de juiste tekst.
    De JSON-body-vorm is gewoon UTF-8 en heeft dit probleem niet.

    LET OP: kies een niet-triviale topic-naam — topics zijn niet geheim-by-
    design, iedereen die de naam raadt kan meelezen/meesturen.
    """
    if not topic:
        return {"ok": False, "error": "Geen ntfy-topic ingesteld."}

    payload = {
        "topic": topic,
        "title": title,
        "message": message,
        "priority": _NTFY_PRIORITY_MAP.get(tier, "default"),
        "tags": ["warning"] if tier in ("HOOG", "KRITIEK") else ["speech_balloon"],
    }

    req = urllib.request.Request(
        server,
        data=json.dumps(payload).encode("utf-8"),
        method="POST",
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return {"ok": 200 <= resp.status < 300, "error": None, "status": resp.status}
    except urllib.error.HTTPError as e:
        # BELANGRIJK: e.read() geeft ntfy's eigen foutmelding terug (bijv.
        # welk veld precies ongeldig was) — zonder dit zag je alleen de
        # generieke "HTTP Error 400: Bad Request", zonder de reden.
        try:
            error_body = e.read().decode("utf-8", errors="replace")
        except Exception:
            error_body = ""
        return {"ok": False, "error": f"HTTP {e.code}: {error_body or e.reason}", "status": e.code}
    except urllib.error.URLError as e:
        return {"ok": False, "error": str(e)}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def dispatch_notifications(score: float, host: str, firing_domains: list, settings: dict = None, hard_fail: bool = False, findings: list = None) -> dict:
    """
    Centraal beslispunt: bepaalt de tier van deze score, vergelijkt die met
    de ingestelde drempel, en stuurt (indien nodig) meldingen via alle
    ingeschakelde kanalen. Geeft een overzicht terug van wat er is gebeurd,
    zodat de aanroeper (GUI of geplande taak) dit kan loggen.

    hard_fail: een bewezen, cryptografisch onderbouwde bevinding (bijv. een
    mislukte attestatie of een niet-geautoriseerd model) uit één enkel
    domein, ongeacht of een tweede domein corroboreert. Vóór deze fix moest
    zo'n bevinding wachten op de gewone score-drempel om zichtbaar te
    worden — een geïsoleerde, eenmalige detectie door slechts één domein
    haalde die drempel vaak niet, en bleef zo onopgemerkt in het logboek
    staan totdat iemand er zelf naar keek. Een bewezen bevinding is geen
    kansberekening meer (zie correlation_engine.py's hard_fail-concept) en
    verdient daarom altijd een melding, los van de algemene drempel — die
    blijft wél gelden voor de overige, niet-bewezen signalen.
    """
    if settings is None:
        settings = load_settings()

    tier = verdict_tier(score)
    threshold = settings.get("min_severity", "KRITIEK")

    if not hard_fail and SEVERITY_ORDER.index(tier) < SEVERITY_ORDER.index(threshold):
        return {"notified": False, "tier": tier, "reason": f"onder de ingestelde drempel ({threshold})"}

    prefix = "🔒 BEWEZEN" if hard_fail else f"🚨 {tier}"
    title = f"{prefix} — {platform.node()} — {host}"
    domains_str = ", ".join(firing_domains) if firing_domains else "(geen vurende domeinen)"
    # Tot deze fix bevatte het bericht alleen domeinnamen + score, nooit de
    # daadwerkelijke bevindingstekst zelf — terwijl correlate_endpoint() die
    # al kant-en-klaar opbouwt (all_findings). Gevonden via een directe,
    # expliciete gebruikersvraag: bewezen meldingen kwamen wel binnen, maar
    # zeiden nooit WAT er precies gevonden was. Kort samengevat (max 2
    # regels) om pushberichten leesbaar te houden — de volledige tekst blijft
    # sowieso beschikbaar in de GUI/het rapport zelf.
    if findings:
        detail = "; ".join(findings[:2])
        if len(findings) > 2:
            detail += f" (+{len(findings) - 2} meer)"
        if len(detail) > 300:
            detail = detail[:297] + "..."
        message = f"Score {score}: {domains_str}\n{detail}"
    else:
        message = f"Score {score}: {domains_str}"

    results = {"notified": True, "tier": tier, "channels": {}}

    if settings.get("desktop_enabled", True):
        results["channels"]["desktop"] = send_desktop_notification(title, message)

    if settings.get("ntfy_enabled", False):
        results["channels"]["ntfy"] = send_ntfy_notification(
            settings.get("ntfy_topic", ""), title, message, tier, settings.get("ntfy_server", "https://ntfy.sh")
        )

    return results
