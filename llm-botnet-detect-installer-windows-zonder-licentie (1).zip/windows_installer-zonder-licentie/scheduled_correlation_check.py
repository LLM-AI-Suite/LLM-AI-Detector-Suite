#!/usr/bin/env python3
"""
scheduled_correlation_check.py
=================================
Draait de volledige correlatieketen zelfstandig, ONAFHANKELIJK van de GUI —
bedoeld voor periodieke uitvoering via een systemd-timer of cron-job in
productie. Dit is nodig omdat de GUI's "Manifest Automatisch Opbouwen" en
"Correlatie Uitvoeren"-knoppen alleen werken terwijl er iemand is ingelogd
en op de knop klikt; in productie moet dit ook 's nachts vanzelf gebeuren.

Stappen:
  1. Bouw een manifest.json op basis van de meest recente resultaten per laag
     (dezelfde logica als de GUI's auto-build-manifest-knop)
  2. Draai de correlatie-engine
  3. Stuur een desktop-notificatie als een endpoint KRITIEK scoort

Gebruik (handmatig testen):
  python3 scheduled_correlation_check.py

Gebruik (productie, via systemd-timer — zie llm-detect-correlate.service):
  Wordt automatisch elke X minuten aangeroepen; logt naar stdout, wat
  systemd via journalctl -u llm-detect-correlate opvangt.
"""

import json
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path
import notification_helper

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
RESULTS_DIR = Path(os.environ.get("LLM_DETECT_RESULTS_DIR", str(Path.home() / "llm-detect-results")))
KRITIEK_THRESHOLD = 40

PREFIX_MAP = {
    "local_scan": "laag1_",
    "netflow": "laag2_",
    "realtime_agent": "laag3_",
    "gpu_fingerprint": "laag4_",
    "attestation": "laag5_verify_",
    "reconnaissance": "verkenning_",
}


def log(msg):
    print(f"[{datetime.now().isoformat(timespec='seconds')}] {msg}")




def auto_build_manifest():
    reports = {}
    sources = []

    for key, prefix in PREFIX_MAP.items():
        candidates = sorted(
            [f for f in RESULTS_DIR.glob(f"{prefix}*.json") if "_samples" not in f.name],
            key=lambda x: x.stat().st_mtime, reverse=True
        )
        if candidates:
            reports[key] = str(candidates[0])
            sources.append(f"{key} ({candidates[0].name})")

    if not reports:
        log("Geen resultaten gevonden — nog niets om te correleren. Overgeslagen.")
        return None

    host = "endpoint-1"
    if "local_scan" in reports:
        try:
            with open(reports["local_scan"], encoding="utf-8") as f:
                data = json.load(f)
                host = data.get("hostname", host)
        except Exception:
            pass

    manifest = {"endpoints": [{"host": host, "reports": reports}]}
    manifest_path = RESULTS_DIR / "manifest_scheduled.json"
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)

    log(f"Manifest opgebouwd met {len(sources)} bron(nen): {', '.join(sources)}")
    return manifest_path


def run_correlation(manifest_path):
    correlatie_out = RESULTS_DIR / f"correlatie_scheduled_{int(datetime.now().timestamp())}.json"
    stix_out = RESULTS_DIR / f"stix_scheduled_{int(datetime.now().timestamp())}.json"

    cmd = [
        "python3", os.path.join(BASE_DIR, "correlation_engine.py"),
        "--manifest", str(manifest_path),
        "--json", str(correlatie_out),
        "--stix", str(stix_out),
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    log(result.stdout)
    if result.returncode != 0:
        log(f"[!] Correlatie-engine gaf fout (exitcode {result.returncode}): {result.stderr}")
        return None
    return correlatie_out


def check_and_notify(correlatie_json_path):
    try:
        with open(correlatie_json_path, encoding="utf-8") as f:
            results = json.load(f)
    except Exception as e:
        log(f"[!] Kon correlatieresultaat niet lezen: {e}")
        return

    settings = notification_helper.load_settings()
    any_notified = False
    for r in results:
        score = r.get("correlated_score", 0)
        result = notification_helper.dispatch_notifications(
            score=score, host=r.get("host", "onbekend"),
            firing_domains=r.get("firing_domains", []), settings=settings,
            hard_fail=r.get("hard_fail_attestation", False),
            findings=r.get("findings", []),
        )
        if result["notified"]:
            any_notified = True
            log(f"🚨 {result['tier']} gedetecteerd: {r['host']} (score {score}) — melding verstuurd via {list(result.get('channels', {}).keys())}")
        else:
            log(f"OK: {r['host']} — score {score} ({result['tier']}, {result['reason']})")

    if not any_notified:
        log("Geen endpoints boven de ingestelde meldingsdrempel — geen notificatie verstuurd.")


def detect_reconnaissance_pattern(window_minutes=10, threshold=3):
    """
    Doorzoekt Laag 3's eigen logboek op herhaalde, snel-opeenvolgende
    'NIET geautoriseerd'-meldingen binnen een kort tijdvenster — een
    signaal dat iets gericht aan het aftasten is (welke modellen worden
    geweigerd, hoe reageert het systeem), niet een losse, individuele
    overtreding. Vergelijkbaar met het 'tripwire'-verkenningsgedrag uit
    het METR-rapport over het OpenAI/Hugging Face-incident (augustus
    2026): bewust herhaald, snel falen om informatie over een
    controlemechanisme te verzamelen, niet één enkele poging.

    Auto-attest's eigen 'unauthorized'-uitkomst wordt alleen als event in
    Laag 3's logboek geschreven, niet als los, blijvend bestand (de
    measure-and-quote/verify-subcommando's binnen attempt_auto_attestation()
    draaien bewust zonder --json) — dus dít is de plek waar zo'n patroon
    zichtbaar wordt, niet de individuele Laag 5-resultaten.
    """
    laag3_files = sorted(
        RESULTS_DIR.glob("laag3_*.json"),
        key=lambda p: p.stat().st_mtime, reverse=True
    )
    if not laag3_files:
        return None

    now = datetime.now().timestamp()
    window_start = now - (window_minutes * 60)

    recent_unauthorized = []
    # Alleen de meest recente paar bestanden — dit signaal gaat om RECENT
    # gedrag binnen het tijdvenster, niet om de volledige geschiedenis.
    for f in laag3_files[:3]:
        try:
            with open(f, encoding="utf-8") as fh:
                events = json.load(fh)
        except Exception:
            continue
        if not isinstance(events, list):
            continue
        for e in events:
            if e.get("severity") == "KRITIEK" and "NIET geautoriseerd" in e.get("message", ""):
                if e.get("ts", 0) >= window_start:
                    recent_unauthorized.append(e)

    if len(recent_unauthorized) < threshold:
        return None

    finding = {
        "type": "verkenningspatroon",
        "severity": "KRITIEK",
        "count": len(recent_unauthorized),
        "window_minutes": window_minutes,
        "detail": (
            f"{len(recent_unauthorized)} niet-geautoriseerde modelpogingen binnen "
            f"{window_minutes} minuten — mogelijk gericht aftasten van het "
            f"controlemechanisme, geen losse overtreding."
        ),
        "detected_at": now,
        "events": recent_unauthorized,
    }

    out_path = RESULTS_DIR / f"verkenning_{int(now)}.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(finding, f, indent=2)
    try:
        import result_integrity as _ri
        _key_dir = _ri.resolve_key_dir()
        _priv = _ri.get_or_create_signing_key(_key_dir)
        _ri.sign_result_file(str(out_path), _priv)
    except Exception as _e:
        log(f"[!] Kon verkenningsresultaat niet ondertekenen ({_e}).")

    return finding


def refresh_attestation_verification():
    """
    Draait een VERSE verificatie van de laatst gemeten modelload tegen de
    HUIDIGE registry-staat — in plaats van simpelweg het laatst bekende
    laag5_verify_*.json-resultaat te hergebruiken. Dit is het verschil
    tussen "was dit model ooit geldig verklaard" en "is dit model NU nog
    geldig" — bijv. een model dat gisteren correct geverifieerd werd, maar
    inmiddels is ingetrokken (revoke), zou zonder deze stap stilzwijgend
    als "geldig" blijven gelden totdat iemand handmatig opnieuw op Verify
    klikt in de GUI.

    Beperking, eerlijk vermeld: dit hercontroleert de LAATST GEMETEN quote
    opnieuw tegen de actuele registry — het detecteert dus geen compleet
    NIEUW, nooit-gemeten model dat ergens stiekem zou zijn geladen (dat
    vereist live proces-monitoring die dit systeem niet heeft). Wat het
    wél oplost: een eerder als geldig bevonden model dat nadien is
    ingetrokken, wordt bij de eerstvolgende geplande controle correct als
    ongeldig herkend, zonder handmatige actie.
    """
    quote_candidates = sorted(
        [f for f in RESULTS_DIR.glob("laag5_quote_*.json")],
        key=lambda x: x.stat().st_mtime, reverse=True
    )
    if not quote_candidates:
        log("Geen eerder gemeten model-quote gevonden — Laag 5-herverificatie overgeslagen.")
        return None

    quote_path = quote_candidates[0]
    try:
        with open(quote_path, encoding="utf-8") as f:
            quote_data = json.load(f)
        nonce = quote_data["nonce"]
    except Exception as e:
        log(f"[!] Kon nonce niet uit {quote_path.name} lezen ({e}) — Laag 5-herverificatie overgeslagen.")
        return None

    # Consistent met resolve_key_dir() (result_integrity.py) en de gelijke
    # fix in realtime_kernel_agent.py's Agent-klasse — ook hier eerst een
    # omgevingsvariabele controleren, ook al draait dit specifieke script
    # in de praktijk altijd als de installerende gebruiker (via
    # llm-detect-correlate.timer, een user-level systemd-unit, nooit root).
    # Consistentie/robuustheid, niet omdat hier vandaag al een actief risico
    # bevestigd is.
    keys_base = os.environ.get("LLM_DETECT_KEYS_BASE") or os.path.expanduser("~/llm-detect-keys")
    registry_path = os.path.join(keys_base, "registry.json")
    authority_pubkey = os.path.join(keys_base, "authority_keys", "public.pem")
    endpoint_pubkey = os.path.join(keys_base, "endpoint_keys", "public.pem")
    if not (os.path.isfile(registry_path) and os.path.isfile(authority_pubkey) and os.path.isfile(endpoint_pubkey)):
        log("Laag 5-sleutels/registry nog niet aangemaakt — herverificatie overgeslagen (verwacht bij een verse installatie).")
        return None

    verify_out = RESULTS_DIR / f"laag5_verify_scheduled_{int(datetime.now().timestamp())}.json"
    cmd = [
        "python3", os.path.join(BASE_DIR, "tpm_model_attestation.py"), "verify",
        "--quote", str(quote_path),
        "--registry", registry_path,
        "--authority-pubkey", authority_pubkey,
        "--endpoint-pubkey", endpoint_pubkey,
        "--expected-nonce", nonce,
        "--json", str(verify_out),
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode == 0:
        log(f"Laag 5 vers geherverifieerd (gebaseerd op {quote_path.name}) — resultaat: {verify_out.name}")
    else:
        log(f"[!] Laag 5-herverificatie gaf een afwijkend resultaat (exitcode {result.returncode}) — mogelijk is het model ingetrokken sinds de laatste meting.")
    return verify_out


def main():
    log("── Geplande correlatiecontrole gestart ──")
    refresh_attestation_verification()

    verkenning = detect_reconnaissance_pattern()
    if verkenning:
        log(f"🚨 Verkenningspatroon gedetecteerd: {verkenning['detail']}")
        settings = notification_helper.load_settings()
        import socket
        result = notification_helper.dispatch_notifications(
            score=100, host=socket.gethostname(),
            firing_domains=["verkenning (herhaalde mislukte modelverificaties)"],
            settings=settings, hard_fail=True, findings=[verkenning["detail"]],
        )
        if result["notified"]:
            log(f"🚨 Melding verstuurd via {list(result.get('channels', {}).keys())}")

    manifest_path = auto_build_manifest()
    if manifest_path is None:
        return
    correlatie_json = run_correlation(manifest_path)
    if correlatie_json is None:
        return
    check_and_notify(correlatie_json)
    log("── Geplande correlatiecontrole voltooid ──")


if __name__ == "__main__":
    main()
