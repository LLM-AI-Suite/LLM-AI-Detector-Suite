#!/usr/bin/env python3
"""
correlation_engine.py
========================
L3 uit de architectuur: de SIEM-fusielaag die de vier detectielagen combineert
tot één multidimensionale score per endpoint.

Kernprincipe uit het onderzoeksrapport:
  "Elk van de vijf signaaldomeinen levert op zichzelf een hoog vals-positief
   percentage op. De kracht zit in correlatie: een endpoint dat tegelijkertijd
   GPU-inferentiesignatuur, gossip-timing én GGUF-achtige bestandsentropie
   toont, is met hoge zekerheid gecompromitteerd."

Dit script implementeert die exponentiële escalatie: hoe meer ONAFHANKELIJKE
domeinen tegelijk vuren voor hetzelfde endpoint, hoe sterker de score groeit
— niet lineair. Eén geïsoleerd signaal (bijv. alleen hoog VRAM-gebruik, wat
een legitieme ML-ontwikkelaar ook vertoont) blijft laag. Vier signalen samen
(bestand + proces/netwerk + gossip + GPU-ritme) is vrijwel nooit legitiem.

Speciale behandeling van TPM-attestatie (laag 5): dit is geen anomalie-score
maar een cryptografisch definitief allow/deny-oordeel. Een FAILED attestatie
gecombineerd met ÉÉN ander signaal escaleert direct naar KRITIEK, ongeacht de
numerieke score van de andere domeinen — een cryptografisch bewezen
ongeautoriseerd model dat ook nog gedragsafwijkingen vertoont heeft geen
verdere correlatie nodig.

Input: een manifest-JSON die per endpoint verwijst naar de outputbestanden
van de vier losse tools (zie --example voor het formaat).

Output: leesbaar rapport + optioneel STIX 2.1 indicator-bundle voor SIEM-
integratie (Splunk, Microsoft Sentinel, Elastic SIEM).

Gebruik:
  python3 correlation_engine.py --example > manifest.json
  python3 correlation_engine.py --manifest manifest.json --stix stix_bundle.json
"""

import argparse
import json
import os
import sys
import time
import uuid


# ──────────────────────────────────────────────────────────────
# Per-domein normalisatie: elke tool heeft zijn eigen scoreschaal.
# Hier mappen we die naar een gemeenschappelijke 0-10-schaal zodat
# domeinen onderling vergelijkbaar en optelbaar worden.
# ──────────────────────────────────────────────────────────────

def normalize_local_scan(report: dict) -> dict:
    """Laag 1: bestandsscanner + proces/netwerk-snapshot (llm_botnet_scanner.py 'all')."""
    if report is None:
        return {"domain": "filesystem_process_network", "score": 0, "findings": [], "present": False}

    findings = []
    max_severity = 0

    for f in report.get("files", []):
        max_severity = max(max_severity, f.get("severity", 0))
        findings.extend(f"[bestand] {ff}" for ff in f.get("findings", []))

    for c in report.get("correlated", []):
        max_severity = max(max_severity, c.get("combined_severity", 0))
        findings.extend(f"[proces+netwerk] {r}" for r in c.get("reasons", []))

    # laag-1-schaal loopt ruwweg 0-13 (zie eerdere severity-optellingen); normaliseer naar 0-10
    score = min(10, max_severity)
    return {"domain": "filesystem_process_network", "score": score, "findings": findings, "present": True}


def normalize_realtime_agent(events: list) -> dict:
    """Laag 3: realtime kernel-agent events (realtime_kernel_agent.py)."""
    if events is None:
        return {"domain": "realtime_behavior", "score": 0, "findings": [], "present": False, "hard_fail": False}

    severity_map = {"KRITIEK": 10, "HOOG": 6, "MIDDEL": 3, "LAAG": 1}
    max_score = 0
    findings = []
    for e in events:
        s = severity_map.get(e.get("severity", ""), 0)
        max_score = max(max_score, s)
        findings.append(f"[realtime] {e.get('message', '')}")

    # Consistent met attestation/reconnaissance: een KRITIEK-detectie hier
    # (bijv. een onbevoegd model dat live probeert te laden) is net zo'n
    # direct, bewezen signaal als een attestatie-mislukking — geen losse
    # kansberekening meer. Vóór deze fix werd dit domein nooit als hard_fail
    # meegewogen, gevonden tijdens een systematische pentest-ronde.
    return {"domain": "realtime_behavior", "score": max_score, "findings": findings, "present": True, "hard_fail": max_score >= 10}


def normalize_gpu(report: dict) -> dict:
    """Laag 4: GPU-fingerprint-analyse (gpu_fingerprint_detector.py)."""
    if report is None:
        return {"domain": "gpu_fingerprint", "score": 0, "findings": [], "present": False}

    # laag-4-schaal loopt 0-9 (3+4+2 max); normaliseer naar 0-10
    raw = report.get("severity", 0)
    score = min(10, round(raw * 10 / 9))
    findings = [f"[gpu] {f}" for f in report.get("findings", [])]
    return {"domain": "gpu_fingerprint", "score": score, "findings": findings, "present": True}


def normalize_netflow(host_result: dict) -> dict:
    """Laag 2: netflow gossip-analyse voor dit specifieke host (netflow_gossip_detector.py)."""
    if host_result is None:
        return {"domain": "network_gossip", "score": 0, "findings": [], "present": False}

    raw = host_result.get("total_severity", 0)
    # kan flink oplopen (zagen scores tot ~65 bij een actieve gossip-node); normaliseer logaritmisch-achtig
    score = min(10, raw / 6)
    findings = []
    if host_result.get("churn_finding"):
        findings.append(f"[gossip] {host_result['churn_finding']}")
    for pr in host_result.get("peer_results", []):
        findings.extend(f"[gossip] {f}" for f in pr.get("findings", []))
    return {"domain": "network_gossip", "score": round(score, 1), "findings": findings, "present": True}


def normalize_attestation(result: dict) -> dict:
    """Laag 5: TPM-attestatieverdict (tpm_model_attestation.py verify --json)."""
    if result is None:
        return {"domain": "attestation", "score": 0, "findings": [], "present": False, "hard_fail": False}

    if result.get("overall_pass"):
        return {"domain": "attestation", "score": 0, "findings": ["[attestatie] Model geverifieerd en toegestaan"],
                 "present": True, "hard_fail": False}

    failed_checks = [c for c in result.get("checks", []) if not c["pass"]]
    findings = [f"[attestatie] {c['check']}: {c['detail']}" for c in failed_checks]
    return {"domain": "attestation", "score": 10, "findings": findings, "present": True, "hard_fail": True}


RECONNAISSANCE_STALENESS_MINUTES = 60  # ouder dan dit telt niet meer mee — het patroon is dan niet meer 'actueel'


def normalize_reconnaissance(result: dict) -> dict:
    """Laag 3-verkenningssignaal (scheduled_correlation_check.py's
    detect_reconnaissance_pattern() — herhaalde, snel-opeenvolgende
    autorisatiemislukkingen binnen een tijdvenster, zie whitepaper 9.14/6.2).

    Behandeld als hard_fail, net als een bewezen attestatie-mislukking: een
    bevestigd verkenningspatroon is, net als de andere hard_fail-gevallen,
    geen kansberekening meer maar een direct signaal. Een verkenningsbestand
    ouder dan RECONNAISSANCE_STALENESS_MINUTES telt bewust niet meer mee —
    zonder dit zou één, lang geleden gevuurd bestand voor altijd de score
    van elke latere, ongerelateerde correlatiecontrole blijven verhogen.
    """
    if result is None:
        return {"domain": "verkenning", "score": 0, "findings": [], "present": False, "hard_fail": False}

    age_minutes = (time.time() - result.get("detected_at", 0)) / 60
    if age_minutes > RECONNAISSANCE_STALENESS_MINUTES:
        return {"domain": "verkenning", "score": 0, "findings": [], "present": False, "hard_fail": False}

    return {
        "domain": "verkenning",
        "score": 10,
        "findings": [f"[verkenning] {result.get('detail', '')}"],
        "present": True,
        "hard_fail": True,
    }


# ──────────────────────────────────────────────────────────────
# Correlatie: exponentiële escalatie bij meerdere onafhankelijke domeinen
# ──────────────────────────────────────────────────────────────

ESCALATION_MULTIPLIER = {0: 1.0, 1: 1.0, 2: 1.6, 3: 2.4, 4: 3.5, 5: 5.0, 6: 6.0}
DOMAIN_FIRE_THRESHOLD = 2.0   # score >= dit telt als "dit domein vuurt"


def correlate_endpoint(host: str, domain_results: list, tampered_sources: list = None) -> dict:
    tampered_sources = tampered_sources or []
    firing_domains = [d for d in domain_results if d["score"] >= DOMAIN_FIRE_THRESHOLD]
    n_firing = len(firing_domains)

    base_score = sum(d["score"] for d in firing_domains)
    multiplier = ESCALATION_MULTIPLIER.get(n_firing, 5.0)
    correlated_score = round(base_score * multiplier, 1)

    hard_fail = any(d.get("hard_fail") for d in domain_results)
    if hard_fail and n_firing >= 2:
        # cryptografisch bewezen ongeautoriseerd model + minstens één ander
        # onafhankelijk signaal = geen verdere twijfel nodig
        correlated_score = max(correlated_score, 100)

    integrity_violation = len(tampered_sources) > 0
    if integrity_violation:
        # Een resultaatbestand dat na het schrijven is gewijzigd, is geen
        # gedragsinferentie maar een BEWEZEN manipulatiepoging — net als bij
        # hard_fail_attestation is verdere kansberekening dan niet meer
        # relevant. Dit escaleert altijd naar het maximum, ongeacht hoeveel
        # domeinen "vuren" — want de manipulatie zelf ondermijnt het
        # vertrouwen in wat er nog meer wél/niet gevuurd zou hebben.
        correlated_score = max(correlated_score, 100)

    all_findings = []
    for d in domain_results:
        all_findings.extend(d["findings"])
    if integrity_violation:
        all_findings.insert(
            0,
            f"[integriteit] MANIPULATIE GEDETECTEERD in resultaatbestand(en): {', '.join(tampered_sources)} "
            f"— de handtekening klopt niet meer met de inhoud, wat betekent dat het bestand na het "
            f"schrijven is aangepast.",
        )

    return {
        "host": host,
        "n_domains_firing": n_firing,
        "firing_domains": [d["domain"] for d in firing_domains],
        "escalation_multiplier": multiplier,
        "base_score": round(base_score, 1),
        "correlated_score": correlated_score,
        "hard_fail_attestation": hard_fail,
        "integrity_violation": integrity_violation,
        "tampered_sources": tampered_sources,
        "findings": all_findings,
        "domain_breakdown": domain_results,
    }


def verdict_label(correlated_score: float) -> str:
    if correlated_score >= 100:
        return "KRITIEK — CRYPTOGRAFISCH BEWEZEN"
    if correlated_score >= 40:
        return "KRITIEK"
    if correlated_score >= 15:
        return "HOOG"
    if correlated_score >= 5:
        return "MIDDEL"
    return "LAAG"


# ──────────────────────────────────────────────────────────────
# Manifest verwerken
# ──────────────────────────────────────────────────────────────

def load_json_or_none(path):
    """
    Geeft (data, integrity_status) terug. integrity_status volgt hetzelfde
    model als result_integrity.verify_result_file(): "valid" (correct
    ondertekend), "tampered" (handtekening aanwezig maar ongeldig — het
    manipulatie-signaal), "unsigned" (geen .sig-bestand, bijv. een ouder
    resultaat), of "not_applicable" (geen pad opgegeven / bestand niet
    leesbaar).
    """
    if not path:
        return None, {"status": "not_applicable", "valid": None}
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError):
        return None, {"status": "not_applicable", "valid": None}

    try:
        import result_integrity as _ri
        _key_dir = _ri.resolve_key_dir()
        _pub = _ri.get_public_key(_key_dir)
        integrity = _ri.verify_result_file(path, _pub)
    except Exception:
        # Sleutel bestaat nog niet, of result_integrity niet beschikbaar —
        # geen fatale fout, gewoon niet-geverifieerd behandelen.
        integrity = {"status": "unknown", "valid": None}

    return data, integrity


def process_manifest(manifest: dict) -> list:
    results = []
    for endpoint in manifest.get("endpoints", []):
        host = endpoint["host"]
        reports = endpoint.get("reports", {})

        local_scan, integ_local = load_json_or_none(reports.get("local_scan"))
        realtime_events, integ_realtime = load_json_or_none(reports.get("realtime_agent"))
        gpu_report, integ_gpu = load_json_or_none(reports.get("gpu_fingerprint"))
        attestation_result, integ_attestation = load_json_or_none(reports.get("attestation"))
        reconnaissance_result, integ_reconnaissance = load_json_or_none(reports.get("reconnaissance"))

        # netflow-rapport is een LIJST van host-resultaten (zie netflow_gossip_detector.py);
        # pik het resultaat voor dit specifieke host eruit
        netflow_all, integ_netflow = load_json_or_none(reports.get("netflow"))
        netflow_host_result = None
        if netflow_all:
            netflow_host_result = next((h for h in netflow_all if h["host"] == host), None)

        domain_results = [
            normalize_local_scan(local_scan),
            normalize_realtime_agent(realtime_events),
            normalize_gpu(gpu_report),
            normalize_netflow(netflow_host_result),
            normalize_attestation(attestation_result),
            normalize_reconnaissance(reconnaissance_result),
        ]

        integrity_statuses = [integ_local, integ_realtime, integ_gpu, integ_attestation, integ_netflow, integ_reconnaissance]
        tampered_sources = [
            name for name, integ in zip(
                ["local_scan", "realtime_agent", "gpu_fingerprint", "attestation", "netflow", "reconnaissance"],
                integrity_statuses,
            ) if integ.get("status") == "tampered"
        ]

        results.append(correlate_endpoint(host, domain_results, tampered_sources))

    results.sort(key=lambda r: r["correlated_score"], reverse=True)
    return results


# ──────────────────────────────────────────────────────────────
# Rapportage
# ──────────────────────────────────────────────────────────────

def print_report(results: list):
    print(f"\n══════════ CORRELATIE-RAPPORT ══════════ ({len(results)} endpoints)\n")
    for r in results:
        label = verdict_label(r["correlated_score"])
        print(f"── Host {r['host']} ── [{label}]  score={r['correlated_score']} "
              f"(basis={r['base_score']} × multiplier={r['escalation_multiplier']}, "
              f"{r['n_domains_firing']} domeinen vuren)")
        if r["firing_domains"]:
            print(f"   Vurende domeinen: {', '.join(r['firing_domains'])}")
        for finding in r["findings"][:8]:
            print(f"      • {finding}")
        if len(r["findings"]) > 8:
            print(f"      … en {len(r['findings']) - 8} meer")
        print()


# ──────────────────────────────────────────────────────────────
# STIX 2.1-export (lichte subset: Indicator-objecten)
# ──────────────────────────────────────────────────────────────

def to_stix_indicator(result: dict) -> dict:
    now = time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime())
    pattern = f"[network-traffic:src_ref.value = '{result['host']}']"
    description = (
        f"Gecorreleerde LLM-botnet-indicatoren voor host {result['host']}: "
        f"{result['n_domains_firing']} domeinen vuren gelijktijdig "
        f"({', '.join(result['firing_domains'])}). Score {result['correlated_score']}."
    )
    if result["hard_fail_attestation"]:
        description += " TPM-attestatie MISLUKT — cryptografisch bewezen ongeautoriseerd model."

    return {
        "type": "indicator",
        "spec_version": "2.1",
        "id": f"indicator--{uuid.uuid4()}",
        "created": now,
        "modified": now,
        "name": f"Verdachte gedistribueerde LLM-activiteit — {result['host']}",
        "description": description,
        "indicator_types": ["anomalous-activity", "malicious-activity"],
        "pattern": pattern,
        "pattern_type": "stix",
        "valid_from": now,
        "confidence": min(100, int(result["correlated_score"])),
    }


def build_stix_bundle(results: list, min_score=5.0) -> dict:
    indicators = [to_stix_indicator(r) for r in results if r["correlated_score"] >= min_score]
    return {
        "type": "bundle",
        "id": f"bundle--{uuid.uuid4()}",
        "objects": indicators,
    }


# ──────────────────────────────────────────────────────────────
# Voorbeeld-manifest
# ──────────────────────────────────────────────────────────────

EXAMPLE_MANIFEST = {
    "endpoints": [
        {
            "host": "10.0.0.9",
            "reports": {
                "local_scan": "reports/10.0.0.9/local_scan.json",
                "realtime_agent": "reports/10.0.0.9/realtime_events.json",
                "gpu_fingerprint": "reports/10.0.0.9/gpu_report.json",
                "netflow": "reports/shared/netflow_report.json",
                "attestation": "reports/10.0.0.9/attestation.json",
                "reconnaissance": "reports/10.0.0.9/reconnaissance.json",
            },
        }
    ]
}


# ──────────────────────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Correlatie-engine: fuseert alle vier detectielagen per endpoint")
    parser.add_argument("--manifest", help="Pad naar manifest-JSON met per-endpoint rapportverwijzingen")
    parser.add_argument("--example", action="store_true", help="Print een voorbeeld-manifest naar stdout en stop")
    parser.add_argument("--json", help="Schrijf volledig correlatieresultaat als JSON naar dit pad")
    parser.add_argument("--stix", help="Schrijf STIX 2.1-indicatorbundel naar dit pad")
    parser.add_argument("--stix-min-score", type=float, default=5.0, help="Minimale score voor opname in STIX-bundel")
    args = parser.parse_args()

    if args.example:
        json.dump(EXAMPLE_MANIFEST, sys.stdout, indent=2)
        return

    if not args.manifest:
        parser.error("Gebruik --manifest of --example")
        return

    with open(args.manifest, encoding="utf-8") as f:
        manifest = json.load(f)

    results = process_manifest(manifest)
    print_report(results)

    if args.json:
        with open(args.json, "w", encoding="utf-8") as f:
            json.dump(results, f, indent=2)
        try:
            import result_integrity as _ri
            _key_dir = _ri.resolve_key_dir()
            _priv = _ri.get_or_create_signing_key(_key_dir)
            _ri.sign_result_file(args.json, _priv)
        except Exception as _e:
            print(f"[!] Kon resultaat niet ondertekenen ({_e}) — bestand blijft ongesigneerd.")
        print(f"Volledig correlatierapport geschreven naar: {args.json}")

    if args.stix:
        bundle = build_stix_bundle(results, args.stix_min_score)
        with open(args.stix, "w", encoding="utf-8") as f:
            json.dump(bundle, f, indent=2)
        print(f"STIX 2.1-bundel geschreven naar: {args.stix} ({len(bundle['objects'])} indicators)")


if __name__ == "__main__":
    main()
