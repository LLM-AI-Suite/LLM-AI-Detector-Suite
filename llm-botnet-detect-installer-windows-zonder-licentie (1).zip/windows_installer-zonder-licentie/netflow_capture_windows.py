#!/usr/bin/env python3
"""
netflow_capture_windows.py — Live netflow-capture voor Windows.

BELANGRIJKE KANTTEKENING: dit script is zorgvuldig geschreven en lokaal
syntactisch/logisch gecontroleerd, maar NOOIT getest tegen echt Windows-
netwerkverkeer, een echte Npcap-installatie, of een echte Windows-machine
(de ontwikkelomgeving heeft geen toegang tot Windows). Test dit als eerste
stap op een niet-kritieke machine vóór productief gebruik.

Vult het gat dat softflowd/nfdump op Linux normaal vullen: vangt pakketten,
aggregeert ze tot flow-records (5-tuple: bron/doel-IP, bron/doel-poort,
protocol), en schrijft output in exact het JSON-schema dat
netflow_gossip_detector.py al verwacht — dus GEEN wijziging nodig aan de
analyse-kant, alleen een nieuwe manier om aan de invoer te komen.

Vereist: Npcap (https://npcap.com, gratis) en Wireshark's dumpcap.exe
(meegeleverd bij een standaard Wireshark-installatie, of los verkrijgbaar)
in PATH, plus de Python-library scapy voor het uitlezen van het pcap-bestand.

Gebruik:
    python netflow_capture_windows.py --interface "Ethernet" --duration 60 --json output.json
"""
import argparse
import json
import os
import platform
import shutil
import subprocess
import sys
import tempfile
import time
from collections import defaultdict

# Netflow-achtige tijdvensters: een 5-tuple die langer dan ACTIVE_TIMEOUT
# actief is, wordt als aparte flow-records opgesplitst — dit voorkomt dat
# één lange verbinding alle individuele heartbeats verdoezelt tot één
# gemiddeld record (wat detect_heartbeat_signature() in
# netflow_gossip_detector.py juist nodig heeft om te kunnen werken).
ACTIVE_TIMEOUT_SEC = 15


def find_dumpcap():
    """Zoekt dumpcap.exe op de gangbare installatielocaties."""
    candidates = [
        shutil.which("dumpcap"),
        shutil.which("dumpcap.exe"),
        r"C:\Program Files\Wireshark\dumpcap.exe",
        r"C:\Program Files (x86)\Wireshark\dumpcap.exe",
    ]
    for c in candidates:
        if c and os.path.isfile(c):
            return c
    return None


def capture_to_pcap(interface: str, duration: int, pcap_out: str):
    """
    Vangt ruw verkeer op de opgegeven interface via dumpcap.exe (onderdeel
    van Wireshark, gebruikt Npcap als onderliggende capture-driver).

    Waarom dumpcap.exe i.p.v. een eigen scapy-sniff(): dumpcap is het
    daadwerkelijke, geteste capture-programma dat Wireshark zelf gebruikt
    — betrouwbaarder en met minder pakketverlies bij hoge doorvoer dan een
    zelfgeschreven Python-sniff-lus. scapy wordt hierna alleen gebruikt om
    het resulterende pcap-bestand te LEZEN, niet om te capturen.
    """
    dumpcap = find_dumpcap()
    if dumpcap is None:
        raise RuntimeError(
            "dumpcap.exe niet gevonden. Installeer Wireshark (bevat dumpcap.exe en de "
            "Npcap-driver): https://www.wireshark.org/download.html — kies bij de "
            "installatie expliciet voor het meeleveren van Npcap."
        )

    cmd = [dumpcap, "-i", interface, "-w", pcap_out, "-a", f"duration:{duration}"]
    print(f"[!] Live netflow-capture gestart op interface '{interface}' voor {duration}s.")
    try:
        result = subprocess.run(cmd, timeout=duration + 15, capture_output=True, text=True)
    except subprocess.TimeoutExpired:
        result = None  # dumpcap's eigen -a duration regelt de duur; dit is een vangnet

    if result is not None and result.returncode != 0:
        stderr = (result.stderr or "").strip()
        raise RuntimeError(
            f"dumpcap kon niet meeluisteren (exitcode {result.returncode}): {stderr or '(geen foutdetails)'}\n"
            f"Meest waarschijnlijke oorzaken: de interfacenaam klopt niet (controleer met "
            f"'dumpcap -D' in een terminal), of Npcap is niet correct geïnstalleerd."
        )

    if not os.path.exists(pcap_out) or os.path.getsize(pcap_out) < 24:
        raise RuntimeError(
            f"dumpcap lijkt te zijn gestart maar er is geen (gevuld) capture-bestand ontstaan. "
            f"Controleer of interface '{interface}' bestaat en of er daadwerkelijk verkeer "
            f"langskwam tijdens de meetduur."
        )


def get_local_ips():
    """
    Bepaalt de eigen IP-adressen van deze machine, om 'out' (van dit
    apparaat) te kunnen onderscheiden van 'in' (naar dit apparaat).
    """
    import socket
    ips = set()
    try:
        hostname = socket.gethostname()
        for info in socket.getaddrinfo(hostname, None):
            ips.add(info[4][0])
    except Exception:
        pass
    ips.add("127.0.0.1")
    return ips


def aggregate_pcap_to_flows(pcap_path: str, local_ips: set) -> list:
    """
    Leest het pcap-bestand en aggregeert individuele pakketten tot
    flow-records — hetzelfde principe als softflowd op Linux, maar dan in
    Python. Een 5-tuple (bron-IP, doel-IP, bron-poort, doel-poort, proto)
    wordt binnen een ACTIVE_TIMEOUT_SEC-venster samengevoegd tot één
    record; bij een langere pauze begint een nieuwe flow (dit behoudt het
    heartbeat-timingpatroon dat de analyse nodig heeft, i.p.v. alles tot
    één gemiddelde te verdoezelen).
    """
    try:
        from scapy.all import rdpcap, IP, TCP, UDP
    except ImportError:
        raise RuntimeError(
            "De Python-library 'scapy' ontbreekt. Installeer met: pip install scapy"
        )

    packets = rdpcap(pcap_path)

    # key: (src_ip, dst_ip, src_port, dst_port, proto) -> lopende flow-state
    active_flows = {}
    finished_flows = []

    for pkt in packets:
        if IP not in pkt:
            continue
        ip_layer = pkt[IP]
        ts = float(pkt.time)

        if TCP in pkt:
            proto = "tcp"
            sport, dport = pkt[TCP].sport, pkt[TCP].dport
        elif UDP in pkt:
            proto = "udp"
            sport, dport = pkt[UDP].sport, pkt[UDP].dport
        else:
            continue  # alleen tcp/udp is relevant voor deze analyse

        size = len(pkt)
        key = (ip_layer.src, ip_layer.dst, sport, dport, proto)

        if key in active_flows:
            flow = active_flows[key]
            if ts - flow["last_ts"] > ACTIVE_TIMEOUT_SEC:
                # Te lange pauze -> vorige flow afsluiten, nieuwe beginnen
                finished_flows.append(flow)
                active_flows[key] = {
                    "first_ts": ts, "last_ts": ts, "bytes": size,
                    "src_ip": ip_layer.src, "dst_ip": ip_layer.dst,
                    "src_port": sport, "dst_port": dport, "proto": proto,
                }
            else:
                flow["last_ts"] = ts
                flow["bytes"] += size
        else:
            active_flows[key] = {
                "first_ts": ts, "last_ts": ts, "bytes": size,
                "src_ip": ip_layer.src, "dst_ip": ip_layer.dst,
                "src_port": sport, "dst_port": dport, "proto": proto,
            }

    finished_flows.extend(active_flows.values())

    records = []
    for f in finished_flows:
        direction = "out" if f["src_ip"] in local_ips else "in"
        records.append({
            "ts": f["first_ts"],
            "src_ip": f["src_ip"],
            "dst_ip": f["dst_ip"],
            "src_port": f["src_port"],
            "dst_port": f["dst_port"],
            "proto": f["proto"],
            "bytes": f["bytes"],
            "direction": direction,
        })
    return records


def main():
    parser = argparse.ArgumentParser(description="Live netflow-capture voor Windows (Npcap/dumpcap-gebaseerd)")
    parser.add_argument("--interface", required=True, help="Netwerkinterface-naam (zie: dumpcap -D)")
    parser.add_argument("--duration", type=int, default=60, help="Capture-duur in seconden (standaard 60)")
    parser.add_argument("--json", required=True, help="Uitvoerpad voor de flow-records (JSON-array)")
    args = parser.parse_args()

    if platform.system() != "Windows":
        print("[!] Dit script is specifiek voor Windows — op Linux zijn softflowd/nfdump al de aangewezen route.", file=sys.stderr)

    with tempfile.NamedTemporaryFile(suffix=".pcap", delete=False) as tmp:
        pcap_path = tmp.name

    try:
        capture_to_pcap(args.interface, args.duration, pcap_path)
        local_ips = get_local_ips()
        flows = aggregate_pcap_to_flows(pcap_path, local_ips)

        with open(args.json, "w", encoding="utf-8") as f:
            json.dump(flows, f)

        print(f"[✓] {len(flows)} flow-record(s) geschreven naar {args.json}")
    finally:
        if os.path.exists(pcap_path):
            os.remove(pcap_path)


if __name__ == "__main__":
    main()
