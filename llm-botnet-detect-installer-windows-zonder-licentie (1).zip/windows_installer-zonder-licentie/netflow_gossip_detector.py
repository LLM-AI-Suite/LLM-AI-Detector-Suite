#!/usr/bin/env python3
"""
netflow_gossip_detector.py
============================
Detecteert gossip-protocol timingsignaturen en verdachte P2P blob-uitwisselingen
in netwerkflow-records — zonder content-inspectie.

Verwacht input: JSON-lines of JSON-array van flow-records met minimaal:
    {
      "ts": <unix timestamp, float>,
      "src_ip": "...", "dst_ip": "...",
      "src_port": int, "dst_port": int,
      "proto": "tcp" | "udp",
      "bytes": int,          # totale bytes in deze flow
      "direction": "out" | "in"   # vanuit perspectief van het gemonitorde endpoint
    }

Dit formaat komt overeen met de output van nfdump/softflowd na conversie naar JSON,
of kan direct gegenereerd worden vanuit /proc/net of eBPF-flow-accounting.

Gebruikte heuristieken (zie onderzoeksrapport):
  1. Grote peer-to-peer blobs        -> flow_size > drempel naar onbekende peer
  2. Gossip-timingsignatuur           -> lage variantie in interarrival van kleine flows
  3. Stroom-symmetrie                 -> upload/download-ratio van zware blobs ~1.0
  4. Peer-churn                       -> veel verschillende peers per tijdvenster

Gebruik:
  python3 netflow_gossip_detector.py --input flows.json
  python3 netflow_gossip_detector.py --input flows.json --json report.json
  python3 netflow_gossip_detector.py --generate-synthetic normal > flows_normal.json
  python3 netflow_gossip_detector.py --generate-synthetic gossip > flows_gossip.json
"""

import argparse
import json
import os
import random
import statistics
import sys
import time
import ipaddress
from collections import defaultdict

# ──────────────────────────────────────────────────────────────
# Drempelwaarden (zie rapport, sectie "Netwerk")
# ──────────────────────────────────────────────────────────────

LARGE_BLOB_BYTES = 40 * 1024 * 1024          # 40 MB — LoRA-delta-orde-grootte
SMALL_FLOW_BYTES = 8 * 1024                   # 8 KB  — heartbeat-orde-grootte
HEARTBEAT_VARIANCE_MAX = 0.20                 # coëfficiënt van variatie (stddev/mean)
SYMMETRY_RATIO_MIN = 0.6                      # upload/download-ratio binnen [0.6, 1.67] = symmetrisch
SYMMETRY_RATIO_MAX = 1.0 / SYMMETRY_RATIO_MIN
PEER_CHURN_WINDOW_SEC = 3600                  # 1 uur
PEER_CHURN_THRESHOLD = 8                      # >8 verschillende SIGNAALHOUDENDE peers per uur is verdacht
KNOWN_CDN_ASN_MARKERS = {"cloudflare", "akamai", "fastly", "amazonaws", "googleusercontent"}

# IP-bereiken die structureel NOOIT een P2P-gossip-peer kunnen zijn, en dus
# altijd worden uitgesloten vóórdat er geanalyseerd wordt — gevonden na een
# praktijktest waarbij multicast/SSDP-verkeer (239.255.255.250, het standaard
# UPnP-discovery-adres dat vrijwel elk thuisnetwerk met smart-tv's/printers/
# Chromecasts genereert) ten onrechte als "gossip-heartbeat" werd gemarkeerd.
#
# Tailscale's CGNAT-bereik (100.64.0.0/10) wordt eveneens uitgesloten: verkeer
# tussen je eigen apparaten via je eigen Tailscale-mesh (bijv. je telefoon die
# je zelf-gehoste AI-suite bereikt) is per definitie vertrouwd eigen verkeer,
# geen anonieme P2P-peer. Dit is een bewuste afweging: een aanvaller zou in
# theorie ook Tailscale kunnen misbruiken, maar dat is een randgeval dat hier
# ondergeschikt is aan het voorkomen van valse alarmen op je eigen apparaten.
EXCLUDED_NETWORKS = [
    ipaddress.ip_network("224.0.0.0/4"),      # multicast (incl. SSDP/UPnP 239.255.255.250)
    ipaddress.ip_network("255.255.255.255/32"),  # beperkte broadcast
    ipaddress.ip_network("169.254.0.0/16"),   # link-local (APIPA)
    ipaddress.ip_network("100.64.0.0/10"),    # Tailscale/CGNAT-bereik — eigen VPN-mesh
]


def is_excluded_peer(ip: str) -> bool:
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return False
    return any(addr in net for net in EXCLUDED_NETWORKS)


# ──────────────────────────────────────────────────────────────
# Data laden
# ──────────────────────────────────────────────────────────────

def load_flows(path: str) -> list:
    with open(path, "r", encoding="utf-8") as f:
        content = f.read().strip()
    if not content:
        return []
    # ondersteun zowel JSON-array als JSON-lines
    if content.startswith("["):
        return json.loads(content)
    flows = []
    for line in content.splitlines():
        line = line.strip()
        if line:
            flows.append(json.loads(line))
    return flows


# ──────────────────────────────────────────────────────────────
# Peer-link aggregatie
# ──────────────────────────────────────────────────────────────

def peer_key(a: str, b: str) -> tuple:
    """Ongeordend paar zodat A->B en B->A dezelfde link zijn."""
    return tuple(sorted((a, b)))


def build_peer_links(flows: list, local_hosts: set) -> dict:
    """
    Groepeer flows per (host, peer)-paar waarbij host een lokaal gemonitord
    endpoint is. Geeft dict: host -> peer_ip -> lijst van flow-records.

    Gebruikt bij voorkeur het 'direction'-veld (out = vanuit lokale host,
    in = naar lokale host) — dit is robuust voor bidirectioneel verkeer,
    waarbij een IP-set-lidmaatschapscheck faalt omdat elke peer ook als
    zowel src als dst voorkomt. Als 'direction' ontbreekt, valt het terug
    op de local_hosts-set.
    """
    links = defaultdict(lambda: defaultdict(list))
    for flow in flows:
        src, dst = flow["src_ip"], flow["dst_ip"]
        direction = flow.get("direction")

        if direction == "out":
            host, peer = src, dst
        elif direction == "in":
            host, peer = dst, src
        elif src in local_hosts:
            host, peer = src, dst
        elif dst in local_hosts:
            host, peer = dst, src
        else:
            continue

        if is_excluded_peer(peer):
            continue

        links[host][peer].append(flow)
    return links


# ──────────────────────────────────────────────────────────────
# Heuristiek 1: grote blob-uitwisselingen
# ──────────────────────────────────────────────────────────────

def detect_large_blobs(host_flows: list) -> list:
    blobs = [f for f in host_flows if f["bytes"] >= LARGE_BLOB_BYTES]
    return blobs


# ──────────────────────────────────────────────────────────────
# Heuristiek 2: gossip-timingsignatuur (heartbeat-regelmaat)
# ──────────────────────────────────────────────────────────────

def detect_heartbeat_signature(host_flows: list):
    """
    Kijk naar kleine flows (heartbeat-achtig) en bereken de variatiecoëfficiënt
    van de tijd tussen opeenvolgende flows. Een lage variatiecoëfficiënt
    betekent een zeer regelmatig (machine-achtig) patroon — typisch voor
    gossip-heartbeats, atypisch voor menselijk/applicatie-verkeer.

    Belangrijk: we kijken alleen naar de 'out'-richting (het eigen verzendritme
    van de lokale host naar deze peer). Als we in+out mengen, komt elke
    heartbeat-paar (out gevolgd door een antwoord enkele ms later) tussen twee
    ritme-intervallen te staan, wat de variantie kunstmatig opblaast en het
    onderliggende regelmatige patroon maskeert.
    """
    small_flows = sorted(
        (f for f in host_flows if f["bytes"] <= SMALL_FLOW_BYTES and f.get("direction") != "in"),
        key=lambda f: f["ts"]
    )
    if len(small_flows) < 5:
        return None

    interarrivals = [
        small_flows[i + 1]["ts"] - small_flows[i]["ts"]
        for i in range(len(small_flows) - 1)
    ]
    interarrivals = [d for d in interarrivals if d > 0]
    if len(interarrivals) < 4:
        return None

    mean = statistics.mean(interarrivals)
    stddev = statistics.pstdev(interarrivals)
    if mean == 0:
        return None
    cv = stddev / mean  # coëfficiënt van variatie

    return {
        "n_small_flows": len(small_flows),
        "mean_interarrival_sec": round(mean, 2),
        "coefficient_of_variation": round(cv, 3),
        "is_regular": cv <= HEARTBEAT_VARIANCE_MAX,
    }


# ──────────────────────────────────────────────────────────────
# Heuristiek 3: upload/download-symmetrie
# ──────────────────────────────────────────────────────────────

def detect_symmetry(host_flows: list, host_is_src_field="direction"):
    total_out = sum(f["bytes"] for f in host_flows if f.get("direction") == "out")
    total_in = sum(f["bytes"] for f in host_flows if f.get("direction") == "in")

    if total_out == 0 or total_in == 0:
        return {"ratio": None, "is_symmetric": False, "total_out": total_out, "total_in": total_in}

    ratio = total_out / total_in
    is_symmetric = SYMMETRY_RATIO_MIN <= ratio <= SYMMETRY_RATIO_MAX
    return {
        "ratio": round(ratio, 3),
        "is_symmetric": is_symmetric,
        "total_out": total_out,
        "total_in": total_in,
    }


# ──────────────────────────────────────────────────────────────
# Heuristiek 4: peer-churn
# ──────────────────────────────────────────────────────────────

def detect_peer_churn(host: str, peer_links: dict, signal_peers: set) -> dict:
    """
    Telt alleen churn over peers die AL minstens één ander verdacht signaal
    tonen (heartbeat-regelmaat en/of grote blobs) — niet over elke losse
    website/CDN-verbinding. Dit is een bewuste correctie na een praktijktest:
    gewoon surfgedrag genereert al snel 60+ verschillende externe IP's per
    uur (elke website, advertentienetwerk, CDN telt apart), wat de oorspron-
    kelijke "elke peer telt mee"-aanpak liet vals-positief afgaan. Een echt
    gossip-botnet vertoont daarentegen bij vrijwel ELKE peer een regelmatige
    heartbeat (zie de whitepaper-testresultaten), dus deze striktere telling
    blijft een echt botnet-scenario onverminderd detecteren.
    """
    peers = {p: flows for p, flows in peer_links[host].items() if p in signal_peers}
    all_flows = []
    for peer_ip, flows in peers.items():
        for f in flows:
            all_flows.append((f["ts"], peer_ip))
    if not all_flows:
        return {"max_peers_per_window": 0, "is_high_churn": False}

    all_flows.sort()
    start_ts = all_flows[0][0]
    end_ts = all_flows[-1][0]

    max_peers = 0
    window_start = start_ts
    while window_start <= end_ts:
        window_end = window_start + PEER_CHURN_WINDOW_SEC
        peers_in_window = {p for ts, p in all_flows if window_start <= ts < window_end}
        max_peers = max(max_peers, len(peers_in_window))
        window_start += PEER_CHURN_WINDOW_SEC

    return {
        "max_peers_per_window": max_peers,
        "is_high_churn": max_peers > PEER_CHURN_THRESHOLD,
    }


# ──────────────────────────────────────────────────────────────
# Correlatie & scoring per host
# ──────────────────────────────────────────────────────────────

def analyze_host(host: str, peer_links: dict) -> dict:
    all_host_flows = []
    per_peer_results = []

    for peer_ip, flows in peer_links[host].items():
        blobs = detect_large_blobs(flows)
        symmetry = detect_symmetry(flows)
        heartbeat = detect_heartbeat_signature(flows)

        findings = []
        severity = 0

        if blobs:
            total_blob_mb = sum(b["bytes"] for b in blobs) / (1024 * 1024)
            findings.append(
                f"{len(blobs)} grote blob-uitwisseling(en) met {peer_ip} "
                f"(totaal {total_blob_mb:.1f} MB, LoRA-delta-orde-grootte)"
            )
            severity += 3

        if symmetry["is_symmetric"] and blobs:
            findings.append(
                f"Symmetrische upload/download-ratio met {peer_ip} "
                f"({symmetry['ratio']}) — atypisch voor client-server, past bij P2P"
            )
            severity += 2

        if heartbeat and heartbeat["is_regular"]:
            findings.append(
                f"Regelmatige heartbeat-timing naar {peer_ip} "
                f"(interval~{heartbeat['mean_interarrival_sec']}s, "
                f"CV={heartbeat['coefficient_of_variation']}) — past bij gossip-protocol"
            )
            severity += 3

        if findings:
            per_peer_results.append({
                "peer": peer_ip,
                "findings": findings,
                "severity": severity,
                "blob_count": len(blobs),
                "symmetry": symmetry,
                "heartbeat": heartbeat,
            })

        all_host_flows.extend(flows)

    signal_peers = {r["peer"] for r in per_peer_results}
    churn = detect_peer_churn(host, peer_links, signal_peers)
    churn_finding = None
    if churn["is_high_churn"]:
        churn_finding = (
            f"Hoge peer-churn: {churn['max_peers_per_window']} verschillende peers "
            f"binnen één uur — past bij gossip-peer-sampling"
        )

    per_peer_results.sort(key=lambda r: r["severity"], reverse=True)
    total_severity = sum(r["severity"] for r in per_peer_results) + (4 if churn_finding else 0)

    return {
        "host": host,
        "peer_results": per_peer_results,
        "peer_churn": churn,
        "churn_finding": churn_finding,
        "total_severity": total_severity,
    }


def severity_label(score: int) -> str:
    if score >= 10:
        return "KRITIEK"
    if score >= 5:
        return "HOOG"
    if score >= 2:
        return "MIDDEL"
    return "LAAG"


# ──────────────────────────────────────────────────────────────
# Rapportage
# ──────────────────────────────────────────────────────────────

def print_report(host_results: list):
    print(f"\n── Netflow gossip-analyse ── ({len(host_results)} gemonitorde hosts)")
    for hr in host_results:
        if hr["total_severity"] == 0:
            continue
        print(f"\n  [{severity_label(hr['total_severity'])}] Host {hr['host']}  (score {hr['total_severity']})")
        if hr["churn_finding"]:
            print(f"      • {hr['churn_finding']}")
        for pr in hr["peer_results"]:
            print(f"      Peer {pr['peer']}  [severity {pr['severity']}]")
            for finding in pr["findings"]:
                print(f"          - {finding}")

    if all(hr["total_severity"] == 0 for hr in host_results):
        print("  Geen verdachte gossip-patronen aangetroffen.")


# ──────────────────────────────────────────────────────────────
# Synthetische data-generatie (voor testen zonder live capture)
# ──────────────────────────────────────────────────────────────

def generate_normal_traffic(host="10.0.0.5", n=200, seed=1) -> list:
    """Simuleert normaal webverkeer: asymmetrisch, wisselende timing, CDN-achtige peers."""
    rnd = random.Random(seed)
    flows = []
    t = time.time() - 3600 * 3
    cdn_peers = [f"104.16.{i}.1" for i in range(1, 6)]  # doet zich voor als CDN-achtig
    for _ in range(n):
        peer = rnd.choice(cdn_peers)
        t += rnd.uniform(1, 45)  # onregelmatige timing, mens-achtig
        size = int(rnd.lognormvariate(9, 1.5))  # meestal klein, af en toe wat groter
        flows.append({
            "ts": t, "src_ip": host, "dst_ip": peer,
            "src_port": rnd.randint(40000, 60000), "dst_port": 443,
            "proto": "tcp", "bytes": size, "direction": "out",
        })
        flows.append({
            "ts": t + 0.05, "src_ip": peer, "dst_ip": host,
            "src_port": 443, "dst_port": rnd.randint(40000, 60000),
            "proto": "tcp", "bytes": int(size * rnd.uniform(3, 20)), "direction": "in",
        })
    return flows


def generate_gossip_traffic(host="10.0.0.9", n_peers=12, seed=2) -> list:
    """
    Simuleert een gossip-protocol node:
      - periodieke kleine heartbeats naar wisselende peers (lage variantie)
      - af en toe een grote symmetrische blob-uitwisseling (LoRA-delta)
      - hoge peer-churn
    """
    rnd = random.Random(seed)
    flows = []
    t = time.time() - 3600 * 2
    peers = [f"185.220.{rnd.randint(1,254)}.{rnd.randint(1,254)}" for _ in range(n_peers)]

    # heartbeats: zeer regelmatig interval (~12s) met kleine jitter, wisselende peer
    hb_t = t
    for i in range(300):
        peer = peers[i % len(peers)]
        hb_t += 12 + rnd.uniform(-0.5, 0.5)   # lage variantie
        flows.append({
            "ts": hb_t, "src_ip": host, "dst_ip": peer,
            "src_port": rnd.randint(40000, 60000), "dst_port": 51413,
            "proto": "udp", "bytes": rnd.randint(200, 2000), "direction": "out",
        })
        flows.append({
            "ts": hb_t + 0.02, "src_ip": peer, "dst_ip": host,
            "src_port": 51413, "dst_port": rnd.randint(40000, 60000),
            "proto": "udp", "bytes": rnd.randint(200, 2000), "direction": "in",
        })

    # grote symmetrische blob-uitwisselingen (LoRA-delta's) met een subset van peers
    blob_t = t + 300
    for i in range(15):
        peer = peers[i % 5]
        blob_t += rnd.uniform(200, 900)
        blob_size = int(rnd.uniform(35, 65) * 1024 * 1024)  # 35-65 MB
        flows.append({
            "ts": blob_t, "src_ip": host, "dst_ip": peer,
            "src_port": rnd.randint(40000, 60000), "dst_port": 51413,
            "proto": "tcp", "bytes": blob_size, "direction": "out",
        })
        flows.append({
            "ts": blob_t + rnd.uniform(1, 4), "src_ip": peer, "dst_ip": host,
            "src_port": 51413, "dst_port": rnd.randint(40000, 60000),
            "proto": "tcp", "bytes": int(blob_size * rnd.uniform(0.85, 1.1)), "direction": "in",
        })

    return flows


# ──────────────────────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Netflow-analyse voor gossip-protocol- en P2P-detectie")
    parser.add_argument("--input", help="Pad naar flow-records (JSON-array of JSON-lines)")
    parser.add_argument("--local-hosts", help="Komma-gescheiden lijst van te monitoren lokale IP's; default: auto-detecteren als meest voorkomende src/dst")
    parser.add_argument("--json", help="Schrijf volledig rapport als JSON naar dit pad")
    parser.add_argument(
        "--generate-synthetic", choices=["normal", "gossip"],
        help="Genereer synthetische testdata naar stdout (voor validatie zonder live capture)"
    )
    parser.add_argument(
        "--seed", type=int, default=None,
        help="Vaste seed voor --generate-synthetic (default: functie-eigen vaste waarde — "
             "geef dit expliciet op als je bij herhaalde runs GEEN identieke testdata wilt)"
    )
    args = parser.parse_args()

    if args.generate_synthetic:
        seed_kwargs = {"seed": args.seed} if args.seed is not None else {}
        flows = (generate_normal_traffic(**seed_kwargs) if args.generate_synthetic == "normal"
                  else generate_gossip_traffic(**seed_kwargs))
        json.dump(flows, sys.stdout, indent=2)
        return

    if not args.input:
        parser.error("--input is verplicht (of gebruik --generate-synthetic)")

    flows = load_flows(args.input)
    if not flows:
        print("Geen flow-records gevonden.")
        return

    if args.local_hosts:
        local_hosts = set(args.local_hosts.split(","))
    else:
        # auto-detecteer: IP's die zowel als src als dst voorkomen zijn kandidaat-lokale hosts
        src_ips = {f["src_ip"] for f in flows}
        dst_ips = {f["dst_ip"] for f in flows}
        local_hosts = src_ips & dst_ips

    peer_links = build_peer_links(flows, local_hosts)
    host_results = [analyze_host(host, peer_links) for host in sorted(peer_links.keys())]

    print_report(host_results)

    if args.json:
        with open(args.json, "w", encoding="utf-8") as f:
            json.dump(host_results, f, indent=2, default=str)
        print(f"\nVolledig rapport geschreven naar: {args.json}")
        try:
            import result_integrity as _ri
            _key_dir = _ri.resolve_key_dir()
            _priv = _ri.get_or_create_signing_key(_key_dir)
            _ri.sign_result_file(args.json, _priv)
        except Exception as _e:
            print(f"[!] Kon resultaat niet ondertekenen ({_e}) — bestand blijft ongesigneerd.")


if __name__ == "__main__":
    main()
