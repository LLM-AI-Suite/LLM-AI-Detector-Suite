#!/usr/bin/env python3
"""
llm_botnet_scanner_windows.py
================================
Windows-compatibele versie van Laag 1 (bestand-, proces- en netwerkscanner).

BELANGRIJKE KANTTEKENING: deze versie is gebouwd en getest op Linux, via de
Linux-implementatie van 'psutil' — een cross-platform library die op Windows
exact dezelfde Python-API biedt (memory_maps(), net_connections(), enz.),
maar daaronder andere Windows-systeemaanroepen gebruikt (WMI/ToolHelp-API's
i.p.v. /proc). De detectielogica zelf (welke patronen, welke drempelwaarden)
is dus wél getest; de daadwerkelijke Windows-systeemkoppeling van psutil zelf
is een volwassen, veelgebruikte library maar hier niet op een echte Windows-
machine bevestigd. Dit is vergelijkbaar met eerdere kanttekeningen in dit
project (eBPF, echte GPU, echte TPM) — alleen dit keer betreft het de héle
onderliggende OS-laag, niet alleen één hardware-integratie.

Dit bestand staat LOS van llm_botnet_scanner.py (de Linux/proc-native versie
die al in productie draait) — géén wijzigingen aan die werkende versie.

Extra Windows-vereiste: pip install psutil

Gebruik (identiek aan de Linux-versie):
  python llm_botnet_scanner_windows.py all --path C:\\Users\\<naam> --json rapport.json
  python llm_botnet_scanner_windows.py processes
  python llm_botnet_scanner_windows.py network
"""

import argparse
import ctypes
import json
import math
import os
import re
import statistics
import sys
import time
from pathlib import Path

try:
    import psutil
except ImportError:
    print("[!] Het 'psutil'-package is vereist op Windows: pip install psutil", file=sys.stderr)
    sys.exit(1)

# ──────────────────────────────────────────────────────────────
# Signaturen (identiek aan de Linux-versie, zie llm_botnet_scanner.py)
# ──────────────────────────────────────────────────────────────

BLOCK_SIZE = 4096
SAMPLE_BLOCKS = 64
GGUF_MAGIC = b"GGUF"

ML_LIB_PATTERNS = [
    re.compile(r"nvcuda\.dll", re.IGNORECASE),
    re.compile(r"cublas.*\.dll", re.IGNORECASE),
    re.compile(r"cudnn.*\.dll", re.IGNORECASE),
    re.compile(r"torch.*\.(dll|pyd)", re.IGNORECASE),
    re.compile(r"ggml.*\.dll", re.IGNORECASE),
    re.compile(r"llama.*\.dll", re.IGNORECASE),
    re.compile(r"nvml\.dll", re.IGNORECASE),
    re.compile(r"tensorflow.*\.dll", re.IGNORECASE),
    re.compile(r"onnxruntime.*\.dll", re.IGNORECASE),
    # ook de Linux/WSL-namen herkennen, voor het geval WSL-processen zichtbaar zijn
    re.compile(r"libcuda\.so"), re.compile(r"libtorch"), re.compile(r"libggml"),
]

RSS_SPIKE_THRESHOLD_KB = 3 * 1024 * 1024      # 3 GB
USS_THRESHOLD_KB = 2 * 1024 * 1024            # 2 GB — vervangt de Linux anon-mmap-check;
                                                # USS (Unique Set Size) is de cross-platform
                                                # psutil-metriek voor privé/niet-gedeeld geheugen,
                                                # het beste beschikbare equivalent op Windows

SUSPECT_PORTS = {
    11434: "Ollama API (default)",
    8080: "generic inference API (llama.cpp/vLLM/OpenWebUI default)",
    8000: "generic inference API (vLLM default)",
    5000: "generic inference API (Flask default)",
    7860: "Gradio/webui default",
    8888: "Jupyter/notebook default",
}


def is_admin() -> bool:
    """Cross-platform check: root op Linux, Administrator op Windows."""
    try:
        if os.name == "nt":
            return ctypes.windll.shell32.IsUserAnAdmin() != 0
        return os.geteuid() == 0
    except Exception:
        return False


# ──────────────────────────────────────────────────────────────
# Bestandsscan (identiek aan de Linux-versie — geen OS-specifieke code)
# ──────────────────────────────────────────────────────────────

def shannon_entropy(data: bytes) -> float:
    if not data:
        return 0.0
    freq = [0] * 256
    for b in data:
        freq[b] += 1
    length = len(data)
    entropy = 0.0
    for count in freq:
        if count == 0:
            continue
        p = count / length
        entropy -= p * math.log2(p)
    return entropy


def sample_file_entropy(path: Path, block_size=BLOCK_SIZE, max_blocks=SAMPLE_BLOCKS):
    entropies = []
    try:
        size = path.stat().st_size
        with open(path, "rb") as f:
            if size <= block_size * max_blocks:
                data = f.read()
                for i in range(0, len(data), block_size):
                    block = data[i:i + block_size]
                    if block:
                        entropies.append(shannon_entropy(block))
            else:
                step = size // max_blocks
                for i in range(max_blocks):
                    f.seek(i * step)
                    block = f.read(block_size)
                    if block:
                        entropies.append(shannon_entropy(block))
    except (OSError, PermissionError):
        return None, None, 0
    if not entropies:
        return None, None, 0
    return statistics.mean(entropies), (statistics.pstdev(entropies) if len(entropies) > 1 else 0.0), len(entropies)


def read_head(path: Path, n=64):
    try:
        with open(path, "rb") as f:
            return f.read(n)
    except (OSError, PermissionError):
        return b""


def is_gguf(head: bytes) -> bool:
    return head[:4] == GGUF_MAGIC


def looks_like_safetensors(path: Path, head: bytes) -> bool:
    if len(head) < 8:
        return False
    header_len = int.from_bytes(head[:8], "little")
    if header_len <= 0 or header_len > 100_000_000:
        return False
    try:
        with open(path, "rb") as f:
            f.seek(8)
            json_bytes = f.read(min(header_len, 4096))
        return b'"dtype"' in json_bytes and b'"shape"' in json_bytes
    except (OSError, PermissionError, ValueError):
        return False


def classify_file(path: Path, min_size_mb: int):
    try:
        size_mb = path.stat().st_size / (1024 * 1024)
    except (OSError, PermissionError):
        return None
    if size_mb < min_size_mb:
        return None

    head = read_head(path)
    findings = []
    severity = 0

    incomplete_download_extensions = (".part", ".tmp", ".download", ".crdownload")
    incomplete_download = path.suffix.lower() in incomplete_download_extensions

    if is_gguf(head):
        findings.append("GGUF-magic-bytes gedetecteerd (llama.cpp/Ollama modelformaat)")
        severity += 3
        # .part/.tmp/etc. zijn bewust uitgesloten van de vermomd-melding —
        # dat is geen vermommingspoging, gewoon een normale downloadconventie;
        # die krijgen hieronder hun eigen, aparte classificatie.
        if path.suffix.lower() not in (".gguf",) and not incomplete_download:
            findings.append(f"Vermomd bestand: GGUF-signatuur maar extensie is '{path.suffix}'")
            severity += 5

    if looks_like_safetensors(path, head):
        findings.append("SafeTensors-headerstructuur gedetecteerd")
        severity += 3

    # Bekende media-/archiefformaten hebben vaak een entropieprofiel dat
    # sterk lijkt op gekwantiseerde modelgewichten — puur op entropie zonder
    # enig ander signaal is dit een zwak, foutgevoelig kenmerk (bevestigd:
    # Bink-video's (.bik) gaven herhaaldelijk valse meldingen). De
    # GGUF/SafeTensors-checks hierboven blijven wél volledig van kracht,
    # ongeacht extensie.
    KNOWN_NON_MODEL_EXTENSIONS = (
        ".bik", ".mp4", ".mkv", ".avi", ".mov", ".webm", ".wmv",
        ".zip", ".7z", ".rar", ".iso", ".mp3", ".flac", ".ogg",
    )
    has_strong_signal = is_gguf(head) or looks_like_safetensors(path, head)
    mean_e, stddev_e, n_blocks = sample_file_entropy(path)
    if mean_e is not None and 7.15 <= mean_e <= 7.85 and stddev_e is not None and stddev_e < 0.35:
        skip_as_known_media = (
            not has_strong_signal and path.suffix.lower() in KNOWN_NON_MODEL_EXTENSIONS
        )
        if not skip_as_known_media:
            findings.append(
                f"Entropieprofiel past bij gekwantiseerd model-bestand "
                f"(mean={mean_e:.2f} bits/byte, stddev={stddev_e:.3f}, n={n_blocks} blokken)"
            )
            severity += 2

    # Onvoltooide download herkennen: een .part-bestand kan legitiem de
    # GGUF-magic-bytes matchen (de eerste paar KB zijn er al), maar is geen
    # bruikbaar, compleet model — behandel dit als eigen categorie i.p.v.
    # als volwaardige modelvondst.
    if incomplete_download and findings:
        findings.append(
            "Bestandsextensie wijst op een ONVOLTOOIDE DOWNLOAD, niet op een compleet, "
            "bruikbaar model — waarschijnlijk irrelevant voor autorisatie."
        )

    if not findings:
        return None

    return {
        "path": str(path),
        "size_mb": round(size_mb, 1),
        "entropy_mean": round(mean_e, 3) if mean_e else None,
        "entropy_stddev": round(stddev_e, 3) if stddev_e else None,
        "findings": findings,
        "severity": severity,
        "incomplete_download": incomplete_download,
    }


def scan_files(root: Path, min_size_mb: int, follow_symlinks=False):
    results = []
    skipped = 0
    for dirpath, dirnames, filenames in os.walk(root, followlinks=follow_symlinks):
        for fname in filenames:
            fpath = Path(dirpath) / fname
            try:
                result = classify_file(fpath, min_size_mb)
            except Exception:
                skipped += 1
                continue
            if result:
                results.append(result)
    results.sort(key=lambda r: r["severity"], reverse=True)
    return results, skipped


# ──────────────────────────────────────────────────────────────
# Procesanalyse via psutil (i.p.v. /proc)
# ──────────────────────────────────────────────────────────────

def get_loaded_ml_libs(proc):
    found = set()
    try:
        for mmap in proc.memory_maps():
            for pattern in ML_LIB_PATTERNS:
                if pattern.search(mmap.path):
                    found.add(pattern.pattern)
    except (psutil.AccessDenied, psutil.NoSuchProcess, NotImplementedError):
        pass
    return sorted(found)


def scan_processes():
    results = []
    no_access = 0

    for proc in psutil.process_iter(["pid", "name", "cmdline"]):
        try:
            cmdline_list = proc.info["cmdline"] or []
            cmdline = " ".join(cmdline_list) if cmdline_list else (proc.info["name"] or "")
            if not cmdline:
                no_access += 1
                continue

            mem = proc.memory_full_info()
            rss_kb = mem.rss // 1024
            uss_kb = getattr(mem, "uss", mem.rss) // 1024
            ml_libs = get_loaded_ml_libs(proc)

            findings = []
            severity = 0

            if rss_kb >= RSS_SPIKE_THRESHOLD_KB:
                findings.append(
                    f"Groot resident geheugengebruik: {rss_kb / (1024*1024):.1f} GB "
                    f"(past bij geladen LLM-gewichten)"
                )
                severity += 2

            if uss_kb >= USS_THRESHOLD_KB:
                findings.append(
                    f"Grote privé/niet-gedeelde geheugenallocatie (USS): {uss_kb / (1024*1024):.1f} GB"
                )
                severity += 2

            if ml_libs:
                findings.append(f"ML/GPU-bibliotheken geladen: {', '.join(ml_libs)}")
                severity += 3

            innocuous_names = {"svchost", "explorer", "conhost", "services", "csrss", "wininit"}
            proc_name = (proc.info["name"] or "").lower()
            if ml_libs and any(proc_name.startswith(n) for n in innocuous_names):
                findings.append(
                    f"Proces '{proc_name}' claimt systeemtaak te zijn maar laadt ML-bibliotheken — sterk verdacht"
                )
                severity += 5

            if findings:
                results.append({
                    "pid": str(proc.info["pid"]),
                    "cmdline": cmdline[:200],
                    "rss_gb": round(rss_kb / (1024 * 1024), 2),
                    "anon_mmap_gb": round(uss_kb / (1024 * 1024), 2),  # veldnaam behouden voor GUI/correlatie-compatibiliteit
                    "ml_libs": ml_libs,
                    "findings": findings,
                    "severity": severity,
                })

        except (psutil.AccessDenied, psutil.NoSuchProcess, psutil.ZombieProcess):
            no_access += 1
            continue

    results.sort(key=lambda r: r["severity"], reverse=True)
    return results, no_access


# ──────────────────────────────────────────────────────────────
# Netwerkanalyse via psutil (i.p.v. /proc/net + inode-koppeling)
# ──────────────────────────────────────────────────────────────

def scan_network():
    findings = []

    try:
        connections = psutil.net_connections(kind="inet")
    except (psutil.AccessDenied, PermissionError):
        # op sommige Windows-configuraties vereist dit Administrator-rechten
        return findings

    for conn in connections:
        if not conn.laddr or conn.laddr.port not in SUSPECT_PORTS:
            continue

        port = conn.laddr.port
        pid = str(conn.pid) if conn.pid else "onbekend"
        cmdline = ""
        if conn.pid:
            try:
                p = psutil.Process(conn.pid)
                cmdline = " ".join(p.cmdline())[:200]
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass

        is_listening = conn.status == psutil.CONN_LISTEN

        findings.append({
            "port": port,
            "service_guess": SUSPECT_PORTS[port],
            "state": "LISTEN" if is_listening else conn.status,
            "pid": pid,
            "cmdline": cmdline,
            "severity": 3 if is_listening else 1,
        })

    findings.sort(key=lambda f: f["severity"], reverse=True)
    return findings


# ──────────────────────────────────────────────────────────────
# Correlatie (identiek aan de Linux-versie)
# ──────────────────────────────────────────────────────────────

def correlate(file_results, process_results, network_results):
    correlated = []
    proc_by_pid = {p["pid"]: p for p in process_results}
    net_by_pid = {}
    for n in network_results:
        net_by_pid.setdefault(n["pid"], []).append(n)

    for pid, proc in proc_by_pid.items():
        net_hits = net_by_pid.get(pid, [])
        if net_hits:
            combined_severity = proc["severity"] + sum(n["severity"] for n in net_hits)
            reasons = list(proc["findings"])
            for n in net_hits:
                reasons.append(f"Luistert op verdachte poort {n['port']} ({n['service_guess']})")
            correlated.append({
                "pid": pid,
                "cmdline": proc["cmdline"],
                "combined_severity": combined_severity,
                "reasons": reasons,
            })

    correlated.sort(key=lambda c: c["combined_severity"], reverse=True)
    return correlated


def severity_label(score: int) -> str:
    if score >= 8:
        return "KRITIEK"
    if score >= 5:
        return "HOOG"
    if score >= 2:
        return "MIDDEL"
    return "LAAG"


def print_file_report(results, skipped):
    print(f"\n── Bestandsscan ── ({len(results)} treffers, {skipped} overgeslagen)")
    for r in results:
        print(f"  [{severity_label(r['severity'])}] {r['path']} ({r['size_mb']} MB)")
        for f in r["findings"]:
            print(f"      - {f}")


def print_process_report(results, no_access):
    print(f"\n── Processcan ── ({len(results)} treffers, {no_access} zonder toegang)")
    for r in results:
        print(f"  [{severity_label(r['severity'])}] PID {r['pid']}: {r['cmdline'][:80]}")
        for f in r["findings"]:
            print(f"      - {f}")


def print_network_report(results):
    print(f"\n── Netwerkscan ── ({len(results)} treffers)")
    for r in results:
        print(f"  [{severity_label(r['severity'])}] Poort {r['port']} ({r['service_guess']}) — PID {r['pid']}")


def print_correlation_report(correlated):
    print(f"\n── Correlatie (proces + netwerk) ── ({len(correlated)} treffers)")
    for c in correlated:
        print(f"  [{severity_label(c['combined_severity'])}] PID {c['pid']} (score {c['combined_severity']}): {c['cmdline'][:80]}")
        for r in c["reasons"]:
            print(f"      - {r}")


def main():
    parser = argparse.ArgumentParser(description="LLM-botnet-scanner — Windows-versie (psutil-gebaseerd)")
    sub = parser.add_subparsers(dest="command", required=True)

    p_files = sub.add_parser("files", help="Scan bestandssysteem op model-signaturen")
    p_files.add_argument("--path", default=str(Path.home()), help="Startpad voor de scan")
    p_files.add_argument("--min-size", type=int, default=20, help="Minimale bestandsgrootte in MB")

    p_processes = sub.add_parser("processes", help="Scan lopende processen op ML-runtime-fingerprints")
    p_network = sub.add_parser("network", help="Scan netwerkverbindingen op verdachte ML-poorten")

    p_all = sub.add_parser("all", help="Voer alle scans uit en correleer")
    p_all.add_argument("--path", default=str(Path.home()), help="Startpad voor bestandsscan")
    p_all.add_argument("--min-size", type=int, default=20, help="Minimale bestandsgrootte in MB")

    for p in (p_files, p_processes, p_network, p_all):
        p.add_argument("--json", default=None, help="Schrijf volledig rapport als JSON naar dit pad")

    args = parser.parse_args()

    report = {
        "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "hostname": os.environ.get("COMPUTERNAME", os.environ.get("HOSTNAME", "onbekend")),
    }
    t0 = time.time()

    if args.command == "files":
        results, skipped = scan_files(Path(args.path), args.min_size)
        print_file_report(results, skipped)
        report["files"] = results

    elif args.command == "processes":
        results, no_access = scan_processes()
        print_process_report(results, no_access)
        report["processes"] = results

    elif args.command == "network":
        results = scan_network()
        print_network_report(results)
        report["network"] = results

    elif args.command == "all":
        file_results, skipped = scan_files(Path(args.path), args.min_size)
        print_file_report(file_results, skipped)

        proc_results, no_access = scan_processes()
        print_process_report(proc_results, no_access)

        net_results = scan_network()
        print_network_report(net_results)

        correlated = correlate(file_results, proc_results, net_results)
        print_correlation_report(correlated)

        report["files"] = file_results
        report["processes"] = proc_results
        report["network"] = net_results
        report["correlated"] = correlated

    elapsed = time.time() - t0
    print(f"\n── Scan voltooid in {elapsed:.1f}s ──")

    json_path = getattr(args, "json", None)
    if json_path:
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2)
        try:
            import result_integrity as _ri
            _key_dir = os.path.expanduser("~/llm-detect-keys/result-integrity")
            _priv = _ri.get_or_create_signing_key(_key_dir)
            _ri.sign_result_file(json_path, _priv)
        except Exception as _e:
            print(f"[!] Kon resultaat niet ondertekenen ({_e}) — bestand blijft ongesigneerd.")
        print(f"Volledig rapport geschreven naar: {json_path}")

    if not is_admin() and args.command in ("processes", "all"):
        print(
            "\n[!] Let op: niet als Administrator gedraaid — sommige processen kunnen "
            "onzichtbaar/ontoegankelijk zijn. Voor een systeembrede scan: start als Administrator."
        )


if __name__ == "__main__":
    main()
