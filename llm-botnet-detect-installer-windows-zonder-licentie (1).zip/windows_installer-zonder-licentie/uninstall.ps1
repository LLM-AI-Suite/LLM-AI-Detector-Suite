﻿# ==============================================================
# uninstall.ps1 - LLM-Botnet Detection System (Windows)
# ==============================================================
# Removes everything install.ps1 set up: program files, desktop
# shortcut, and launcher script.
#
# By default, KEEPS your data:
#   %USERPROFILE%\llm-detect-keys\     (TPM keys, model registry)
#   %USERPROFILE%\llm-detect-results\  (scan history, calibration data)
# Use -PurgeAll to also remove that data.
#
# NOTE: this script has NOT been executed on a real Windows machine
# (same limitation as install.ps1 - the development environment had
# no access to PowerShell). It has been carefully written to mirror
# install.ps1's exact paths and applies the encoding lessons learned
# from testing install.ps1 (ASCII-only text, UTF-8 BOM). Test on a
# non-critical machine first.
#
# Usage:
#   .\uninstall.ps1              # keeps keys and results
#   .\uninstall.ps1 -PurgeAll    # removes everything
# ==============================================================

param(
    [switch]$PurgeAll
)

try {
    $DetectedLang = (Get-Culture).TwoLetterISOLanguageName
} catch {
    $DetectedLang = "en"
}
if ($DetectedLang -eq "nl") {
    $UiLang = "nl"
} else {
    $UiLang = "en"
}

$T_NL = @{
    title = "LLM-Botnet Detectiesysteem - Verwijderprogramma"
    install_dir = "Installatiemap:"
    results_dir = "Resultatenmap:"
    keys_dir = "Sleutelmap:"
    will_remove = "(wordt VERWIJDERD)"
    will_keep = "(blijft staan)"
    warn_purge_1 = "Je gaf -PurgeAll mee: dit verwijdert ook je TPM-sleutels, modelregistry, en volledige scangeschiedenis."
    warn_purge_2 = "Dit kan niet ongedaan worden gemaakt."
    warn_running = "Als de GUI nu draait (een PowerShell-venster toont 'Running on http://...'), sluit dat venster eerst - bestanden kunnen niet verwijderd worden terwijl ze in gebruik zijn."
    confirm_prompt = "Doorgaan met verwijderen? Typ 'ja' om te bevestigen"
    confirm_word = "ja"
    aborted = "Afgebroken - niets gewijzigd."

    step1 = "Stap 1/4 - Bureaubladsnelkoppeling verwijderen"
    ok_shortcut_removed = "Bureaubladsnelkoppeling verwijderd"
    warn_shortcut_missing = "Bureaubladsnelkoppeling niet gevonden"

    step2 = "Stap 2/4 - Programmabestanden verwijderen"
    ok_removed = "Verwijderd:"
    warn_partial_1 = "Kon niet volledig verwijderen - map is mogelijk nog in gebruik."
    warn_partial_2 = "Sluit alle draaiende GUI-vensters en PowerShell-vensters die deze map gebruiken, en draai dit script opnieuw."
    warn_partial_3 = "Foutmelding:"
    warn_not_exist = "bestond niet"

    step3 = "Stap 3/4 - Configuratie verwijderen"

    step4 = "Stap 4/4 - Data (sleutels + resultaten)"
    ok_data_removed = "Verwijderd:"
    and_word = "en"
    ok_data_kept = "behouden (gebruik -PurgeAll de volgende keer om ook dit te verwijderen)"

    done_title = "Verwijderen voltooid."
    kept_title = "Je sleutels en scangeschiedenis zijn bewaard op:"
    kept_footer = "Draai met -PurgeAll als je die ook wilt verwijderen."
}

$T_EN = @{
    title = "LLM-Botnet Detection System - Uninstaller"
    install_dir = "Install directory:"
    results_dir = "Results directory:"
    keys_dir = "Keys directory:"
    will_remove = "(will be REMOVED)"
    will_keep = "(will be kept)"
    warn_purge_1 = "You passed -PurgeAll: this will also delete your TPM keys, model registry, and full scan history."
    warn_purge_2 = "This cannot be undone."
    warn_running = "If the GUI is currently running (a PowerShell window showing 'Running on http://...'), close that window first - files cannot be removed while in use."
    confirm_prompt = "Continue with uninstall? Type 'yes' to confirm"
    confirm_word = "yes"
    aborted = "Aborted - nothing was changed."

    step1 = "Step 1/4 - Removing desktop shortcut"
    ok_shortcut_removed = "Removed desktop shortcut"
    warn_shortcut_missing = "Desktop shortcut was not found"

    step2 = "Step 2/4 - Removing program files"
    ok_removed = "Removed"
    warn_partial_1 = "Could not fully remove - folder may still be in use."
    warn_partial_2 = "Close any running GUI window and PowerShell windows using this folder, then run this script again."
    warn_partial_3 = "Error:"
    warn_not_exist = "did not exist"

    step3 = "Step 3/4 - Removing configuration"

    step4 = "Step 4/4 - Data (keys + results)"
    ok_data_removed = "Removed"
    and_word = "and"
    ok_data_kept = "kept (use -PurgeAll next time to remove these too)"

    done_title = "Uninstall complete."
    kept_title = "Your keys and scan history were kept at:"
    kept_footer = "Run with -PurgeAll if you want to remove those too."
}

function T($key) {
    if ($UiLang -eq "nl") { return $T_NL[$key] } else { return $T_EN[$key] }
}

# Werkdirectory bewust buiten de installatiemap zetten - dit script kan nu
# vanuit de installatiemap zelf draaien (via de bureaubladsnelkoppeling),
# en Windows kan een map soms niet verwijderen als die de HUIDIGE
# werkdirectory van een lopend proces is, ook al is het script zelf allang
# volledig ingelezen (en dus veilig te verwijderen).
Set-Location $env:TEMP

$InstallDir = "$env:LOCALAPPDATA\llm-botnet-detect"
$ResultsDir = "$env:USERPROFILE\llm-detect-results"
$KeysDir = "$env:USERPROFILE\llm-detect-keys"
$ConfigDir = "$env:USERPROFILE\.llm-detect"
$DesktopShortcut = "$env:USERPROFILE\Desktop\LLM-Botnet Detectie GUI.lnk"

function Step($msg) { Write-Host "`n==> $msg" -ForegroundColor Green }
function Ok($msg) { Write-Host "[OK] $msg" -ForegroundColor Green }
function WarnMsg($msg) { Write-Host "[WARN] $msg" -ForegroundColor Yellow }

Write-Host (T "title") -ForegroundColor Green
Write-Host "=================================================="
Write-Host "$(T 'install_dir') $InstallDir"
if ($PurgeAll) {
    Write-Host "$(T 'results_dir') $ResultsDir $(T 'will_remove')"
    Write-Host "$(T 'keys_dir') $KeysDir $(T 'will_remove')"
} else {
    Write-Host "$(T 'results_dir') $ResultsDir $(T 'will_keep')"
    Write-Host "$(T 'keys_dir') $KeysDir $(T 'will_keep')"
}
Write-Host ""

if ($PurgeAll) {
    WarnMsg (T "warn_purge_1")
    WarnMsg (T "warn_purge_2")
}

WarnMsg (T "warn_running")
$Confirm = Read-Host (T "confirm_prompt")
if ($Confirm -ne (T "confirm_word")) {
    Write-Host (T "aborted")
    exit 0
}

# ==============================================================
# 1. Remove desktop shortcut
# ==============================================================
Step (T "step1")

if (Test-Path $DesktopShortcut) {
    Remove-Item $DesktopShortcut -Force
    Ok (T "ok_shortcut_removed")
} else {
    WarnMsg (T "warn_shortcut_missing")
}

# ==============================================================
# 2. Remove program files
# ==============================================================
Step (T "step2")

if (Test-Path $InstallDir) {
    try {
        Remove-Item $InstallDir -Recurse -Force -ErrorAction Stop
        Ok "$(T 'ok_removed') $InstallDir"
    } catch {
        WarnMsg "$(T 'warn_partial_1')"
        WarnMsg (T "warn_partial_2")
        WarnMsg "$(T 'warn_partial_3') $($_.Exception.Message)"
    }
} else {
    WarnMsg "$InstallDir $(T 'warn_not_exist')"
}

# ==============================================================
# 3. Remove configuration
# ==============================================================
Step (T "step3")

if (Test-Path $ConfigDir) {
    Remove-Item $ConfigDir -Recurse -Force
    Ok "$(T 'ok_removed') $ConfigDir"
} else {
    WarnMsg "$ConfigDir $(T 'warn_not_exist')"
}

# ==============================================================
# 4. Data (keys + results) - kept by default
# ==============================================================
Step (T "step4")

if ($PurgeAll) {
    if (Test-Path $KeysDir) { Remove-Item $KeysDir -Recurse -Force }
    if (Test-Path $ResultsDir) { Remove-Item $ResultsDir -Recurse -Force }
    Ok "$(T 'ok_data_removed') $KeysDir $(T 'and_word') $ResultsDir"
} else {
    Ok "$KeysDir $ResultsDir $(T 'ok_data_kept')"
}

Write-Host ""
Write-Host "==================================================" -ForegroundColor Green
Write-Host (T "done_title") -ForegroundColor Green
Write-Host "==================================================" -ForegroundColor Green
if (-not $PurgeAll) {
    Write-Host ""
    Write-Host (T "kept_title")
    Write-Host "  $KeysDir"
    Write-Host "  $ResultsDir"
    Write-Host (T "kept_footer")
}
