#!/usr/bin/env python3
"""
tpm_model_attestation.py
==========================
Laag 5: hardware-attestatie voor modelauthenticiteit — de langetermijn-
verdediging uit het rapport: "een niet-gesigneerd model kan simpelweg niet
starten op compliant hardware."

Dit simuleert de cryptografische kern van TPM 2.0 remote attestation
(measured boot + PCR-extend + quote + verificatie), zonder een fysieke TPM-
chip nodig te hebben. De cryptografische primitieven (hash-chains, digitale
handtekeningen) zijn identiek aan wat een echte TPM doet — alleen de
hardware-isolatie (private keys die de chip nooit verlaten) ontbreekt
uiteraard in software.

BELANGRIJKE KANTTEKENING:
  Deze sandbox heeft geen TPM-device, geen tpm2-tools en geen swtpm
  (software-TPM-emulator), en geen netwerktoegang om die te installeren.
  Dit script implementeert daarom de PROTOCOLLOGICA in software (met de
  Python 'cryptography'-library) zodat de kernvraag — "detecteert de
  verificatielogica een ongeautoriseerd/vervalst/ingetrokken model correct?"
  — wél volledig getest kan worden. Voor een echte deployment op Ubuntu met
  een fysieke of firmware-TPM vervang je:
    - sign_model/generate_quote  -> tpm2_create + tpm2_sign (AK blijft in de TPM)
    - extend_pcr                 -> tpm2_pcrextend (PCR-registers in de TPM)
    - de quote-productie zelf    -> tpm2_quote (ondertekent PCR-selectie + nonce)
  De verificatielogica (verify_attestation) verandert dan vrijwel niet: die
  controleert alleen handtekeningen en hash-kettingen, wat identiek werkt of
  de sleutel nu in software of in een TPM-chip zit.

Rolverdeling (analoog aan een echte PKI/attestatie-keten):
  - Vendor/model-autoriteit  -> ondertekent legitieme modelhashes (sign_model)
  - Endpoint (TPM)           -> meet wat er daadwerkelijk geladen wordt (extend_pcr)
                                 en ondertekent die meting met de AK (generate_quote)
  - Verifier                 -> controleert of de meting overeenkomt met een
                                 legitiem, niet-ingetrokken, correct ondertekend
                                 model (verify_attestation)

Gebruik:
  python3 tpm_model_attestation.py init-authority --out authority_keys/
  python3 tpm_model_attestation.py init-endpoint --out endpoint_keys/
  python3 tpm_model_attestation.py sign-model --model model.gguf --authority-key authority_keys/private.pem --registry registry.json
  python3 tpm_model_attestation.py revoke --sha256 <hash> --authority-key authority_keys/private.pem --registry registry.json
  python3 tpm_model_attestation.py measure-and-quote --model model.gguf --endpoint-key endpoint_keys/private.pem --out quote.json
  python3 tpm_model_attestation.py verify --quote quote.json --registry registry.json --endpoint-pubkey endpoint_keys/public.pem
"""

import argparse
import hashlib
import json
import os
import sys
import time

from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey, Ed25519PublicKey,
)
from cryptography.hazmat.primitives import serialization
from cryptography.exceptions import InvalidSignature


# ──────────────────────────────────────────────────────────────
# Sleutelbeheer (Ed25519 — analoog aan een TPM AK-sleutelpaar of vendor-CA)
# ──────────────────────────────────────────────────────────────

def generate_keypair(out_dir: str):
    # Tilde ('~') wordt door de shell uitgevouwen, niet door Python — een
    # aanroep vanuit de GUI (die het pad rechtstreeks doorgeeft aan een
    # subprocess-argument, zonder tussenkomst van een shell) laat '~' dus
    # letterlijk staan. Zonder deze regel maakte dit een map genaamd '~' aan
    # in de werkmap, in plaats van in de thuismap van de gebruiker —
    # bevestigd met een echte test.
    out_dir = os.path.expanduser(out_dir)

    # Zelfde vroege waarschuwing als result_integrity.py's
    # get_or_create_signing_key() — een NIEUW TPM-sleutelpaar onder /root/...
    # is bijna altijd een ongeluk (dit commando per ongeluk met sudo
    # gedraaid), niet een bewuste keuze. Dit soort sleutels autoriseert
    # modellen, dus een verwisseling hier is nog vervelender dan bij de
    # resultaat-ondertekeningssleutel: elk daarna gesigneerd model zou
    # onbruikbaar worden zodra het per ongeluk met de verkeerde sleutel
    # gebeurt.
    if os.name != "nt" and hasattr(os, "geteuid") and os.geteuid() == 0 and out_dir.startswith("/root/"):
        print(
            f"[!] WAARSCHUWING: nieuw TPM-sleutelpaar wordt aangemaakt onder {out_dir} "
            f"(root's thuismap) — dit gebeurt meestal per ongeluk, bijv. door dit commando met "
            f"sudo te draaien terwijl dat niet de bedoeling was. Modellen die je hiermee signeert "
            f"zullen niet herkend worden door je eigen, gewone-gebruiker-installatie. "
            f"Draai dit liever zonder sudo.",
            file=sys.stderr,
        )
    os.makedirs(out_dir, exist_ok=True)
    private_key = Ed25519PrivateKey.generate()
    public_key = private_key.public_key()

    priv_bytes = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    pub_bytes = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )

    with open(os.path.join(out_dir, "private.pem"), "wb") as f:
        f.write(priv_bytes)
    with open(os.path.join(out_dir, "public.pem"), "wb") as f:
        f.write(pub_bytes)

    return os.path.join(out_dir, "private.pem"), os.path.join(out_dir, "public.pem")


def load_private_key(path: str) -> Ed25519PrivateKey:
    with open(path, "rb") as f:
        return serialization.load_pem_private_key(f.read(), password=None)


def load_public_key(path: str) -> Ed25519PublicKey:
    with open(path, "rb") as f:
        return serialization.load_pem_public_key(f.read())


# ──────────────────────────────────────────────────────────────
# Hashing
# ──────────────────────────────────────────────────────────────

def sha256_file(path: str, block_size=1024 * 1024) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(block_size):
            h.update(chunk)
    return h.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


# ──────────────────────────────────────────────────────────────
# Model-registry (vendor-ondertekende allowlist — analoog aan een
# code-signing-CA of Secure Boot 'db'-variabele)
# ──────────────────────────────────────────────────────────────

def load_registry(path: str) -> dict:
    if not os.path.exists(path):
        return {"models": [], "revoked": []}
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def save_registry(path: str, registry: dict):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(registry, f, indent=2)


def sign_model(model_path: str, authority_key_path: str, registry_path: str, name: str = None):
    """
    Vendor-actie: registreer en onderteken een legitiem modelbestand.
    De handtekening dekt de sha256-hash van het bestand, zodat elke bit-
    wijziging (of vervanging door een ander bestand met dezelfde naam)
    de handtekening ongeldig maakt.

    Geeft (file_hash, waarschuwing) terug — waarschuwing is None bij een
    plausibel modelbestand, anders een tekst. Blokkeert het signeren zelf
    NIET: dit blijft een bewuste, menselijke actie, en er kunnen legitieme
    redenen zijn om iets ongebruikelijks te signeren. Toegevoegd na een
    reële, verwarrende situatie: /usr/local/bin/ollama (het programma zelf,
    geen model) werd per ongeluk in het modelpad-veld gesigneerd, zonder
    enige waarschuwing dat dit geen plausibel modelbestand leek.
    """
    priv = load_private_key(authority_key_path)
    file_hash = sha256_file(model_path)
    name = name or os.path.basename(model_path)

    waarschuwing = None
    try:
        import llm_botnet_scanner as _lbs
        p = _lbs.Path(model_path)
        head = _lbs.read_head(p)
        if not (_lbs.is_gguf(head) or _lbs.looks_like_safetensors(p, head)):
            waarschuwing = (
                f"'{os.path.basename(model_path)}' lijkt geen GGUF- of SafeTensors-bestand "
                f"(geen herkende magic-bytes/headerstructuur) — controleer of dit daadwerkelijk "
                f"een modelbestand is, en niet bijv. een programma of ander bestandstype."
            )
    except Exception:
        pass  # validatie is puur informatief; mag het signeren zelf nooit blokkeren

    signature = priv.sign(bytes.fromhex(file_hash))

    registry = load_registry(registry_path)
    registry["models"] = [m for m in registry["models"] if m["sha256"] != file_hash]  # dedupe
    registry["models"].append({
        "name": name,
        "sha256": file_hash,
        "signature": signature.hex(),
        "signed_at": time.time(),
        # Bewaard zodat revoke_model() weet WELK bestand op schijf bij deze
        # hash hoort — nodig om leesrechten daadwerkelijk te kunnen intrekken.
        # Rechten zitten op de inode, niet op het pad: als hetzelfde bestand
        # via meerdere paden bereikbaar is (bijv. containerd/Ollama's
        # content-addressed opslag), blokkeert dit ene pad automatisch alle.
        "path": os.path.abspath(os.path.expanduser(model_path)),
    })
    save_registry(registry_path, registry)
    return file_hash, waarschuwing


def revoke_model(sha256_hash: str, authority_key_path: str, registry_path: str, reason: str = "", fallback_path: str = None):
    """
    Vendor-actie: trek een eerder gesigneerd model in (analoog aan een CRL-
    entry). Het model kan legitiem gesigneerd zijn geweest maar bijv. later
    gecompromitteerd/vergiftigd zijn bevonden.

    Trekt SINDS deze bouwronde ook daadwerkelijk de leesrechten in op het
    onderliggende bestand (chmod 000) — de suite was tot dusver uitsluitend
    signalerend; dit is de eerste stap naar daadwerkelijk ingrijpen. Eerlijke
    grens: dit blokkeert alleen TOEKOMSTIGE laadpogingen (een proces dat het
    bestand al in het geheugen heeft, merkt hier niets van), en is met
    voldoende rechten (root) te omzeilen — zie whitepaper 9.13/12 voor de
    volledige afweging. Als het pad niet bekend is (oudere registry-entry
    van vóór deze functie) of het bestand al weg is, wordt dat gemeld maar
    blokkeert het de intrekking zelf niet — de registry-intrekking (het
    signalerende deel) blijft altijd van kracht, ongeacht of de bestands-
    actie lukt.

    fallback_path: voor een model dat NOOIT eerder gesigneerd was (dus geen
    registry-entry met een opgeslagen pad heeft) — bijv. bij automatische
    intrekking vanuit Laag 3's auto-attest, die het pad al direct bij de hand
    heeft uit de eigen detectie. Wordt alleen gebruikt als er geen bestaande
    registry-entry met een pad is; een al-bekend, opgeslagen pad heeft altijd
    voorrang.
    """
    priv = load_private_key(authority_key_path)
    revocation_payload = f"REVOKE:{sha256_hash}".encode()
    signature = priv.sign(revocation_payload)

    registry = load_registry(registry_path)
    registry["revoked"] = [r for r in registry["revoked"] if r["sha256"] != sha256_hash]
    registry["revoked"].append({
        "sha256": sha256_hash,
        "reason": reason,
        "signature": signature.hex(),
        "revoked_at": time.time(),
    })
    save_registry(registry_path, registry)

    file_action = {"attempted": False, "success": False, "detail": "", "effectively_blocked": False}
    model_entry = next((m for m in registry.get("models", []) if m["sha256"] == sha256_hash), None)
    path = model_entry["path"] if (model_entry and model_entry.get("path")) else fallback_path
    if path:
        file_action["attempted"] = True
        if not os.path.exists(path):
            file_action["detail"] = f"Bestand niet gevonden op het opgeslagen pad ({path}) — waarschijnlijk verplaatst/verwijderd."
        else:
            chmod_ok = False
            try:
                os.chmod(path, 0o000)
                chmod_ok = True
                chmod_detail = f"leesrechten ingetrokken op {path}"
            except PermissionError as e:
                chmod_detail = f"leesrechten intrekken mislukt (onvoldoende rechten op dit bestand — normaal voor systeembreed geïnstalleerde bestanden, bijv. Ollama): {e}"

            # AppArmor-laag: aanvullend op chmod, houdt ook stand tegen een
            # lezend proces met root-rechten (chmod alleen doet dat niet).
            # Uitsluitend voor de programma's die de gebruiker expliciet heeft
            # opgegeven onder registry["apparmor_binaries"] — zonder configuratie
            # gebeurt hier niets, chmod blijft dan de enige blokkade.
            apparmor_lines = []
            any_apparmor_ok = False
            for binary in registry.get("apparmor_binaries", []):
                try:
                    import apparmor_enforcement as _aa
                    aa_result = _aa.add_deny_rule_privileged(binary, path)
                    if aa_result["success"]:
                        any_apparmor_ok = True
                    apparmor_lines.append(f"AppArmor ({binary}): {'✅' if aa_result['success'] else '❌'} {aa_result['detail']}")
                except Exception as _e:
                    apparmor_lines.append(f"AppArmor ({binary}): ❌ kon niet worden toegepast ({_e})")

            file_action["success"] = chmod_ok
            file_action["effectively_blocked"] = chmod_ok or any_apparmor_ok

            # Leidende, eerlijke samenvatting in gewone taal, vóór de technische
            # details — zodat 'chmod mislukt' niet ten onrechte als totale
            # mislukking overkomt wanneer AppArmor het model wél al blokkeert
            # (of andersom). De vraag die telt: is het model nú daadwerkelijk
            # geblokkeerd, niet welk specifiek mechanisme dat deed.
            verdict = "🔒 Dit model is nu daadwerkelijk geblokkeerd." if file_action["effectively_blocked"] \
                else "🔓 Let op: geen van de beschikbare mechanismen kon de blokkade toepassen — dit model is NIET geblokkeerd."
            technical = "; ".join([f"chmod: {'✅' if chmod_ok else '❌'} {chmod_detail}"] + apparmor_lines)
            file_action["detail"] = f"{verdict} ({technical})"
    else:
        file_action["detail"] = "Geen bestandspad bekend voor dit model — alleen de registry-intrekking is toegepast."

    return file_action


def unrevoke_model(sha256_hash: str, authority_key_path: str, authority_pubkey_path: str, registry_path: str):
    """
    Vendor-actie: maak een eerdere intrekking ongedaan — het model mag weer
    laden. Vereist BEWUST ook de autoriteitssleutel, en verifieert die
    EXPLICIET tegen de bekende publieke sleutel — in tegenstelling tot
    sign_model/revoke_model (waar een verkeerde sleutel simpelweg een nutteloze,
    later-falende handtekening oplevert), verwijdert deze actie direct een
    entry uit een lijst zonder zelf een handtekening te produceren die later
    nog gecontroleerd wordt. Zonder deze expliciete sleutelcontrole zou WELKE
    GELDIGE ED25519-SLEUTEL DAN OOK (niet per se de juiste) een intrekking
    ongedaan kunnen maken — dit is bij het testen daadwerkelijk aangetroffen
    en hiermee gefixt.

    De registry-intrekking zelf is nooit afhankelijk van het bestand: de
    oorspronkelijke sign-model-handtekening in 'models' blijft ongewijzigd en
    is nog steeds de bron van autorisatie. Sinds revoke_model() ook leesrechten
    intrekt, probeert deze functie die wél te herstellen (chmod 644) als het
    bestand er nog staat — lukt dat niet (bestand weg, onvoldoende rechten),
    dan blijft de registry-kant alsnog hersteld; het bestand kan dan hooguit
    onterecht ontoegankelijk blijven, nooit onterecht weer autoriteit krijgen.
    """
    priv = load_private_key(authority_key_path)
    expected_pub = load_public_key(authority_pubkey_path)

    priv_pub_bytes = priv.public_key().public_bytes(
        encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw
    )
    expected_pub_bytes = expected_pub.public_bytes(
        encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw
    )
    if priv_pub_bytes != expected_pub_bytes:
        raise ValueError(
            "Verkeerde autoriteitssleutel: de opgegeven private key komt niet overeen "
            "met de bekende publieke sleutel. Intrekking NIET ongedaan gemaakt."
        )

    registry = load_registry(registry_path)
    before = len(registry.get("revoked", []))
    registry["revoked"] = [r for r in registry.get("revoked", []) if r["sha256"] != sha256_hash]
    save_registry(registry_path, registry)

    file_action = {"attempted": False, "success": False, "detail": "", "effectively_restored": False}
    model_entry = next((m for m in registry.get("models", []) if m["sha256"] == sha256_hash), None)
    if model_entry and model_entry.get("path"):
        path = model_entry["path"]
        file_action["attempted"] = True
        if not os.path.exists(path):
            file_action["detail"] = f"Bestand niet gevonden op het opgeslagen pad ({path}) — leesrechten kunnen niet hersteld worden, maar de intrekking zelf is wel ongedaan gemaakt."
        else:
            chmod_ok = False
            try:
                os.chmod(path, 0o644)
                chmod_ok = True
                chmod_detail = f"leesrechten hersteld op {path}"
            except PermissionError as e:
                chmod_detail = f"leesrechten herstellen mislukt (onvoldoende rechten): {e}"

            apparmor_lines = []
            all_apparmor_ok = True
            for binary in registry.get("apparmor_binaries", []):
                try:
                    import apparmor_enforcement as _aa
                    aa_result = _aa.remove_deny_rule_privileged(binary, path)
                    if not aa_result["success"]:
                        all_apparmor_ok = False
                    apparmor_lines.append(f"AppArmor ({binary}): {'✅' if aa_result['success'] else '❌'} {aa_result['detail']}")
                except Exception as _e:
                    all_apparmor_ok = False
                    apparmor_lines.append(f"AppArmor ({binary}): ❌ kon niet worden verwijderd ({_e})")

            file_action["success"] = chmod_ok
            # Bewust ANDERS dan revoke_model()'s OR-logica: hier moeten ALLE
            # mechanismen succesvol opgeheven zijn, niet slechts één — een
            # enkele vergeten, achtergebleven AppArmor-regel zou het model
            # anders alsnog stil blokkeren, terwijl de registry en de GUI al
            # 'hersteld' tonen. Bij twijfel liever te voorzichtig melden.
            file_action["effectively_restored"] = chmod_ok and all_apparmor_ok

            verdict = "✅ Dit model is weer volledig toegankelijk." if file_action["effectively_restored"] \
                else "⚠️  Let op: niet alle blokkades konden opgeheven worden — dit model kan alsnog (deels) geblokkeerd blijven."
            technical = "; ".join([f"chmod: {'✅' if chmod_ok else '❌'} {chmod_detail}"] + apparmor_lines)
            file_action["detail"] = f"{verdict} ({technical})"
    else:
        file_action["detail"] = "Geen bestandspad bekend voor dit model — alleen de registry-intrekking is ongedaan gemaakt."

    revoked_removed = before - len(registry["revoked"])  # aantal verwijderde intrekkingen (0 of 1)
    return revoked_removed, file_action


def is_model_authorized(file_hash: str, registry: dict, authority_pubkey: Ed25519PublicKey) -> dict:
    """
    Controleer of een modelhash legitiem gesigneerd is DOOR de opgegeven
    autoriteitssleutel te verifiëren (niet enkel te vertrouwen op wat er in
    het registry-bestand staat — een aanvaller die het JSON-bestand kan
    aanpassen kan geen geldige handtekening vervalsen zonder de private key).
    """
    entry = next((m for m in registry["models"] if m["sha256"] == file_hash), None)
    if entry is None:
        return {"authorized": False, "reason": "Modelhash staat niet in de registry"}

    try:
        authority_pubkey.verify(bytes.fromhex(entry["signature"]), bytes.fromhex(file_hash))
    except InvalidSignature:
        return {"authorized": False, "reason": "Handtekening in registry is ONGELDIG — mogelijk vervalst registry-bestand"}

    revoked_entry = next((r for r in registry.get("revoked", []) if r["sha256"] == file_hash), None)
    if revoked_entry is not None:
        try:
            authority_pubkey.verify(
                bytes.fromhex(revoked_entry["signature"]), f"REVOKE:{file_hash}".encode()
            )
            return {"authorized": False, "reason": f"Model is INGETROKKEN: {revoked_entry.get('reason', '(geen reden opgegeven)')}"}
        except InvalidSignature:
            pass  # ongeldige revocatie-entry negeren, val terug op geldige signing-status

    return {"authorized": True, "reason": f"Geldig gesigneerd als '{entry['name']}'"}


# ──────────────────────────────────────────────────────────────
# Measured boot: PCR-extend keten
# ──────────────────────────────────────────────────────────────

PCR_INITIAL_VALUE = "00" * 32  # analoog aan een TPM-PCR die bij boot op 0 begint


def extend_pcr(current_pcr_hex: str, measurement_hash_hex: str) -> str:
    """
    Simuleert TPM2_PCR_Extend: PCR_nieuw = SHA256(PCR_oud || meting).
    Dit is een cumulatieve, niet-omkeerbare keten — je kunt een eerdere
    meting niet stilletjes vervangen zonder dat de eindwaarde verandert,
    en je kunt de keten niet 'terugdraaien' zonder de eerdere PCR-waarde
    te kennen (one-way hash chain).
    """
    combined = bytes.fromhex(current_pcr_hex) + bytes.fromhex(measurement_hash_hex)
    return hashlib.sha256(combined).hexdigest()


def measure_boot_sequence(runtime_hash: str, model_hash: str, config_hash: str) -> dict:
    """
    Simuleert een measured-boot-log met drie metingen, zoals een TPM tijdens
    het laden van een LLM-inferentie-stack zou opbouwen:
      PCR[0] <- SHA256(0x00...00 || hash(runtime-binary))
      PCR[0] <- SHA256(PCR[0]    || hash(modelbestand))
      PCR[0] <- SHA256(PCR[0]    || hash(configbestand))
    """
    pcr = PCR_INITIAL_VALUE
    log = []
    for label, measurement in [("runtime", runtime_hash), ("model", model_hash), ("config", config_hash)]:
        pcr = extend_pcr(pcr, measurement)
        log.append({"label": label, "measurement": measurement, "pcr_after": pcr})
    return {"final_pcr": pcr, "log": log}


def recompute_pcr_from_log(log: list) -> str:
    """Herberekent de PCR-eindwaarde onafhankelijk vanuit de log — dit is wat
    de verifier doet om te checken dat de log niet gemanipuleerd is."""
    pcr = PCR_INITIAL_VALUE
    for entry in log:
        pcr = extend_pcr(pcr, entry["measurement"])
    return pcr


# ──────────────────────────────────────────────────────────────
# Quote: de TPM ondertekent de PCR-waarde + een nonce (anti-replay)
# ──────────────────────────────────────────────────────────────

def generate_quote(pcr_value_hex: str, endpoint_key_path: str, nonce_hex: str) -> str:
    """
    Simuleert TPM2_Quote: de TPM (via zijn Attestation Key, die de chip nooit
    verlaat) ondertekent de PCR-waarde samen met een door de verifier
    aangeleverde nonce. De nonce voorkomt dat een oude, ooit-geldige quote
    hergebruikt kan worden (replay-attack).
    """
    priv = load_private_key(endpoint_key_path)
    payload = bytes.fromhex(pcr_value_hex) + bytes.fromhex(nonce_hex)
    signature = priv.sign(payload)
    return signature.hex()


def build_attestation_bundle(model_path: str, endpoint_key_path: str, nonce_hex: str,
                               runtime_hash: str = None, config_hash: str = None) -> dict:
    model_hash = sha256_file(model_path)
    runtime_hash = runtime_hash or sha256_bytes(b"llama.cpp-runtime-v1-reference-build")
    config_hash = config_hash or sha256_bytes(b"default-inference-config")

    boot = measure_boot_sequence(runtime_hash, model_hash, config_hash)
    quote_sig = generate_quote(boot["final_pcr"], endpoint_key_path, nonce_hex)

    return {
        "model_path": model_path,
        "model_hash": model_hash,
        "pcr_log": boot["log"],
        "final_pcr": boot["final_pcr"],
        "nonce": nonce_hex,
        "quote_signature": quote_sig,
        "generated_at": time.time(),
    }


# ──────────────────────────────────────────────────────────────
# Verificatie
# ──────────────────────────────────────────────────────────────

def verify_attestation(bundle: dict, registry: dict, authority_pubkey: Ed25519PublicKey,
                         endpoint_pubkey: Ed25519PublicKey, expected_nonce_hex: str) -> dict:
    """
    Volledige verificatieketen, in volgorde van de controles die een echte
    verifier (bijv. Keylime-achtige remote-attestation-server) zou uitvoeren:

      1. Nonce-check       -> is dit een verse quote, geen replay?
      2. PCR-herberekening -> komt de log overeen met de ondertekende PCR-waarde?
      3. Quote-handtekening-> is de PCR-waarde daadwerkelijk door déze endpoint
                              (AK) ondertekend, en niet vervalst?
      4. Model-autorisatie -> is de gemeten modelhash legitiem gesigneerd door
                              de vendor, en niet ingetrokken?
    """
    checks = []
    overall_pass = True

    # 1. Nonce-check
    if bundle["nonce"] != expected_nonce_hex:
        checks.append({"check": "nonce", "pass": False, "detail": "Nonce komt niet overeen — mogelijk replay-attack met een oude quote"})
        overall_pass = False
    else:
        checks.append({"check": "nonce", "pass": True, "detail": "Nonce is vers en verwacht"})

    # 2. PCR-herberekening
    recomputed_pcr = recompute_pcr_from_log(bundle["pcr_log"])
    if recomputed_pcr != bundle["final_pcr"]:
        checks.append({"check": "pcr_log_integrity", "pass": False,
                        "detail": "Herberekende PCR komt niet overeen met de opgegeven PCR — log is gemanipuleerd"})
        overall_pass = False
    else:
        checks.append({"check": "pcr_log_integrity", "pass": True, "detail": "PCR-log is intern consistent"})

    # 3. Quote-handtekening (alleen zinvol als de PCR-log klopt, anders verifiëren
    #    we een handtekening over een waarde die we al weten dat gemanipuleerd is)
    try:
        payload = bytes.fromhex(bundle["final_pcr"]) + bytes.fromhex(bundle["nonce"])
        endpoint_pubkey.verify(bytes.fromhex(bundle["quote_signature"]), payload)
        checks.append({"check": "quote_signature", "pass": True, "detail": "Quote correct ondertekend door endpoint-AK"})
    except InvalidSignature:
        checks.append({"check": "quote_signature", "pass": False, "detail": "Quote-handtekening ONGELDIG — niet door deze endpoint-AK ondertekend"})
        overall_pass = False

    # 4. Model-autorisatie
    model_entry = next((e for e in bundle["pcr_log"] if e["label"] == "model"), None)
    model_hash = model_entry["measurement"] if model_entry else bundle.get("model_hash")
    authz = is_model_authorized(model_hash, registry, authority_pubkey)
    checks.append({"check": "model_authorization", "pass": authz["authorized"], "detail": authz["reason"]})
    if not authz["authorized"]:
        overall_pass = False

    return {
        "overall_pass": overall_pass,
        "checks": checks,
        "model_hash": model_hash,
    }


def print_verification(result: dict):
    verdict = "TOEGESTAAN — model mag laden" if result["overall_pass"] else "GEWEIGERD — model mag NIET laden"
    print(f"\n── Attestatieverificatie ── {verdict}")
    for check in result["checks"]:
        status = "OK" if check["pass"] else "FAIL"
        print(f"  [{status}] {check['check']}: {check['detail']}")


# ──────────────────────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="TPM-attestatie-simulatie voor modelauthenticiteit (laag 5)")
    sub = parser.add_subparsers(dest="command", required=True)

    p_init_auth = sub.add_parser("init-authority", help="Genereer vendor/autoriteits-sleutelpaar")
    p_init_auth.add_argument("--out", required=True)

    p_init_endpoint = sub.add_parser("init-endpoint", help="Genereer endpoint (simuleert TPM AK) sleutelpaar")
    p_init_endpoint.add_argument("--out", required=True)

    p_sign = sub.add_parser("sign-model", help="Vendor ondertekent een legitiem modelbestand")
    p_sign.add_argument("--model", required=True)
    p_sign.add_argument("--authority-key", required=True)
    p_sign.add_argument("--registry", required=True)
    p_sign.add_argument("--name", default=None)

    p_revoke = sub.add_parser("revoke", help="Vendor trekt een eerder gesigneerd model in")
    p_revoke.add_argument("--sha256", required=True)
    p_revoke.add_argument("--authority-key", required=True)
    p_revoke.add_argument("--registry", required=True)
    p_revoke.add_argument("--reason", default="")
    p_revoke.add_argument("--fallback-path", default=None, help="Pad om te blokkeren als er geen bestaande registry-entry met een opgeslagen pad is (bijv. bij automatische intrekking van een nooit eerder gesigneerd model)")

    p_unrevoke = sub.add_parser("unrevoke", help="Vendor maakt een eerdere intrekking ongedaan")
    p_unrevoke.add_argument("--sha256", required=True)
    p_unrevoke.add_argument("--authority-key", required=True)
    p_unrevoke.add_argument("--authority-pubkey", required=True)
    p_unrevoke.add_argument("--registry", required=True)

    p_quote = sub.add_parser("measure-and-quote", help="Endpoint meet een modelload en produceert een quote")
    p_quote.add_argument("--model", required=True)
    p_quote.add_argument("--endpoint-key", required=True)
    p_quote.add_argument("--nonce", default=None, help="Hex-nonce van de verifier; default: willekeurig gegenereerd")
    p_quote.add_argument("--out", required=True)

    p_verify = sub.add_parser("verify", help="Verifier controleert een quote tegen de registry")
    p_verify.add_argument("--quote", required=True)
    p_verify.add_argument("--registry", required=True)
    p_verify.add_argument("--authority-pubkey", required=True)
    p_verify.add_argument("--endpoint-pubkey", required=True)
    p_verify.add_argument("--expected-nonce", required=True)
    p_verify.add_argument("--json", default=None, help="Schrijf verificatieresultaat als JSON naar dit pad (voor correlatie-engine)")

    args = parser.parse_args()

    if args.command == "init-authority":
        priv, pub = generate_keypair(args.out)
        print(f"Autoriteitssleutel aangemaakt: {priv} / {pub}")

    elif args.command == "init-endpoint":
        priv, pub = generate_keypair(args.out)
        print(f"Endpoint-sleutel (simuleert TPM-AK) aangemaakt: {priv} / {pub}")

    elif args.command == "sign-model":
        file_hash, waarschuwing = sign_model(args.model, args.authority_key, args.registry, args.name)
        print(f"Model gesigneerd. SHA256: {file_hash}")
        if waarschuwing:
            print(f"⚠️  {waarschuwing}")

    elif args.command == "revoke":
        file_action = revoke_model(args.sha256, args.authority_key, args.registry, args.reason, fallback_path=args.fallback_path)
        print(f"Model {args.sha256} ingetrokken.")
        if file_action["attempted"]:
            if file_action.get("effectively_blocked", file_action["success"]):
                print(f"✅ {file_action['detail']}")
            else:
                print(f"⚠️  {file_action['detail']}")
        else:
            print(f"ℹ️  {file_action['detail']}")

    elif args.command == "unrevoke":
        n, file_action = unrevoke_model(args.sha256, args.authority_key, args.authority_pubkey, args.registry)
        if n > 0:
            print(f"Model {args.sha256} niet meer ingetrokken — mag weer laden.")
        else:
            print(f"Model {args.sha256} stond niet op de intrekkingslijst (niets gewijzigd).")
        if file_action["attempted"]:
            if file_action.get("effectively_restored", file_action["success"]):
                print(f"✅ {file_action['detail']}")
            else:
                print(f"⚠️  {file_action['detail']}")
        else:
            print(f"ℹ️  {file_action['detail']}")

    elif args.command == "measure-and-quote":
        nonce_hex = args.nonce or os.urandom(16).hex()
        bundle = build_attestation_bundle(args.model, args.endpoint_key, nonce_hex)
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(bundle, f, indent=2)
        print(f"Quote geschreven naar {args.out} (nonce={nonce_hex})")
        try:
            import result_integrity as _ri
            _key_dir = _ri.resolve_key_dir()
            _priv = _ri.get_or_create_signing_key(_key_dir)
            _ri.sign_result_file(args.out, _priv)
        except Exception as _e:
            print(f"[!] Kon resultaat niet ondertekenen ({_e}) — bestand blijft ongesigneerd.")

    elif args.command == "verify":
        with open(args.quote, encoding="utf-8") as f:
            bundle = json.load(f)
        registry = load_registry(args.registry)
        authority_pub = load_public_key(args.authority_pubkey)
        endpoint_pub = load_public_key(args.endpoint_pubkey)
        result = verify_attestation(bundle, registry, authority_pub, endpoint_pub, args.expected_nonce)
        print_verification(result)
        if args.json:
            with open(args.json, "w", encoding="utf-8") as f:
                json.dump(result, f, indent=2)
            try:
                import result_integrity as _ri
                _key_dir = _ri.resolve_key_dir()
                _priv = _ri.get_or_create_signing_key(_key_dir)
                _ri.sign_result_file(args.json, _priv)
            except Exception as _e:
                print(f"[!] Kon resultaat niet ondertekenen ({_e}) — bestand blijft ongesigneerd.")
        sys.exit(0 if result["overall_pass"] else 1)


if __name__ == "__main__":
    main()
