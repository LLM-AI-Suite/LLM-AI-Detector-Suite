#!/usr/bin/env python3
"""
realtime_kernel_agent.py
==========================
Laag 3: realtime procesmonitoring — in tegenstelling tot laag 1 (eenmalige
snapshot) volgt dit script processen continu, waardoor het drie dingen
detecteert die een snapshot mist:

  1. Groeicurves     -> een proces dat plotseling 2-40GB alloceert binnen
                         seconden (model-loading), i.p.v. alleen "is nu groot"
  2. Dynamic loading  -> een proces dat *tijdens* executie een ML/GPU-bibliotheek
                         laadt (dlopen), bijvoorbeeld nadat het zich eerst als
                         onschuldig script heeft voorgedaan — klassiek
                         injectie/dropper-patroon
  3. Procesafstamming -> een ML-bibliotheek die geladen wordt door een proces
                         met een verdachte ouderketen (bijv. gespawnd door een
                         script-interpreter of downloader i.p.v. een normale
                         package-manager/deployment-tool)

BELANGRIJKE KANTTEKENING — eBPF vs. polling:
  Dit script gebruikt polling van /proc (userspace, geen kernel-hooks) omdat
  eBPF-compileertools (clang/LLVM, bcc, bpftrace) niet altijd beschikbaar zijn
  op een target-systeem. Polling heeft een blinde vlek: events die *tussen*
  twee polls beginnen en eindigen worden gemist (bijv. een proces dat in 0.5s
  spawnt, een lib laadt, en weer verdwijnt bij een poll-interval van 2s).

  Voor productie-gebruik op een volledige Ubuntu-machine met devtools is de
  eBPF-equivalent van deze logica:

    - sched_process_exec tracepoint   -> vangt élke execve, geen gaten
    - security_mmap_file LSM-hook     -> vangt élke mmap, incl. dlopen
    - kprobe op do_dlopen / dl_open   -> exacte dlopen-events met libpad
    - sched_process_exit tracepoint   -> vangt korte-levensduur-processen

  Een bpftrace-eenregelaar die het dlopen-signaal (punt 2) direct in de kernel
  vangt zonder polling-gat:

    bpftrace -e '
      uprobe:/lib/x86_64-linux-gnu/libc.so.6:dlopen
      { printf("%d %s %s\n", pid, comm, str(arg0)); }'

  Dit script blijft desondanks waardevol: het werkt overal waar Python draait,
  vereist geen kernel-compileertools, en de detectielogica (groeicurve-
  drempels, lineage-regels) is identiek — alleen de databron verschilt.

Gebruik:
  sudo python3 realtime_kernel_agent.py --duration 60 --interval 2
  sudo python3 realtime_kernel_agent.py --duration 60 --json events.json
"""

import argparse
import hashlib
import json
import os
import re
import signal
import socket
import subprocess
import sys
import time

# Hergebruik van Laag 1's inhoud-gebaseerde detectie (GGUF-magic-bytes,
# SafeTensors-headerstructuur) — nodig omdat Laag 3's eigen, oorspronkelijke
# detectie hieronder uitsluitend op bestandsextensie matcht, en Ollama's
# eigen opslag (kale sha256-hash-namen, geen extensie) daardoor structureel
# nooit gezien werd. Zie get_loaded_model_files() hieronder.
import llm_botnet_scanner as _lbs

# ──────────────────────────────────────────────────────────────
# Signaturen (zelfde als laag 1, hier zelfstandig herhaald)
# ──────────────────────────────────────────────────────────────

ML_LIB_PATTERNS = [
    re.compile(r"libcuda\.so"),
    re.compile(r"libcublas"),
    re.compile(r"libcudnn"),
    re.compile(r"libtorch"),
    re.compile(r"libggml"),
    re.compile(r"libllama"),
    re.compile(r"libnvidia-ml"),
    re.compile(r"libtensorflow"),
    re.compile(r"libonnxruntime"),
]

# Modelbestand-extensies — gebruikt om te herkennen wanneer een proces een
# AI-modelbestand memory-mapt (zichtbaar in /proc/<pid>/maps, net als de
# ML-bibliotheken hierboven). Dit is de brug tussen Laag 3 (gedragsdetectie)
# en Laag 5 (cryptografische autorisatie): een model dat hier opduikt maar
# niet in de Laag 5-registry staat, is een kandidaat voor automatische
# measure-and-quote — zie check_unknown_models() in de Agent-klasse.
MODEL_FILE_PATTERNS = [
    re.compile(r"\.gguf$"),
    re.compile(r"\.safetensors$"),
    re.compile(r"\.ggml$"),
    re.compile(r"\.pt$"),
    re.compile(r"\.pth$"),
    re.compile(r"\.onnx$"),
    re.compile(r"\.bin$"),  # let op: overlapt met andere .bin-bestanden, zie MIN_MODEL_FILE_SIZE_MB
]

# Bekende, legitieme systeembestanden die toevallig op .bin eindigen en door
# hun omvang de MIN_MODEL_FILE_SIZE_MB-drempel kunnen halen — géén modellen,
# gewoon vals-positief door de generieke .bin-extensie. Gevonden in de
# praktijk: APT's eigen pakketcache werd zo als 'onbevoegd model' herkend en
# automatisch ingetrokken, met een echt risico op het breken van apt/dpkg op
# een systeem waar de intrekking (in tegenstelling tot hier) wél zou slagen.
KNOWN_NON_MODEL_BIN_FILES = {
    "/var/cache/apt/pkgcache.bin",
    "/var/cache/apt/srcpkgcache.bin",
}

# .bin is een generieke extensie — pas als "modelbestand" behandelen als het
# ook daadwerkelijk groot genoeg is om een model te kunnen zijn, om te
# voorkomen dat elk willekeurig .bin-bestand (er zijn er veel, voor van
# alles) als vals-positief wordt gezien.
MIN_MODEL_FILE_SIZE_MB = 50

# processen die vaak *legitiem* korte scripts starten, maar waarvan het
# spawnen van een ML-workload direct erna een injectie/dropper-patroon kan zijn
SUSPICIOUS_INTERPRETERS = {"bash", "sh", "python3", "python", "perl", "node", "dash"}

# spawn-patronen die vrijwel nooit legitiem een ML-runtime starten
SUSPICIOUS_DOWNLOADER_PARENTS = {"curl", "wget", "unzip", "tar"}

RSS_SPIKE_DELTA_KB = 2 * 1024 * 1024      # +2 GB binnen één polling-venster
RSS_SPIKE_WINDOW_SEC = 15                  # binnen dit aantal seconden
POLL_INTERVAL_DEFAULT = 2.0


# ──────────────────────────────────────────────────────────────
# /proc hulpfuncties
# ──────────────────────────────────────────────────────────────

def read_proc_file(pid: str, name: str) -> str:
    try:
        with open(f"/proc/{pid}/{name}", "r", errors="replace", encoding="utf-8") as f:
            return f.read()
    except (OSError, PermissionError):
        return ""


def read_cmdline(pid: str) -> str:
    try:
        with open(f"/proc/{pid}/cmdline", "rb") as f:
            raw = f.read()
        return raw.replace(b"\x00", b" ").decode(errors="replace").strip()
    except (OSError, PermissionError):
        return ""


def read_comm(pid: str) -> str:
    return read_proc_file(pid, "comm").strip()


def get_ppid(pid: str) -> str:
    status = read_proc_file(pid, "status")
    for line in status.splitlines():
        if line.startswith("PPid:"):
            return line.split()[1]
    return ""


def get_rss_kb(pid: str) -> int:
    status = read_proc_file(pid, "status")
    for line in status.splitlines():
        if line.startswith("VmRSS:"):
            parts = line.split()
            if len(parts) >= 2:
                return int(parts[1])
    return 0


def get_loaded_libs(pid: str) -> set:
    maps = read_proc_file(pid, "maps")
    libs = set()
    for line in maps.splitlines():
        cols = line.split(maxsplit=5)
        if len(cols) == 6:
            libs.add(cols[5])
    return libs


def get_ml_libs(libs: set) -> set:
    hits = set()
    for lib in libs:
        for pattern in ML_LIB_PATTERNS:
            if pattern.search(lib):
                hits.add(lib)
    return hits


def get_loaded_model_files(libs: set) -> set:
    """
    Zelfde bron als get_ml_libs (/proc/<pid>/maps), maar dan gericht op
    modelbestanden i.p.v. runtime-bibliotheken. Filtert .bin-bestanden op
    grootte om ruis te voorkomen (zie MIN_MODEL_FILE_SIZE_MB).

    Aanvullend: een inhoud-gebaseerde fallback voor bestanden ZONDER enige
    herkende extensie — bevestigd ontbrekend via een echte productietest:
    Ollama's eigen blob-opslag gebruikt kale sha256-hash-bestandsnamen
    (geen '.gguf', geen extensie van welke aard dan ook), waardoor de
    bovenstaande, puur extensie-gebaseerde matching een daadwerkelijk
    geladen Ollama-model structureel nooit kon zien — ook niet als het
    keurig geautoriseerd was. Deze fallback hergebruikt Laag 1's eigen,
    al-geteste inhoud-detectie (GGUF-magic-bytes/SafeTensors-structuur) in
    plaats van dezelfde logica opnieuw te bouwen.
    """
    hits = set()
    for path in libs:
        if path in KNOWN_NON_MODEL_BIN_FILES:
            continue
        matched_by_extension = False
        for pattern in MODEL_FILE_PATTERNS:
            if not pattern.search(path):
                continue
            if pattern.pattern == r"\.bin$":
                try:
                    size_mb = os.path.getsize(path) / (1024 * 1024)
                except OSError:
                    continue
                if size_mb < MIN_MODEL_FILE_SIZE_MB:
                    continue
            hits.add(path)
            matched_by_extension = True
        if matched_by_extension:
            continue

        # Geen enkele extensie matchte — controleer op inhoud, maar
        # uitsluitend voor bestanden die al groot genoeg zijn om een
        # plausibele modelkandidaat te zijn (voorkomt onnodig, herhaald
        # lezen van elk klein, willekeurig extensieloos bestand).
        try:
            if os.path.getsize(path) / (1024 * 1024) < MIN_MODEL_FILE_SIZE_MB:
                continue
        except OSError:
            continue
        p = _lbs.Path(path)
        head = _lbs.read_head(p)
        if _lbs.is_gguf(head) or _lbs.looks_like_safetensors(p, head):
            hits.add(path)
    return hits


def attempt_auto_attestation(model_path: str, endpoint_key: str, registry: str,
                              authority_pubkey: str, endpoint_pubkey: str, quote_dir: str) -> dict:
    """
    Brug tussen Laag 3 (gedragsdetectie) en Laag 5 (cryptografische
    autorisatie): bij een nieuw gedetecteerd modelbestand automatisch een
    measure-and-quote + verify-cyclus starten, i.p.v. te wachten tot een
    gebruiker dit handmatig doet. Dit vangt ook volledig ONBEKENDE modellen
    — Laag 5's doorlopende herverificatie hercontroleerde voorheen alleen
    een reeds-eerder-gemeten model, dit sluit dat gat.

    Faalt bewust GRACEFUL (geeft een status terug, gooit geen exceptie) als
    de sleutels/registry nog niet zijn opgezet — dat is een normale, geen
    foutieve staat vóór de eerste keer dat iemand Laag 5 heeft ingesteld.
    """
    script = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tpm_model_attestation.py")
    python_cmd = sys.executable or "python3"

    if not os.path.isfile(endpoint_key):
        return {"status": "skipped", "reason": "Geen endpoint-sleutel gevonden — Laag 5 is nog niet ingesteld."}
    if not os.path.isfile(registry):
        return {"status": "skipped", "reason": "Geen registry gevonden — Laag 5 is nog niet ingesteld."}

    os.makedirs(quote_dir, exist_ok=True)
    quote_out = os.path.join(quote_dir, f"auto_quote_{int(time.time())}.json")

    try:
        quote_result = subprocess.run(
            [python_cmd, script, "measure-and-quote", "--model", model_path,
             "--endpoint-key", endpoint_key, "--out", quote_out],
            capture_output=True, text=True, timeout=30,
        )
        if quote_result.returncode != 0:
            return {"status": "error", "reason": f"measure-and-quote mislukt: {quote_result.stderr.strip()[:300]}"}

        with open(quote_out, encoding="utf-8") as f:
            quote_data = json.load(f)
        nonce = quote_data.get("nonce")
        if not nonce:
            return {"status": "error", "reason": "Quote-bestand bevat geen nonce — onverwacht formaat."}

        verify_result = subprocess.run(
            [python_cmd, script, "verify", "--quote", quote_out, "--registry", registry,
             "--authority-pubkey", authority_pubkey, "--endpoint-pubkey", endpoint_pubkey,
             "--expected-nonce", nonce],
            capture_output=True, text=True, timeout=30,
        )
        verified = verify_result.returncode == 0
        return {
            "status": "verified" if verified else "unauthorized",
            "quote_path": quote_out,
            "detail": verify_result.stdout.strip()[:500] if verified else verify_result.stderr.strip()[:500],
        }
    except subprocess.TimeoutExpired:
        return {"status": "error", "reason": "Time-out bij measure-and-quote/verify."}
    except Exception as e:
        return {"status": "error", "reason": f"Onverwachte fout: {e}"}


def sha256_file(path: str, block_size=1024 * 1024) -> str:
    """Zelfde implementatie als tpm_model_attestation.py's eigen sha256_file —
    hier lokaal gedupliceerd i.p.v. geïmporteerd, omdat de rest van dit
    bestand tpm_model_attestation.py bewust via subprocess aanroept (nooit
    als module importeert), consistent met attempt_auto_attestation()."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(block_size):
            h.update(chunk)
    return h.hexdigest()


def auto_revoke_unauthorized_model(model_path: str, sha256_hash: str, authority_key: str,
                                    registry: str) -> dict:
    """
    Scope-1-sluitstuk: een 'unauthorized'-detectie leidde tot nu toe alleen tot
    een KRITIEK-melding, nooit tot een daadwerkelijke actie — een mens moest
    de melding zien en zelf in de GUI intrekken. Dit sluit die kloof: bij
    detectie wordt het model automatisch, direct, ook ingetrokken (registry +
    leesrechten via revoke_model()'s bestaande, geteste mechanisme).

    fallback_path is hier essentieel: een model dat nog nooit gesigneerd was
    (de normale reden voor 'unauthorized') heeft geen registry-entry met een
    opgeslagen pad — zonder fallback_path zou de leesrechten-intrekking dus
    niets kunnen blokkeren, alleen de registry bijwerken. We hebben het pad
    hier al uit onze eigen detectie, dus geven we het direct mee.

    Root kan draaien met dit script (systeembrede service), en root kan de
    private key altijd lezen ongeacht bestandsrechten — vandaar dat dit
    zonder aparte rechtenconfiguratie werkt.
    """
    script = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tpm_model_attestation.py")
    python_cmd = sys.executable or "python3"

    if not os.path.isfile(authority_key):
        return {"success": False, "detail": "Geen autoriteitssleutel gevonden — automatische intrekking overgeslagen."}

    try:
        result = subprocess.run(
            [python_cmd, script, "revoke",
             "--sha256", sha256_hash, "--authority-key", authority_key,
             "--registry", registry, "--fallback-path", model_path,
             "--reason", "Automatisch ingetrokken door Laag 3 (auto-attest: unauthorized)"],
            capture_output=True, text=True, timeout=15,
        )
        outcome = {
            "success": result.returncode == 0,
            "detail": result.stdout.strip()[:300] if result.returncode == 0 else result.stderr.strip()[:300],
        }
        # Optie 3: meld dit direct, los van de correlatiescore — als de suite
        # al genoeg vertrouwen had om zelf in te grijpen, hoort de eigenaar
        # dat sowieso te weten. Voorheen moest zo'n geïsoleerde, automatische
        # intrekking wachten op de geplande correlatiecontrole (en de
        # score-drempel daarvan) om zichtbaar te worden.
        if outcome["success"]:
            try:
                import notification_helper as _nh
                _nh.dispatch_notifications(
                    score=100, host=socket.gethostname(),
                    firing_domains=["auto-attest (onbevoegd model automatisch ingetrokken)"],
                    hard_fail=True, findings=[f"Onbevoegd model automatisch ingetrokken: {model_path}"],
                )
            except Exception:
                pass  # een meldingsfout mag de intrekking zelf nooit ongedaan maken
        return outcome
    except subprocess.TimeoutExpired:
        return {"success": False, "detail": "Time-out bij automatische intrekking."}
    except Exception as e:
        return {"success": False, "detail": f"Onverwachte fout bij automatische intrekking: {e}"}


def list_pids() -> list:
    return [p for p in os.listdir("/proc") if p.isdigit()]


# ──────────────────────────────────────────────────────────────
# Procesafstamming
# ──────────────────────────────────────────────────────────────

def build_lineage(pid: str, comm_cache: dict, max_depth=6) -> list:
    """Loop de ouderketen op en geef een lijst van (pid, comm) terug, kind eerst."""
    chain = []
    current = pid
    for _ in range(max_depth):
        comm = comm_cache.get(current) or read_comm(current)
        if not comm:
            break
        chain.append((current, comm))
        ppid = get_ppid(current)
        if not ppid or ppid == "0" or ppid == current:
            break
        current = ppid
    return chain


def lineage_is_suspicious(chain: list) -> str | None:
    """
    Geeft een reden terug als de ouderketen verdacht is voor een proces dat
    een ML-workload draait, anders None.
    """
    ancestor_comms = [comm for _, comm in chain[1:]]  # exclusief het proces zelf
    for comm in ancestor_comms:
        if comm in SUSPICIOUS_DOWNLOADER_PARENTS:
            return f"Gespawnd (indirect) door downloader-tool '{comm}' — past bij drop-and-execute"
    for comm in ancestor_comms:
        if comm in SUSPICIOUS_INTERPRETERS:
            return f"Gespawnd via script-interpreter '{comm}' vóór ML-library-load — mogelijk injectie/dropper"
    return None


# ──────────────────────────────────────────────────────────────
# State tracking over polling-rondes
# ──────────────────────────────────────────────────────────────

class ProcessState:
    def __init__(self, pid, ts, rss_kb, libs, comm, ppid, cmdline):
        self.pid = pid
        self.first_seen = ts
        self.rss_history = [(ts, rss_kb)]
        self.libs_seen = set(libs)
        self.comm = comm
        self.ppid = ppid
        self.cmdline = cmdline
        self.reported_growth = False
        self.reported_libs = set()
        self.reported_lineage = False
        self.reported_model_files = set()

    def update(self, ts, rss_kb, libs):
        self.rss_history.append((ts, rss_kb))
        # houd alleen recente geschiedenis bij (venster + marge)
        cutoff = ts - RSS_SPIKE_WINDOW_SEC * 3
        self.rss_history = [(t, r) for t, r in self.rss_history if t >= cutoff]
        new_libs = libs - self.libs_seen
        self.libs_seen |= libs
        return new_libs

    def rss_growth_in_window(self, now_ts):
        recent = [(t, r) for t, r in self.rss_history if now_ts - t <= RSS_SPIKE_WINDOW_SEC]
        if len(recent) < 2:
            return 0
        return max(r for _, r in recent) - min(r for _, r in recent)


# ──────────────────────────────────────────────────────────────
# Hoofdlus
# ──────────────────────────────────────────────────────────────

class Agent:
    def __init__(self, interval, duration, json_path, flush_interval=60, auto_attest=True):
        self.interval = interval
        self.duration = duration
        self.json_path = json_path
        self.flush_interval = flush_interval
        self.states = {}
        self.events = []
        self.running = True
        self.auto_attest = auto_attest
        # Standaard sleutel-/registrylocaties — consistent met de rest van
        # het project (zie llm_detect_gui.py, tpm_model_attestation.py).
        #
        # BELANGRIJK: dit gebruikte lange tijd kaal os.path.expanduser("~"),
        # zonder omgevingsvariabele-overschrijving — in tegenstelling tot
        # result_integrity.resolve_key_dir(), die dit al wél deed voor de
        # ondertekeningssleutel specifiek. Voor Laag 3 (draait als root via
        # systemd) betekende dit dat authority_pubkey, endpoint_pubkey,
        # registry, én quote_dir allemaal naar /root/llm-detect-keys/...
        # wezen — nooit naar de echte, installerende gebruiker. Auto-attest
        # kon zo structureel nooit de echte, correct gesigneerde modellen
        # herkennen. Bevestigd met een directe test; gerepareerd door hier
        # ook eerst een omgevingsvariabele te controleren, net als
        # resolve_key_dir() al deed — zie install.sh/update.sh voor waar
        # deze nu expliciet gezet wordt in de root-draaiende services.
        keys_base = os.environ.get("LLM_DETECT_KEYS_BASE") or os.path.expanduser("~/llm-detect-keys")
        self.endpoint_key = os.path.join(keys_base, "endpoint_keys", "private.pem")
        self.endpoint_pubkey = os.path.join(keys_base, "endpoint_keys", "public.pem")
        self.authority_key = os.path.join(keys_base, "authority_keys", "private.pem")
        self.authority_pubkey = os.path.join(keys_base, "authority_keys", "public.pem")
        self.registry = os.path.join(keys_base, "registry.json")
        self.quote_dir = os.path.join(keys_base, "auto_quotes")

    def stop(self, *_):
        self.running = False

    def write_json(self):
        if self.json_path:
            # De hele schrijf+onderteken-cyclus onder één exclusieve lock,
            # zodat een lezer (correlatie-engine, dashboard) nooit het
            # tussenliggende moment kan treffen waarop de inhoud al vervangen
            # is maar de handtekening nog niet — dat gaf eerder een vals
            # 'tampered'-resultaat op een continu bijgewerkt bestand als dit.
            # Het lock-bestand is bewust apart van het JSON-bestand zelf,
            # want dat laatste wordt via os.replace() vervangen (nieuwe
            # inode) — een lock daarop zou dan verweesd raken. De
            # cross-platform lock-helpers komen uit result_integrity.py,
            # zodat dezelfde logica ook op Windows werkt (msvcrt i.p.v.
            # fcntl) zonder dat hier apart onderhouden te hoeven worden.
            import result_integrity as _ri
            lock_path = f"{self.json_path}.lock"
            lock_file = open(lock_path, "a+b")
            if os.path.getsize(lock_path) == 0:
                lock_file.write(b"0")
                lock_file.flush()
            lock_file.seek(0)
            _ri._lock_exclusive(lock_file)
            try:
                tmp_path = f"{self.json_path}.tmp"
                with open(tmp_path, "w", encoding="utf-8") as f:
                    json.dump(self.events, f, indent=2)
                os.replace(tmp_path, self.json_path)
                try:
                    _key_dir = _ri.resolve_key_dir()
                    _priv = _ri.get_or_create_signing_key(_key_dir)
                    _ri.sign_result_file(self.json_path, _priv)
                except Exception as _e:
                    print(f"[!] Kon resultaat niet ondertekenen ({_e}) — bestand blijft ongesigneerd.")
            finally:
                _ri._unlock(lock_file)
                lock_file.close()

    def emit(self, severity, pid, comm, cmdline, message):
        event = {
            "ts": round(time.time(), 2),
            "severity": severity,
            "pid": pid,
            "comm": comm,
            "cmdline": cmdline[:200],
            "message": message,
        }
        self.events.append(event)
        print(f"  [{severity}] PID {pid} ({comm})  {message}")

    def poll_once(self):
        ts = time.time()
        current_pids = set(list_pids())
        comm_cache = {}

        for pid in current_pids:
            comm = read_comm(pid)
            comm_cache[pid] = comm
            if not comm:
                continue

            rss_kb = get_rss_kb(pid)
            all_libs = get_loaded_libs(pid)
            ml_libs = get_ml_libs(all_libs)
            model_files = get_loaded_model_files(all_libs)
            cmdline = read_cmdline(pid) or comm

            if pid not in self.states:
                self.states[pid] = ProcessState(
                    pid, ts, rss_kb, ml_libs, comm, get_ppid(pid), cmdline
                )
                new_ml_libs = ml_libs
            else:
                state = self.states[pid]
                new_ml_libs = state.update(ts, rss_kb, ml_libs)
                state = self.states[pid]

            state = self.states[pid]

            # ── Signaal 1: groeicurve ──
            growth = state.rss_growth_in_window(ts)
            if growth >= RSS_SPIKE_DELTA_KB and not state.reported_growth:
                state.reported_growth = True
                self.emit(
                    "HOOG", pid, comm, cmdline,
                    f"Acute geheugengroei: +{growth / (1024*1024):.2f} GB binnen "
                    f"{RSS_SPIKE_WINDOW_SEC}s — past bij model-loading"
                )

            # ── Signaal 2: dynamic library loading tijdens executie ──
            newly_loaded = new_ml_libs - state.reported_libs
            if newly_loaded:
                state.reported_libs |= newly_loaded
                elapsed = ts - state.first_seen
                self.emit(
                    "HOOG", pid, comm, cmdline,
                    f"ML/GPU-bibliotheek dynamisch geladen ({elapsed:.1f}s na eerste observatie): "
                    f"{', '.join(sorted(newly_loaded))}"
                )

                # ── Signaal 3: procesafstamming, alleen relevant als er net een ML-lib bijkwam ──
                chain = build_lineage(pid, comm_cache)
                reason = lineage_is_suspicious(chain)
                if reason and not state.reported_lineage:
                    state.reported_lineage = True
                    chain_str = " ← ".join(f"{c}({p})" for p, c in chain)
                    self.emit(
                        "KRITIEK", pid, comm, cmdline,
                        f"{reason}. Ouderketen: {chain_str}"
                    )

            # ── Signaal 4: nieuw modelbestand -> brug naar Laag 5 (standaard AAN, --no-auto-attest om uit te zetten) ──
            new_model_files = model_files - state.reported_model_files
            if new_model_files:
                state.reported_model_files |= new_model_files
                if self.auto_attest:
                    for model_path in sorted(new_model_files):
                        result = attempt_auto_attestation(
                            model_path, self.endpoint_key, self.registry,
                            self.authority_pubkey, self.endpoint_pubkey, self.quote_dir,
                        )
                        if result["status"] == "verified":
                            self.emit(
                                "INFO", pid, comm, cmdline,
                                f"Nieuw modelbestand automatisch geverifieerd en toegestaan: {model_path}"
                            )
                        elif result["status"] == "unauthorized":
                            revoke_result = auto_revoke_unauthorized_model(
                                model_path, sha256_file(model_path), self.authority_key, self.registry
                            )
                            action_note = (
                                f" — automatisch ingetrokken ({revoke_result['detail']})"
                                if revoke_result["success"]
                                else f" — automatische intrekking mislukt ({revoke_result['detail']})"
                            )
                            self.emit(
                                "KRITIEK", pid, comm, cmdline,
                                f"Nieuw modelbestand NIET geautoriseerd (niet in registry of ingetrokken): {model_path} — {result.get('detail', '')}{action_note}"
                            )
                        elif result["status"] == "skipped":
                            self.emit(
                                "INFO", pid, comm, cmdline,
                                f"Nieuw modelbestand gezien, automatische attestatie overgeslagen: {model_path} ({result['reason']})"
                            )
                        else:
                            self.emit(
                                "AANDACHT", pid, comm, cmdline,
                                f"Nieuw modelbestand gezien, automatische attestatie mislukte: {model_path} ({result.get('reason', 'onbekende fout')})"
                            )
                else:
                    self.emit(
                        "INFO", pid, comm, cmdline,
                        f"Nieuw modelbestand gezien (--no-auto-attest actief, geen actie ondernomen): {', '.join(sorted(new_model_files))}"
                    )

        # opruimen van verdwenen processen
        for pid in list(self.states.keys()):
            if pid not in current_pids:
                del self.states[pid]

    def run(self):
        signal.signal(signal.SIGINT, self.stop)
        signal.signal(signal.SIGTERM, self.stop)

        print(f"── Realtime kernel-agent gestart (interval={self.interval}s, duur={self.duration}s) ──")
        print("   Ctrl+C om te stoppen.\n")

        start = time.time()
        last_flush = start
        while self.running and (time.time() - start) < self.duration:
            self.poll_once()
            if time.time() - last_flush >= self.flush_interval:
                self.write_json()
                last_flush = time.time()
            time.sleep(self.interval)

        print(f"\n── Agent gestopt na {time.time() - start:.1f}s. {len(self.events)} events gelogd. ──")

        self.write_json()
        if self.json_path:
            print(f"Events geschreven naar: {self.json_path}")


def main():
    parser = argparse.ArgumentParser(description="Realtime kernel-adjacent monitoring agent (laag 3)")
    parser.add_argument("--interval", type=float, default=POLL_INTERVAL_DEFAULT, help="Polling-interval in seconden")
    parser.add_argument("--duration", type=float, default=60, help="Totale looptijd in seconden")
    parser.add_argument("--json", default=None, help="Schrijf events als JSON naar dit pad")
    parser.add_argument("--flush-interval", type=float, default=60,
                         help="Bij lange/continue runs (bijv. als systemd-service): schrijf het JSON-bestand "
                              "elke N seconden tussentijds weg, i.p.v. alleen bij het einde. Belangrijk voor "
                              "productie-inzet waarbij de agent nooit stopt — zonder dit zou het resultaatbestand "
                              "nooit gevuld raken zolang de service draait.")
    parser.add_argument("--no-auto-attest", action="store_true",
                         help="Schakel de automatische koppeling van nieuw gedetecteerde modelbestanden aan "
                              "Laag 5 UIT. Sinds deze versie staat dit standaard AAN — een niet-geautoriseerd "
                              "model dat laadt en binnen het reguliere hercontrole-venster weer verdwijnt, "
                              "werd anders alleen als INFO gelogd (geen alarm, geen verhoogde correlatiescore). "
                              "Gebruik deze vlag alleen als je bewust minder streng wilt zijn, of als Laag 5's "
                              "sleutels bewust nog niet zijn opgezet en je de INFO-meldingen liever niet ziet.")
    args = parser.parse_args()

    agent = Agent(args.interval, args.duration, args.json, args.flush_interval, not args.no_auto_attest)
    agent.run()

    if os.geteuid() != 0:
        print(
            "\n[!] Let op: niet als root gedraaid — alleen processen van de huidige "
            "gebruiker zijn volledig inspecteerbaar. Voor systeembrede monitoring: sudo."
        )


if __name__ == "__main__":
    main()
