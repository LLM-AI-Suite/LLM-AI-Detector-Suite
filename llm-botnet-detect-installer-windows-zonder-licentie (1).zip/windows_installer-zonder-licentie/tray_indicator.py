"""
tray_indicator.py — systemtray-icoon dat toont of de GUI-service draait.

Dit is een APARTE, lichte companion-app, geen onderdeel van de GUI-service
zelf. Detectie gebeurt door periodiek te controleren of er iets op poort
5000 luistert (HTTP of HTTPS, afhankelijk van de geconfigureerde
TLS-modus) — dit werkt ongeacht HOE de GUI gestart is (systemd-service op
Linux, handmatig via start-gui.ps1 op Windows, of gewoon 'python3
llm_detect_gui.py' direct), zonder platform-specifieke proces-detectie
nodig te hebben.

Belangrijke ontwerpkeuze: 'Afsluiten' in het tray-menu sluit ALLEEN dit
tray-icoontje af, niet de onderliggende GUI-service — een klein
statusicoontje mag nooit een onbedoelde manier worden om de beveiligings-
tool zelf uit te zetten.
"""

import http.client
import os
import socket
import threading
import time
import webbrowser

from PIL import Image, ImageDraw
import pystray

CHECK_INTERVAL_SECONDS = 8
PORT = 5000


def _get_tls_mode() -> str:
    return os.environ.get("LLM_GUI_TLS_MODE", "https").strip().lower()


def _is_gui_running() -> bool:
    """
    Probeert een minimale verbinding te maken met de GUI-poort. Geen
    inhoudelijke check nodig (geen inloggegevens vereist) — puur "luistert
    hier iets" is genoeg om de status te tonen.

    Gebruikt een kale TCP-verbinding (socket.connect), GEEN HTTP-aanvraag —
    een HEAD-verzoek gaat namelijk gewoon door de authenticatielaag van de
    GUI heen (401 zonder inloggegevens), wat elke paar seconden meetelde
    voor de rate-limiter en zo een vals "te veel mislukte pogingen" kon
    veroorzaken voor de gebruiker zelf. Puur verbinden en meteen weer
    sluiten omzeilt dat volledig, en is precies genoeg voor deze check.
    """
    try:
        with socket.create_connection(("127.0.0.1", PORT), timeout=2):
            pass
        return True
    except (OSError, socket.timeout):
        return False


def _make_icon_image(color: str) -> Image.Image:
    """Genereert een simpele gekleurde cirkel als tray-icoon — geen los icoonbestand nodig."""
    size = 64
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    margin = 8
    draw.ellipse((margin, margin, size - margin, size - margin), fill=color)
    return img


_ICON_RUNNING = _make_icon_image("#0f6e5c")   # groen — draait
_ICON_STOPPED = _make_icon_image("#c0392b")   # rood — draait niet
_ICON_UNKNOWN = _make_icon_image("#999999")   # grijs — nog aan het checken


def _open_dashboard(icon=None, item=None):
    tls_mode = _get_tls_mode()
    protocol = "http" if tls_mode == "tailscale-only" else "https"
    webbrowser.open(f"{protocol}://localhost:{PORT}")


def _quit_tray(icon=None, item=None):
    """Sluit ALLEEN het tray-icoontje — de GUI-service blijft gewoon draaien."""
    icon.stop()


def _status_text(running: bool) -> str:
    if running:
        return "LLM-Botnet Detectie — actief"
    return "LLM-Botnet Detectie — NIET actief"


def _background_status_loop(icon: pystray.Icon):
    while True:
        running = _is_gui_running()
        icon.icon = _ICON_RUNNING if running else _ICON_STOPPED
        icon.title = _status_text(running)
        time.sleep(CHECK_INTERVAL_SECONDS)


def main():
    menu = pystray.Menu(
        pystray.MenuItem("Open dashboard", _open_dashboard, default=True),
        pystray.MenuItem("Afsluiten (alleen dit icoontje)", _quit_tray),
    )
    icon = pystray.Icon(
        "llm-botnet-detect",
        icon=_ICON_UNKNOWN,
        title="LLM-Botnet Detectie — status controleren...",
        menu=menu,
    )
    threading.Thread(target=_background_status_loop, args=(icon,), daemon=True).start()
    icon.run()


if __name__ == "__main__":
    main()
