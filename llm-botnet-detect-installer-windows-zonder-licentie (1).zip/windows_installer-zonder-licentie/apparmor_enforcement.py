#!/usr/bin/env python3
"""
AppArmor-gebaseerde handhaving — de kernelniveau-aanvulling op revoke_model()'s
chmod-blokkade uit tpm_model_attestation.py.

WAAROM DIT BESTAAT
------------------
De chmod-blokkade (0o000 op het onderliggende bestand) is een DAC-maatregel
(discretionary access control) — een proces met root-rechten leest het
bestand gewoon, ongeacht de rechten. Bij productietesten bleek dit precies
het geval: een systeembreed geïnstalleerde Ollama (/usr/share/ollama/...)
bleef na intrekking van al zijn modelbestanden gewoon werken. AppArmor is
een MAC-systeem (mandatory access control) — het opereert op een andere,
hogere laag dan bestandsrechten, en een 'deny'-regel daarin geldt ook voor
root. Dat is het hele verschil, en de hele reden voor dit bestand.

ONTWERPKEUZE — ZO BREED MOGELIJK TOESTAAN, ALLEEN GERICHT WEIGEREN
-------------------------------------------------------------------
Een volledig, streng confinement-profiel voor een willekeurig programma
handmatig samenstellen is risicovol: elke vergeten, noodzakelijke
toestemming breekt het programma. Daarom kiest dit bestand bewust voor het
andere uiterste: het gegenereerde profiel staat vrijwel alles toe (file,
capability, network, signal, ptrace — breed, niet fijnmazig), en voegt
UITSLUITEND gerichte 'deny'-regels toe voor specifiek ingetrokken
modelpaden. AppArmor's eigen regel is dat 'deny' altijd wint, ongeacht hoe
breed de rest van het profiel toestaat — dus dit blijft een echte,
werkende blokkade, met een veel kleiner risico op nevenschade dan een
streng, fijnmazig profiel.

EERLIJKE GRENS, EXPLICIET
--------------------------
Dit bestand kon niet tegen een echte, actieve AppArmor-kernelmodule getest
worden (niet beschikbaar in de ontwikkelomgeving — gebruikelijk voor
containers). De profielgeneratie zelf (bestandsinhoud, regelstructuur) is
wel getest. Vóór dit in productie te vertrouwen: eerst handmatig verifiëren
op een echte machine dat het doelprogramma na profiel-laden nog normaal
functioneert, en dat een gerichte intrekking het daadwerkelijk blokkeert.
"""
import os
import re
import subprocess
import sys


PROFILE_DIR = "/etc/apparmor.d"
MARKER_START = "    # LLM-DETECT-GUARD:BEGIN-AUTOGEN — wijzig niet handmatig, wordt overschreven"
MARKER_END = "    # LLM-DETECT-GUARD:END-AUTOGEN"


def is_apparmor_available() -> bool:
    """Bevestigt zowel de tooling (apparmor_parser) als de actieve kernel-
    module — beide zijn nodig; op veel systemen (waaronder de meeste
    containers) ontbreekt de kernelmodule ook als de tooling wel
    geïnstalleerd is."""
    has_parser = subprocess.run(
        ["which", "apparmor_parser"], capture_output=True
    ).returncode == 0
    has_kernel_module = os.path.isdir("/sys/kernel/security/apparmor")
    return has_parser and has_kernel_module


def _profile_name_for_binary(binary_path: str) -> str:
    """Ubuntu-conventie: bestandsnaam = absoluut pad met '/' -> '.', geen
    leidende punt. Bijv. /usr/bin/ollama -> usr.bin.ollama."""
    return binary_path.strip("/").replace("/", ".")


def _profile_path_for_binary(binary_path: str) -> str:
    return os.path.join(PROFILE_DIR, _profile_name_for_binary(binary_path))


def _base_profile_text(binary_path: str) -> str:
    name = _profile_name_for_binary(binary_path)
    return f"""# Automatisch beheerd door de LLM-Botnet-Detectiesuite (apparmor_enforcement.py).
# Doel: {binary_path} mag vrijwel alles — dit profiel voegt uitsluitend
# gerichte weigeringen toe voor specifiek ingetrokken modelbestanden.
# Verwijder dit bestand handmatig (en herlaad AppArmor) om de confinement
# volledig ongedaan te maken.
abi <abi/4.0>,
#include <tunables/global>

profile llm-detect-guard-{name} "{binary_path}" flags=(attach_disconnected,complain) {{
  #include <abstractions/base>
  file,
  capability,
  network,
  signal,
  ptrace,
  mount,
  umount,
  pivot_root,

{MARKER_START}
{MARKER_END}
}}
"""


def ensure_profile_exists(binary_path: str) -> str:
    """Maakt een breed-toestaand basisprofiel aan als er nog geen bestaat.
    Bewust gestart in 'complain'-modus (logt overtredingen, blokkeert nog
    niet) — een profiel dat je nog nooit tegen het echte programma testte,
    hoort niet meteen in 'enforce' te draaien. Zie handmatige stap
    hieronder om over te schakelen zodra bevestigd is dat het programma
    normaal blijft functioneren."""
    os.makedirs(PROFILE_DIR, exist_ok=True)
    path = _profile_path_for_binary(binary_path)
    if not os.path.isfile(path):
        with open(path, "w", encoding="utf-8") as f:
            f.write(_base_profile_text(binary_path))
    return path


def _reload_profile(profile_path: str) -> dict:
    if not is_apparmor_available():
        return {
            "success": False,
            "detail": "AppArmor niet beschikbaar op dit systeem (tooling en/of kernelmodule ontbreekt) — profiel aangepast maar niet herladen.",
        }
    result = subprocess.run(
        ["apparmor_parser", "-r", profile_path], capture_output=True, text=True, timeout=15
    )
    if result.returncode == 0:
        return {"success": True, "detail": f"Profiel herladen: {profile_path}"}
    return {"success": False, "detail": f"Herladen mislukt: {result.stderr.strip()[:300]}"}


def add_deny_rule(binary_path: str, file_path: str) -> dict:
    """Voegt een gerichte 'deny read'-regel toe voor file_path aan het
    profiel van binary_path, en herlaadt het profiel. Idempotent — een
    reeds aanwezige regel voor hetzelfde pad wordt niet gedupliceerd."""
    # Nu deze functie ook via een sudo-verhoogd pad aangeroepen kan worden
    # (add_deny_rule_privileged()), is een pad met een aanhalingsteken of
    # regeleinde niet langer alleen een curiositeit: het zou de AppArmor-
    # regelsyntax kunnen doorbreken en een extra, ongecontroleerde regel in
    # een root-eigen profiel kunnen injecteren. Vroegtijdig, hard afwijzen.
    if '"' in file_path or "\n" in file_path or "\r" in file_path:
        return {"success": False, "detail": f"Ongeldig pad geweigerd (bevat aanhalingsteken of regeleinde): {file_path!r}"}

    profile_path = ensure_profile_exists(binary_path)
    with open(profile_path, encoding="utf-8") as f:
        content = f.read()

    escaped_path = re.escape(file_path)
    deny_line = f'  deny "{file_path}" r,'
    if re.search(rf'deny\s+"?{escaped_path}"?\s+r,', content):
        return _reload_profile(profile_path)  # al aanwezig, alleen zeker herladen

    if MARKER_START not in content:
        return {"success": False, "detail": f"Kon markeerpunt niet vinden in {profile_path} — is dit bestand handmatig aangepast?"}

    content = content.replace(MARKER_START, f"{MARKER_START}\n{deny_line}")
    with open(profile_path, "w", encoding="utf-8") as f:
        f.write(content)

    return _reload_profile(profile_path)


def remove_deny_rule(binary_path: str, file_path: str) -> dict:
    """Tegenhanger van add_deny_rule() — verwijdert de weigeringsregel voor
    file_path (bij unrevoke_model()) en herlaadt het profiel."""
    profile_path = _profile_path_for_binary(binary_path)
    if not os.path.isfile(profile_path):
        return {"success": True, "detail": "Geen profiel aanwezig — niets te verwijderen."}

    with open(profile_path, encoding="utf-8") as f:
        lines = f.readlines()

    escaped_path = re.escape(file_path)
    pattern = re.compile(rf'^\s*deny\s+"?{escaped_path}"?\s+r,\s*$')
    new_lines = [ln for ln in lines if not pattern.match(ln.rstrip("\n"))]

    if len(new_lines) == len(lines):
        return {"success": True, "detail": "Geen weigeringsregel gevonden voor dit pad — niets te verwijderen."}

    with open(profile_path, "w", encoding="utf-8") as f:
        f.writelines(new_lines)

    return _reload_profile(profile_path)


def _run_privileged_via_sudo(subcommand: str, binary_path: str, file_path: str) -> dict:
    """Roept dit script zelf aan via 'sudo', voor het geval het HUIDIGE
    proces geen root is (bijv. de GUI, die handmatige intrekkingen als
    gewone gebruiker afhandelt). Vereist een specifiek, beperkt sudoers-
    recht (zie install.sh) dat UITSLUITEND dit ene script zonder wachtwoord
    toestaat — niet een algemene shell. Zonder dat sudoers-recht faalt dit
    met een duidelijke foutmelding in plaats van een wachtwoordprompt die
    in een niet-interactieve GUI-context toch nooit beantwoord kan worden.
    """
    script_path = os.path.abspath(__file__)
    try:
        result = subprocess.run(
            ["sudo", "-n", "/usr/bin/python3", script_path, subcommand,
             "--binary", binary_path, "--file", file_path],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode == 0:
            return {"success": True, "detail": result.stdout.strip()}
        return {
            "success": False,
            "detail": f"sudo-aanroep mislukt (is het sudoers-recht uit install.sh aanwezig?): {result.stderr.strip()[:300]}",
        }
    except subprocess.TimeoutExpired:
        return {"success": False, "detail": "Time-out bij de sudo-aanroep."}
    except FileNotFoundError:
        return {"success": False, "detail": "sudo niet gevonden op dit systeem."}


def add_deny_rule_privileged(binary_path: str, file_path: str) -> dict:
    """Bevoegdheid-bewuste variant van add_deny_rule(): draait het huidige
    proces al als root (bijv. Laag 3's automatische intrekking), dan
    rechtstreeks; anders (bijv. een handmatige intrekking via de GUI, die
    als gewone gebruiker draait) via een beperkte sudo-aanroep naar dit
    script zelf."""
    if hasattr(os, "geteuid") and os.geteuid() == 0:
        return add_deny_rule(binary_path, file_path)
    return _run_privileged_via_sudo("add-deny", binary_path, file_path)


def remove_deny_rule_privileged(binary_path: str, file_path: str) -> dict:
    """Bevoegdheid-bewuste variant van remove_deny_rule() — zelfde principe
    als add_deny_rule_privileged()."""
    if hasattr(os, "geteuid") and os.geteuid() == 0:
        return remove_deny_rule(binary_path, file_path)
    return _run_privileged_via_sudo("remove-deny", binary_path, file_path)


def set_enforce_mode(binary_path: str) -> dict:
    """Schakelt een profiel van 'complain' naar 'enforce' — de bewuste,
    aparte stap NA handmatige bevestiging dat het doelprogramma normaal
    functioneert met dit profiel geladen. Wordt niet automatisch aangeroepen
    door add_deny_rule()."""
    profile_path = _profile_path_for_binary(binary_path)
    if not os.path.isfile(profile_path):
        return {"success": False, "detail": "Geen profiel aanwezig voor dit programma."}
    with open(profile_path, encoding="utf-8") as f:
        content = f.read()
    if "flags=(attach_disconnected,complain)" not in content:
        return {"success": False, "detail": "Profiel staat al niet (meer) in complain-modus, of is handmatig aangepast."}
    content = content.replace("flags=(attach_disconnected,complain)", "flags=(attach_disconnected)")
    with open(profile_path, "w", encoding="utf-8") as f:
        f.write(content)
    return _reload_profile(profile_path)


if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser(description="AppArmor-profielbeheer voor de LLM-Botnet-Detectiesuite")
    sub = p.add_subparsers(dest="command", required=True)

    p_check = sub.add_parser("check", help="Controleert of AppArmor beschikbaar is op dit systeem")

    p_deny = sub.add_parser("add-deny", help="Voegt een weigeringsregel toe en herlaadt")
    p_deny.add_argument("--binary", required=True)
    p_deny.add_argument("--file", required=True)

    p_undeny = sub.add_parser("remove-deny", help="Verwijdert een weigeringsregel en herlaadt")
    p_undeny.add_argument("--binary", required=True)
    p_undeny.add_argument("--file", required=True)

    p_enforce = sub.add_parser("set-enforce", help="Schakelt van complain naar enforce")
    p_enforce.add_argument("--binary", required=True)

    args = p.parse_args()
    if args.command == "check":
        print("Beschikbaar" if is_apparmor_available() else "Niet beschikbaar")
    elif args.command == "add-deny":
        result = add_deny_rule(args.binary, args.file)
        print(result["detail"])
        sys.exit(0 if result["success"] else 1)
    elif args.command == "remove-deny":
        result = remove_deny_rule(args.binary, args.file)
        print(result["detail"])
        sys.exit(0 if result["success"] else 1)
    elif args.command == "set-enforce":
        result = set_enforce_mode(args.binary)
        print(result["detail"])
        sys.exit(0 if result["success"] else 1)
