"""
tls_utils.py — zelfondertekende HTTPS-certificaten voor de GUI.

Waarom zelfondertekend en niet een 'echte' CA-ondertekende certificaat?
Dit is een lokaal draaiend hulpmiddel zonder publiek domein — een CA
(zoals Let's Encrypt) kan alleen certificaten uitgeven voor domeinen die
publiek bereikbaar en verifieerbaar zijn. Voor een tool die op
localhost/LAN/Tailscale draait, is zelfondertekend de enige praktische
optie. Dit geeft altijd een browserwaarschuwing ("niet veilig") — dat
betekent NIET dat de verbinding zelf onveilig is (de versleuteling werkt
gewoon), alleen dat de browser niet kan verifiëren wie het certificaat
heeft uitgegeven. Voor een lokaal netwerk-hulpmiddel is dat een
acceptabele, bewuste afweging — de GUI legt dit ook aan de gebruiker uit.
"""

import ipaddress
import os
import socket
from datetime import datetime, timedelta, timezone

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID


def _detect_local_addresses():
    """
    Verzamelt adressen waarop de GUI mogelijk bereikt wordt, zodat het
    certificaat daarvoor geldig is. Faalt een detectie (bijv. geen
    Tailscale actief), dan wordt die simpelweg overgeslagen — geen fatale
    fout, het certificaat blijft geldig voor de adressen die wél
    gevonden zijn.
    """
    addresses = {"127.0.0.1", "::1"}
    hostnames = {"localhost"}

    try:
        hostnames.add(socket.gethostname())
    except Exception:
        pass

    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        addresses.add(s.getsockname()[0])
        s.close()
    except Exception:
        pass

    try:
        import psutil
        for _, addrs in psutil.net_if_addrs().items():
            for addr in addrs:
                if addr.family == socket.AF_INET and not addr.address.startswith("127."):
                    addresses.add(addr.address)
    except Exception:
        pass

    return addresses, hostnames


def generate_self_signed_cert(cert_path: str, key_path: str, validity_days: int = 825):
    """
    Genereert een zelfondertekend RSA-2048-certificaat + private key, met
    Subject Alternative Names voor alle lokaal gedetecteerde adressen
    (localhost, 127.0.0.1, LAN-IP, Tailscale-IP indien aanwezig).

    validity_days=825 (~2,25 jaar) is bewust onder de 825-dagen-grens die
    moderne browsers als maximum hanteren voor certificaatgeldigheid —
    een langere geldigheidsduur zou sommige browsers laten weigeren.
    """
    addresses, hostnames = _detect_local_addresses()

    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)

    subject = issuer = x509.Name([
        x509.NameAttribute(NameOID.COMMON_NAME, "llm-botnet-detect (lokaal, zelfondertekend)"),
    ])

    san_entries = [x509.DNSName(h) for h in sorted(hostnames)]
    for addr in sorted(addresses):
        try:
            san_entries.append(x509.IPAddress(ipaddress.ip_address(addr)))
        except ValueError:
            san_entries.append(x509.DNSName(addr))

    now = datetime.now(timezone.utc)
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - timedelta(days=1))
        .not_valid_after(now + timedelta(days=validity_days))
        .add_extension(x509.SubjectAlternativeName(san_entries), critical=False)
        .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
        .sign(key, hashes.SHA256())
    )

    os.makedirs(os.path.dirname(cert_path), exist_ok=True)
    with open(cert_path, "wb") as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))
    with open(key_path, "wb") as f:
        f.write(key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        ))
    try:
        os.chmod(key_path, 0o600)
    except Exception:
        pass  # Windows kent chmod niet op dezelfde manier — geen fatale fout

    return cert_path, key_path


def ensure_cert_exists(cert_path: str, key_path: str) -> tuple:
    """Genereert het certificaat alleen als het nog niet bestaat."""
    if os.path.isfile(cert_path) and os.path.isfile(key_path):
        return cert_path, key_path
    return generate_self_signed_cert(cert_path, key_path)
