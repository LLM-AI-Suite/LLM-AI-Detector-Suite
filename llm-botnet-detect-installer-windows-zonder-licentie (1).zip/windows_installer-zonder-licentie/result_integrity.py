"""
result_integrity.py — cryptografische ondertekening van resultaatbestanden
van Laag 1-4 en de correlatie-engine.

Waarom een APART sleutelpaar t.o.v. de TPM-modelsleutel (Laag 5)?
Die twee beschermen fundamenteel iets anders. De TPM-sleutel autoriseert
WELKE AI-MODELLEN mogen laden. Deze sleutel bevestigt dat een
RESULTAATBESTAND (bijv. "Laag 1: schoon") niet is aangepast nadat het
geschreven is. Eén sleutel voor beide zou een architecturale fout zijn:
compromittering van de ene sleutel zou dan ook het andere vertrouwens-
domein aantasten.

Dreigingsmodel — wat dit WEL en NIET beschermt:
Dit beschermt tegen iemand (of iets, bijv. een ander programma of gebruiker
op dezelfde machine) met SCHRIJFTOEGANG tot de resultatenmap maar zonder
toegang tot de private sleutel — bijv. een kwaadwillend proces dat een
"schoon"-resultaat injecteert om een echte dreiging te verbergen, of een
vals KRITIEK-resultaat om alarmmoeheid te veroorzaken. Dit beschermt NIET
tegen een aanvaller met volledige root/Administrator-toegang tot dezelfde
machine — die kan in principe ook de private sleutel zelf lezen. Dat is
een bewuste, realistische scope-afbakening, geen garantie tegen elk
denkbaar scenario.
"""

import json
import os
import platform
import sys

# Cross-platform bestandsvergrendeling: fcntl bestaat alleen op Linux/Unix,
# msvcrt is het Windows-equivalent — dit bestand wordt op beide platforms
# gebruikt (gedeeld tussen de Linux- en Windows-installers), dus een kale
# 'import fcntl' zou de Windows-installatie bij het importeren laten crashen.
_IS_WINDOWS = platform.system() == "Windows"
if _IS_WINDOWS:
    import msvcrt
else:
    import fcntl

from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey, Ed25519PublicKey,
)
from cryptography.hazmat.primitives import serialization
from cryptography.exceptions import InvalidSignature

_INTEGRITY_FIELD = "_integrity"


def _lock_exclusive(fileobj):
    if _IS_WINDOWS:
        msvcrt.locking(fileobj.fileno(), msvcrt.LK_LOCK, 1)
    else:
        fcntl.flock(fileobj.fileno(), fcntl.LOCK_EX)


def _try_lock_shared(fileobj):
    """Geeft True bij succes, False als de lock niet direct beschikbaar is."""
    if _IS_WINDOWS:
        try:
            msvcrt.locking(fileobj.fileno(), msvcrt.LK_NBLCK, 1)
            return True
        except OSError:
            return False
    else:
        try:
            fcntl.flock(fileobj.fileno(), fcntl.LOCK_SH | fcntl.LOCK_NB)
            return True
        except (OSError, BlockingIOError):
            return False


def _unlock(fileobj):
    if _IS_WINDOWS:
        try:
            fileobj.seek(0)
            msvcrt.locking(fileobj.fileno(), msvcrt.LK_UNLCK, 1)
        except OSError:
            pass
    else:
        fcntl.flock(fileobj.fileno(), fcntl.LOCK_UN)
_ALGORITHM = "ed25519"


def _key_paths(key_dir: str):
    return (
        os.path.join(key_dir, "result_signing_private.pem"),
        os.path.join(key_dir, "result_signing_public.pem"),
    )


def resolve_key_dir() -> str:
    """
    Bepaalt de map met de resultaat-ondertekeningssleutel. Controleert eerst
    de omgevingsvariabele LLM_DETECT_KEY_DIR; valt anders terug op
    '~/llm-detect-keys/result-integrity', waarbij '~' bewust NIET het kale
    $HOME is (zie hieronder).

    Waarom dit bestaat: elk laag-script gebruikte tot dusver rechtstreeks
    os.path.expanduser("~/llm-detect-keys/result-integrity"). Voor een
    proces dat als root draait (bijv. Laag 3's systeembrede service, of een
    handmatig cron-item) wijst '~' naar /root, niet naar de installerende
    gebruiker — met als gevolg een andere, eigen sleutel onder /root, die
    nooit tegen de echte publieke sleutel van de gebruiker verifieert. Dit
    werd in de praktijk gevonden via een oud, los cron-item
    (/etc/cron.d/llm-botnet-laag1) dat hierdoor structureel 'tampered'-
    resultaten produceerde. Root-draaiende systemd-services zetten nu
    expliciet LLM_DETECT_KEY_DIR (zie install.sh), zodat dit niet opnieuw,
    onopgemerkt, ergens anders kan misgaan.

    Aanvullende terugval, toegevoegd nadat exact hetzelfde patroon een
    zesde keer opdook: een gebruiker die zelf, handmatig, 'sudo python3
    <script>.py' draait vanaf de eigen terminal (zonder LLM_DETECT_KEY_DIR
    zelf te zetten) liep in precies dezelfde val — geen systemd-Environment=
    om op terug te vallen. sudo zet in dat geval zelf $SUDO_USER op de
    oorspronkelijke, echte gebruiker; die gebruiken we hier, vóór de kale
    $HOME-terugval, dezelfde aanpak als diagnose-detectiesuite.sh al kreeg.
    """
    env_override = os.environ.get("LLM_DETECT_KEY_DIR")
    if env_override:
        return env_override
    if not _IS_WINDOWS and os.environ.get("SUDO_USER"):
        try:
            import pwd
            real_home = pwd.getpwnam(os.environ["SUDO_USER"]).pw_dir
            return os.path.join(real_home, "llm-detect-keys", "result-integrity")
        except (KeyError, ImportError):
            pass  # val terug op het kale gedrag hieronder als dit onverhoopt niet lukt
    return os.path.expanduser("~/llm-detect-keys/result-integrity")


def get_or_create_signing_key(key_dir: str) -> Ed25519PrivateKey:
    """
    Haalt de lokale resultaat-ondertekeningssleutel op, en genereert er
    automatisch één als die nog niet bestaat — geen aparte, handmatige
    installatiestap nodig (in tegenstelling tot de TPM-sleutels, die
    bewust wél een expliciete keuze vereisen omdat ze modellen autoriseren).
    """
    priv_path, pub_path = _key_paths(key_dir)
    if os.path.isfile(priv_path):
        with open(priv_path, "rb") as f:
            return serialization.load_pem_private_key(f.read(), password=None)

    # Bewuste, vroege waarschuwing: een NIEUWE sleutel die onder /root/...
    # terechtkomt, is bijna altijd een ongeluk — een commando per ongeluk
    # met sudo gedraaid, niet een bewuste, systeembrede installatiekeuze.
    # Zo'n sleutel verifieert nooit tegen de eigenlijke gebruiker se eigen
    # publieke sleutel, wat pas veel later als verwarrende 'tampered'-
    # meldingen opduikt — deze waarschuwing vangt het op het moment zelf.
    if not _IS_WINDOWS and hasattr(os, "geteuid") and os.geteuid() == 0 and key_dir.startswith("/root/"):
        print(
            f"[!] WAARSCHUWING: nieuwe ondertekeningssleutel wordt aangemaakt onder {key_dir} "
            f"(root's thuismap) — dit gebeurt meestal per ongeluk, bijv. door dit commando met "
            f"sudo te draaien terwijl dat niet de bedoeling was. Deze sleutel zal NIET overeenkomen "
            f"met je eigen gebruikerssleutel, en resultaten die hiermee ondertekend worden zullen "
            f"later als 'tampered' verschijnen. Draai dit liever zonder sudo.",
            file=sys.stderr,
        )

    os.makedirs(key_dir, exist_ok=True)
    private_key = Ed25519PrivateKey.generate()
    public_key = private_key.public_key()

    priv_bytes = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    pub_bytes = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    with open(priv_path, "wb") as f:
        f.write(priv_bytes)
    with open(pub_path, "wb") as f:
        f.write(pub_bytes)
    try:
        os.chmod(priv_path, 0o600)
    except Exception:
        pass  # Windows kent chmod niet op dezelfde manier — geen fatale fout

    return private_key


def get_public_key(key_dir: str) -> Ed25519PublicKey:
    _, pub_path = _key_paths(key_dir)
    with open(pub_path, "rb") as f:
        return serialization.load_pem_public_key(f.read())


def _canonical_bytes(data) -> bytes:
    """
    Deterministische, herhaalbare byte-representatie van de data — nodig
    zodat ondertekenen en verifiëren altijd exact dezelfde bytes zien.
    Werkt zowel voor dicts (sleutels gesorteerd) als lijsten (volgorde
    blijft zoals gegeven, want die is voor een lijst al betekenisvol).
    """
    if isinstance(data, dict):
        payload = {k: v for k, v in data.items() if k != _INTEGRITY_FIELD}
    else:
        payload = data
    return json.dumps(payload, sort_keys=True, ensure_ascii=True).encode("utf-8")


def sign_result_file(json_path: str, private_key: Ed25519PrivateKey) -> str:
    """
    Ondertekent een reeds weggeschreven JSON-resultaatbestand (lijst of
    dict, maakt niet uit) en schrijft de handtekening naar een los
    companion-bestand ({json_path}.sig) — zodat de structuur van het
    resultaatbestand zelf nooit hoeft te veranderen, wat het risico op
    het breken van bestaande lezers (bijv. code die een kale lijst
    verwacht) volledig vermijdt.
    """
    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    signature = private_key.sign(_canonical_bytes(data))
    sig_path = json_path + ".sig"
    with open(sig_path, "w", encoding="utf-8") as f:
        json.dump({"algorithm": _ALGORITHM, "signature": signature.hex()}, f)
    return sig_path


def _try_shared_lock(json_path: str):
    """
    Probeert een gedeelde, niet-blokkerende lock te verkrijgen op het
    bijbehorende .lock-bestand (NIET het resultaatbestand zelf — dat wordt
    bij elke update vervangen via os.replace(), waardoor een lock daarop
    'verweesd' zou raken op de oude inode zodra de vervanging gebeurt).

    Geeft het open lock-bestand terug bij succes, of None als een
    schrijver momenteel een exclusieve lock vasthoudt — dat is het signaal
    dat er middenin een update wordt gelezen, wat anders een vals
    'tampered'-resultaat kan opleveren (nieuwe inhoud, nog-oude
    handtekening, want dat zijn twee losse bestandsoperaties).
    """
    lock_path = json_path + ".lock"
    try:
        # msvcrt.locking() vereist minstens 1 byte in het bestand om een
        # regio op te kunnen vergrendelen — zorg daarvoor bij een vers
        # aangemaakt (leeg) lock-bestand. Onschadelijk op Linux.
        lock_file = open(lock_path, "a+b")
        if os.path.getsize(lock_path) == 0:
            lock_file.write(b"0")
            lock_file.flush()
        lock_file.seek(0)
        if _try_lock_shared(lock_file):
            return lock_file
        lock_file.close()
        return None
    except OSError:
        return None


def verify_result_file(json_path: str, public_key: Ed25519PublicKey) -> dict:
    """Zelfde statusmodel als verify_result(), maar dan op bestandsniveau."""
    lock_file = _try_shared_lock(json_path)
    if lock_file is None:
        return {"status": "busy", "valid": None}
    try:
        sig_path = json_path + ".sig"
        if not os.path.isfile(sig_path):
            return {"status": "unsigned", "valid": None}

        try:
            with open(sig_path, "r", encoding="utf-8") as f:
                sig_data = json.load(f)
            signature = bytes.fromhex(sig_data["signature"])
        except (KeyError, ValueError, json.JSONDecodeError):
            return {"status": "malformed", "valid": False}

        with open(json_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        try:
            public_key.verify(signature, _canonical_bytes(data))
            return {"status": "valid", "valid": True}
        except InvalidSignature:
            return {"status": "tampered", "valid": False}
    finally:
        _unlock(lock_file)
        lock_file.close()


def sign_result(data: dict, private_key: Ed25519PrivateKey) -> dict:
    """
    Voegt een _integrity-veld toe aan het resultaat-dict, met een
    handtekening over de rest van de inhoud. Geeft een NIEUW dict terug
    (muteert de invoer niet). Alleen geschikt voor dict-vormige resultaten
    — gebruik sign_result_file() voor lijst-vormige resultaten.
    """
    signed = dict(data)
    signed.pop(_INTEGRITY_FIELD, None)
    signature = private_key.sign(_canonical_bytes(signed))
    signed[_INTEGRITY_FIELD] = {
        "algorithm": _ALGORITHM,
        "signature": signature.hex(),
    }
    return signed


def verify_result(data: dict, public_key: Ed25519PublicKey) -> dict:
    """
    Verifieert een eerder ondertekend resultaat. Geeft een status-dict
    terug in plaats van simpelweg True/False, zodat de aanroeper het
    verschil kan tonen tussen "geen handtekening aanwezig" (bijv. een
    resultaat van vóór deze functie werd toegevoegd) en "handtekening
    aanwezig maar ONGELDIG" (het echte manipulatie-signaal).
    """
    integrity = data.get(_INTEGRITY_FIELD)
    if not integrity:
        return {"status": "unsigned", "valid": None}

    try:
        signature = bytes.fromhex(integrity["signature"])
    except (KeyError, ValueError):
        return {"status": "malformed", "valid": False}

    payload = {k: v for k, v in data.items() if k != _INTEGRITY_FIELD}
    try:
        public_key.verify(signature, _canonical_bytes(payload))
        return {"status": "valid", "valid": True}
    except InvalidSignature:
        return {"status": "tampered", "valid": False}
