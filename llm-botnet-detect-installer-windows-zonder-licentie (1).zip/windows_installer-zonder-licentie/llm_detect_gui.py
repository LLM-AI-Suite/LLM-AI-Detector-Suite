#!/usr/bin/env python3
"""
llm_detect_gui.py
=================
Web-gebaseerde GUI voor het LLM-botnet-detectiesysteem.
Draai met: python3 llm_detect_gui.py
Bezoek: http://localhost:5000

Deze versie bevat alle fixes die tijdens ontwikkeling en productie-inzet zijn
gevonden en getest:
  - Templates/static-map relatief aan dit scriptbestand (niet /tmp)
  - Alle subprocess-aanroepen met 'python3 -u' (unbuffered output, anders
    komt live-logging pas binnen bij het einde van een lange taak)
  - RESULTS_DIR met automatische fallback naar de home-map als /var/log/
    niet beschrijfbaar is
  - Laag 4 synthetische modus: twee-staps flow (genereren + analyseren) zodat
    er een bruikbaar resultaat in de geschiedenis verschijnt
  - Laag 5: volledige flow inclusief init-authority/init-endpoint/verify,
    plus een testmodel-generator (persistent, niet in /tmp)
  - Laag 2: testdata-generator direct vanuit de GUI (persistent, niet in /tmp)
  - Correlatie: automatische manifest-opbouw op basis van resultatengeschiedenis
  - size_display i.p.v. size_kb (geen misleidende "0 KB" bij kleine bestanden)
  - ~ (tilde) wordt server-side uitgevouwen in alle pad-parameters
  - HTTP Basic Auth via LLM_GUI_USER/LLM_GUI_PASS omgevingsvariabelen
  - Desktop-notificatie bij KRITIEK-correlatiescore
"""

from flask import Flask, render_template, request, jsonify, send_file
import subprocess
import csv
import hashlib
import io
import ipaddress
import json
import os
import platform
import socket
import sys
import xml.etree.ElementTree as ET
import threading
import time
from datetime import datetime
from pathlib import Path
import uuid

try:
    import psutil
except ImportError:
    psutil = None  # alleen nodig voor /api/network-interfaces; de rest van de GUI blijft werken zonder

# Forceer UTF-8-uitvoer voor deze GUI zelf ÉN voor alle subprocessen die het
# start (elke laag, correlatie-engine, enz.) — child-processen erven
# os.environ automatisch, dus dit hoeft maar op één plek te staan.
# Zonder dit crasht elk print()/Write-Host-achtig statement met een
# niet-ASCII-teken (checkmarks, waarschuwingstekens, gedachtestreepjes) op
# Windows met een UnicodeEncodeError, omdat Windows' console standaard het
# cp1252-codepage gebruikt in plaats van UTF-8 — bevestigd tijdens een echte
# Windows-testinstallatie, waar dit vier van de vijf lagen liet crashen.
os.environ["PYTHONUTF8"] = "1"
os.environ["PYTHONIOENCODING"] = "utf-8"
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

# ─────────────────────────────────────────────────────────────
# Cross-platform ondersteuning (Linux/Ubuntu productiesysteem + Windows)
# ─────────────────────────────────────────────────────────────
# LET OP: de Windows-tak hieronder is ontwikkeld en getest op Linux via
# psutil's Linux-backend (zie llm_botnet_scanner_windows.py en
# realtime_kernel_agent_windows.py voor de volledige kanttekening). De
# Linux-tak (IS_WINDOWS == False) is het bestaande, in productie draaiende
# pad en blijft ongewijzigd — dit is uitgebreid geregressietest na deze
# wijziging om dat te bevestigen.
IS_WINDOWS = platform.system() == "Windows"
PYTHON_CMD = "python" if IS_WINDOWS else "python3"
SCANNER_SCRIPT = "llm_botnet_scanner_windows.py" if IS_WINDOWS else "llm_botnet_scanner.py"
AGENT_SCRIPT = "realtime_kernel_agent_windows.py" if IS_WINDOWS else "realtime_kernel_agent.py"

# Script per laag, gebruikt om te controleren of een laag daadwerkelijk is
# meegeleverd in dit installatiepakket (bijv. bij de Wachter-tier, die
# bewust alleen Laag 2 bevat). Laag 2 zelf staat hier niet in, want die
# is in elke tier altijd aanwezig.
_LAYER_SCRIPT_MAP = {
    1: SCANNER_SCRIPT,
    3: AGENT_SCRIPT,
    4: "gpu_fingerprint_detector.py",
    5: "tpm_model_attestation.py",
}

def _layer_unavailable_response(layer_id):
    """
    Geeft None als de laag beschikbaar is, anders een nette foutmelding
    i.p.v. een kale Python-traceback bij een ontbrekend script (relevant
    voor beperktere installatievarianten, zoals de Wachter-tier).
    """
    script = _LAYER_SCRIPT_MAP.get(layer_id)
    if script is None:
        return None
    if os.path.isfile(os.path.join(BASE_DIR, script)):
        return None
    return {
        "error": f"Laag {layer_id} is niet inbegrepen in deze installatie.",
        "detail": "Deze installatie bevat een beperktere set functies (bijv. de Wachter-tier, met alleen Laag 2). Een volledige installatie geeft toegang tot alle vijf lagen.",
    }

# Templates-map bevindt zich naast dit script zelf (niet in /tmp — dat bestaat
# alleen op de ontwikkelmachine en niet op een productie-installatie)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__, template_folder=os.path.join(BASE_DIR, "templates"), static_folder=os.path.join(BASE_DIR, "static"))


def _resolve_results_dir():
    """
    Gebruik /var/log/llm-detect/ als die bestaat én beschrijfbaar is (alleen
    relevant op Linux). Val anders terug op een map in de home-directory van
    de gebruiker — op Windows is dat altijd de te gebruiken locatie, op
    Linux een nette fallback wanneer /var/log/llm-detect/ eigendom is van
    root.
    """
    if IS_WINDOWS:
        fallback = Path.home() / "llm-detect-results"
        fallback.mkdir(parents=True, exist_ok=True)
        return fallback

    primary = Path("/var/log/llm-detect")
    try:
        primary.mkdir(parents=True, exist_ok=True)
        test_file = primary / ".write_test"
        test_file.touch()
        test_file.unlink()
        return primary
    except (PermissionError, OSError):
        fallback = Path.home() / "llm-detect-results"
        fallback.mkdir(parents=True, exist_ok=True)
        print(f"[!] /var/log/llm-detect/ is niet beschrijfbaar — resultaten gaan naar {fallback}")
        print(f"    Tip: 'sudo chown {os.environ.get('USER', 'jouw-gebruiker')}:{os.environ.get('USER', 'jouw-gebruiker')} /var/log/llm-detect/' lost dit permanent op.")
        return fallback


RESULTS_DIR = _resolve_results_dir()

# ─────────────────────────────────────────────────────────────
# Basisauthenticatie — nodig zodra de GUI binnen het LAN bereikbaar is
# (niet alleen localhost). Gebruikersnaam/wachtwoord komen uit omgevings-
# variabelen, nooit hardcoded in dit bestand. Instellen vóór het starten:
#
#   export LLM_GUI_USER=jouw_gebruikersnaam
#   export LLM_GUI_PASS=een_sterk_wachtwoord
#   python3 llm_detect_gui.py
#
# Zonder deze variabelen draait de GUI ONBEVEILIGD — prima voor localhost-
# only gebruik, maar riskant zodra de poort ook op het LAN toegankelijk is
# (Flask luistert standaard al op 0.0.0.0, dus dit is niet optioneel bij
# productiegebruik op een netwerk waar meerdere apparaten op zitten).
# ─────────────────────────────────────────────────────────────

GUI_USER = os.environ.get("LLM_GUI_USER")
GUI_PASS = os.environ.get("LLM_GUI_PASS")

if not GUI_USER or not GUI_PASS:
    print("[!] WAARSCHUWING: LLM_GUI_USER/LLM_GUI_PASS niet ingesteld — de GUI draait ONBEVEILIGD.")
    print("    Stel in met: export LLM_GUI_USER=... && export LLM_GUI_PASS=...")

# ─────────────────────────────────────────────────────────────
# TLS-modus: HTTPS (zelfondertekend) of HTTP-maar-alleen-Tailscale/localhost.
# Gekozen tijdens installatie (of update.sh vraagt hierom bij een bestaand
# certificaat), opgeslagen als LLM_GUI_TLS_MODE. Bestaat deze variabele nog
# niet (bijv. een installatie die via update.sh is bijgewerkt vanaf een
# versie zonder deze functie), dan is "https" de veilige standaardkeuze —
# er is dan geen aparte install.sh-stap nodig om het gat alsnog te dichten.
# ─────────────────────────────────────────────────────────────
TLS_MODE = os.environ.get("LLM_GUI_TLS_MODE", "https").strip().lower()

# Tailscale's CGNAT-adresruimte (100.64.0.0/10) — alle Tailscale-IP's vallen
# hierbinnen, ongeacht welk specifiek adres een apparaat toegewezen krijgt.
_TAILSCALE_CGNAT = ipaddress.ip_network("100.64.0.0/10")


def _is_allowed_in_tailscale_only_mode(remote_addr: str) -> bool:
    if remote_addr in ("127.0.0.1", "::1"):
        return True
    try:
        return ipaddress.ip_address(remote_addr) in _TAILSCALE_CGNAT
    except ValueError:
        return False


@app.before_request
def restrict_to_tailscale_if_configured():
    if TLS_MODE != "tailscale-only":
        return
    remote_addr = request.remote_addr or ""
    if not _is_allowed_in_tailscale_only_mode(remote_addr):
        return (
            "Toegang geweigerd — deze installatie is geconfigureerd om alleen "
            "bereikbaar te zijn via Tailscale of vanaf de machine zelf (localhost). "
            "Verbind via je Tailscale-netwerk, of kies bij de installatie voor de "
            "HTTPS-modus als je breder LAN-toegang nodig hebt.",
            403,
        )


# ─────────────────────────────────────────────────────────────
# Rate-limiting op inlogpogingen — gevonden tijdens een informele
# zelf-pentest: zonder dit konden 50 gelijktijdige foutieve pogingen in
# 0,31 seconden worden afgevuurd, zonder enige vertraging. In-memory
# (geen externe afhankelijkheid nodig) — past bij de schaal van een
# lokaal-draaiend hulpmiddel met één proces.
# ─────────────────────────────────────────────────────────────
_LOGIN_MAX_ATTEMPTS = 5
_LOGIN_WINDOW_SECONDS = 300  # 5 minuten
_failed_login_attempts = {}  # {ip: [tijdstip1, tijdstip2, ...]}


def _is_rate_limited(ip: str) -> bool:
    now = time.time()
    attempts = _failed_login_attempts.get(ip, [])
    attempts = [t for t in attempts if now - t < _LOGIN_WINDOW_SECONDS]
    _failed_login_attempts[ip] = attempts
    return len(attempts) >= _LOGIN_MAX_ATTEMPTS


def _record_failed_login(ip: str):
    _failed_login_attempts.setdefault(ip, []).append(time.time())


def _clear_failed_logins(ip: str):
    _failed_login_attempts.pop(ip, None)


@app.before_request
def require_auth():
    if not GUI_USER or not GUI_PASS:
        return  # geen credentials geconfigureerd -> auth overgeslagen (alleen aan te raden voor localhost-only gebruik)

    client_ip = request.remote_addr or "onbekend"
    if _is_rate_limited(client_ip):
        return (
            f"Te veel mislukte inlogpogingen. Probeer het over maximaal "
            f"{_LOGIN_WINDOW_SECONDS // 60} minuten opnieuw.",
            429,
            {"Retry-After": str(_LOGIN_WINDOW_SECONDS)},
        )

    auth = request.authorization
    if not auth or auth.username != GUI_USER or auth.password != GUI_PASS:
        _record_failed_login(client_ip)
        return (
            "Authenticatie vereist.",
            401,
            {"WWW-Authenticate": 'Basic realm="LLM-Botnet Detectie GUI"'},
        )
    _clear_failed_logins(client_ip)


ACTIVE_JOBS = {}  # {job_id: {"status": "running|done", "output": "", "result_path": ""}}


import notification_helper


def check_and_notify_correlation_result(correlatie_json_path):
    """
    Leest een correlatie-resultaat en dispatcht (indien de score de ingestelde
    drempel haalt) notificaties via alle ingeschakelde kanalen. Zie
    notification_helper.py voor de gedeelde logica (ook gebruikt door
    scheduled_correlation_check.py, zodat beide consistent dezelfde
    instellingen respecteren).
    """
    try:
        with open(correlatie_json_path, encoding="utf-8") as f:
            results = json.load(f)
        settings = notification_helper.load_settings()
        for r in results:
            notification_helper.dispatch_notifications(
                score=r.get("correlated_score", 0),
                host=r.get("host", "onbekend"),
                firing_domains=r.get("firing_domains", []),
                settings=settings,
            )
    except Exception as e:
        print(f"[!] Kon correlatieresultaat niet controleren voor notificatie: {e}")


# ─────────────────────────────────────────────────────────────
# Job-beheer
# ─────────────────────────────────────────────────────────────

def run_layer_task(job_id, layer, params):
    """Voer een detectielaag-taak uit in een aparte thread."""
    # Vouw "~" uit naar de echte home-directory in alle pad-achtige parameters.
    # Zonder dit stuurt de browser de letterlijke tekst "~/..." door naar
    # subprocess, wat niet door de shell wordt geïnterpreteerd (dat gebeurt
    # normaal door bash, niet door Python's subprocess-module rechtstreeks).
    path_keys = {"path", "input_file", "model_path", "registry", "authority_key",
                 "endpoint_key", "authority_out", "endpoint_out", "quote_path",
                 "authority_pubkey", "endpoint_pubkey"}
    params = {k: (os.path.expanduser(v) if k in path_keys and isinstance(v, str) else v)
              for k, v in params.items()}

    ACTIVE_JOBS[job_id] = {"status": "running", "output": "", "layer": layer, "start": datetime.now().isoformat()}

    try:
        # Bouw het commando op basis van laag en params
        if layer == 1:
            mode = params.get("mode", "all")
            cmd = [
                PYTHON_CMD, "-u", os.path.join(BASE_DIR, SCANNER_SCRIPT),
                mode,
            ]
            # --path en --min-size bestaan alleen bij de subcommando's 'files'
            # en 'all' in llm_botnet_scanner.py — bij 'processes'/'network'
            # geeft de tool dan een "unrecognized arguments"-fout (exitcode 2).
            if mode in ("files", "all"):
                # expanduser is hier nodig omdat de zoekbare dropdown voor dit
                # veld zelf '~' als suggestie aanbiedt (zie initSearchableDropdown
                # voor l1_path) — zonder dit zou die keuze een letterlijke,
                # niet-bestaande map genaamd '~' opleveren.
                cmd.extend(["--path", os.path.expanduser(params.get("path", "/home"))])
                if params.get("min_size"):
                    cmd.extend(["--min-size", str(params["min_size"])])
            cmd.extend(["--json", str(RESULTS_DIR / f"laag1_{job_id}.json")])
        elif layer == 2:
            if IS_WINDOWS and params.get("mode") == "live_capture":
                # Live capture op Windows: eerst pakketten vangen en omzetten
                # naar flow-records (netflow_capture_windows.py, Npcap/dumpcap-
                # gebaseerd), dan die output aan de bestaande, ongewijzigde
                # analyse-engine voeren — zelfde eindresultaat als op Linux,
                # alleen de weg ernaartoe verschilt.
                capture_out = str(RESULTS_DIR / f"laag2_capture_{job_id}.json")
                capture_cmd = [
                    PYTHON_CMD, "-u", os.path.join(BASE_DIR, "netflow_capture_windows.py"),
                    "--interface", params.get("interface", ""),
                    "--duration", str(params.get("duration", 60)),
                    "--json", capture_out,
                ]
                capture_result = subprocess.run(capture_cmd, capture_output=True, text=True, timeout=int(params.get("duration", 60)) + 30)
                ACTIVE_JOBS[job_id]["output"] += capture_result.stdout + capture_result.stderr
                if capture_result.returncode != 0:
                    raise RuntimeError(f"Netflow-capture mislukt: {capture_result.stderr.strip() or '(geen foutdetails)'}")
                cmd = [
                    PYTHON_CMD, "-u", os.path.join(BASE_DIR, "netflow_gossip_detector.py"),
                    "--input", capture_out,
                    "--json", str(RESULTS_DIR / f"laag2_{job_id}.json")
                ]
            else:
                cmd = [
                    PYTHON_CMD, "-u", os.path.join(BASE_DIR, "netflow_gossip_detector.py"),
                    "--input", os.path.expanduser(params.get("input_file", "flows.json")),
                    "--json", str(RESULTS_DIR / f"laag2_{job_id}.json")
                ]
        elif layer == 3:
            cmd = [
                PYTHON_CMD, "-u", os.path.join(BASE_DIR, AGENT_SCRIPT),
                "--interval", str(params.get("interval", 2)),
                "--duration", str(params.get("duration", 3600)),
                "--json", str(RESULTS_DIR / f"laag3_{job_id}.json")
            ]
        elif layer == 4:
            if params.get("mode") == "live":
                cmd = [
                    PYTHON_CMD, "-u", os.path.join(BASE_DIR, "gpu_fingerprint_detector.py"),
                    "--live",
                    "--duration", str(params.get("duration", 60)),
                    "--interval", str(params.get("interval", 0.1)),
                    "--json", str(RESULTS_DIR / f"laag4_{job_id}.json")
                ]
            else:
                # Synthetische modus is een 2-staps proces in de onderliggende
                # tool: eerst samples genereren (naar stdout), dan analyseren
                # (--input). Beide stappen hier uitvoeren zodat er, net als bij
                # de andere lagen, een resultaat-JSON in de geschiedenis komt
                # i.p.v. alleen ruwe samples in de live-log te tonen.
                synthetic_path = RESULTS_DIR / f"laag4_{job_id}_samples.json"
                gen_cmd = [
                    PYTHON_CMD, "-u", os.path.join(BASE_DIR, "gpu_fingerprint_detector.py"),
                    "--generate-synthetic", params.get("synthetic_type", "idle"),
                    "--duration", str(params.get("duration", 15))
                ]
                with open(synthetic_path, "w", encoding="utf-8") as sf:
                    subprocess.run(gen_cmd, stdout=sf, stderr=subprocess.PIPE, text=True)
                cmd = [
                    PYTHON_CMD, "-u", os.path.join(BASE_DIR, "gpu_fingerprint_detector.py"),
                    "--input", str(synthetic_path),
                    "--json", str(RESULTS_DIR / f"laag4_{job_id}.json")
                ]
        elif layer == 5:
            action = params.get("action")
            if action == "init-authority":
                out_dir = os.path.expanduser(params.get("authority_out", "~/llm-detect-keys/authority_keys"))
                if os.path.exists(os.path.join(out_dir, "private.pem")) and not params.get("force"):
                    raise RuntimeError(
                        f"Er bestaat al een sleutel op {os.path.join(out_dir, 'private.pem')}. "
                        f"Opnieuw genereren maakt alle eerder gesigneerde modellen onverifieerbaar. "
                        f"Vink 'Ik snap het risico' aan in de GUI om toch door te gaan."
                    )
                cmd = [
                    PYTHON_CMD, "-u", os.path.join(BASE_DIR, "tpm_model_attestation.py"),
                    "init-authority",
                    "--out", out_dir
                ]
            elif action == "init-endpoint":
                out_dir = os.path.expanduser(params.get("endpoint_out", "~/llm-detect-keys/endpoint_keys"))
                if os.path.exists(os.path.join(out_dir, "private.pem")) and not params.get("force"):
                    raise RuntimeError(
                        f"Er bestaat al een sleutel op {os.path.join(out_dir, 'private.pem')}. "
                        f"Opnieuw genereren maakt alle eerder gemaakte quotes onverifieerbaar. "
                        f"Vink 'Ik snap het risico' aan in de GUI om toch door te gaan."
                    )
                cmd = [
                    PYTHON_CMD, "-u", os.path.join(BASE_DIR, "tpm_model_attestation.py"),
                    "init-endpoint",
                    "--out", out_dir
                ]
            elif action == "verify":
                cmd = [
                    PYTHON_CMD, "-u", os.path.join(BASE_DIR, "tpm_model_attestation.py"),
                    "verify",
                    "--quote", os.path.expanduser(params.get("quote_path", "")),
                    "--registry", os.path.expanduser(params.get("registry", "~/llm-detect-keys/registry.json")),
                    "--authority-pubkey", os.path.expanduser(params.get("authority_pubkey", "~/llm-detect-keys/authority_keys/public.pem")),
                    "--endpoint-pubkey", os.path.expanduser(params.get("endpoint_pubkey", "~/llm-detect-keys/endpoint_keys/public.pem")),
                    "--expected-nonce", params.get("nonce", "0123456789abcdef"),
                    "--json", str(RESULTS_DIR / f"laag5_verify_{job_id}.json")
                ]
            elif action == "sign":
                cmd = [
                    PYTHON_CMD, "-u", os.path.join(BASE_DIR, "tpm_model_attestation.py"),
                    "sign-model",
                    "--model", os.path.expanduser(params.get("model_path", "model.gguf")),
                    "--authority-key", os.path.expanduser(params.get("authority_key", "~/llm-detect-keys/authority_keys/private.pem")),
                    "--registry", os.path.expanduser(params.get("registry", "~/llm-detect-keys/registry.json")),
                    "--name", params.get("model_name", "model")
                ]
            else:  # measure
                quote_out_path = str(RESULTS_DIR / f"laag5_quote_{job_id}.json")
                cmd = [
                    PYTHON_CMD, "-u", os.path.join(BASE_DIR, "tpm_model_attestation.py"),
                    "measure-and-quote",
                    "--model", os.path.expanduser(params.get("model_path", "model.gguf")),
                    "--endpoint-key", os.path.expanduser(params.get("endpoint_key", "~/llm-detect-keys/endpoint_keys/private.pem")),
                    "--nonce", params.get("nonce", "0123456789abcdef"),
                    "--out", quote_out_path
                ]
                # Bewaar het pad zodat de GUI het quote_path-veld automatisch
                # kan invullen na afloop — zonder dit moet de gebruiker dit
                # bestandspad handmatig overtypen vóór de Verify-stap, wat
                # foutgevoelig is en tot een lege/verkeerde waarde leidde.
                ACTIVE_JOBS[job_id]["result_path"] = quote_out_path

        # Voer uit
        proc = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1
        )
        output_lines = []
        for line in proc.stdout:
            output_lines.append(line.rstrip())
            ACTIVE_JOBS[job_id]["output"] = "\n".join(output_lines[-100:])  # houd laatste 100 regels

        proc.wait()
        ACTIVE_JOBS[job_id]["status"] = "done"
        ACTIVE_JOBS[job_id]["return_code"] = proc.returncode
        ACTIVE_JOBS[job_id]["end"] = datetime.now().isoformat()

        # Bij een niet-nul exitcode staat de daadwerkelijke fout al in de
        # output (stderr is meegekaapt naar stdout), maar we lichten 'm er
        # expliciet uit zodat de GUI een duidelijke samenvatting kan tonen
        # i.p.v. alleen "exitcode: 1" zonder verdere context.
        if proc.returncode != 0:
            last_lines = "\n".join(output_lines[-5:])
            ACTIVE_JOBS[job_id]["error_summary"] = f"Script eindigde met fout (exitcode {proc.returncode}). Laatste regels:\n{last_lines}"

    except Exception as e:
        ACTIVE_JOBS[job_id]["status"] = "error"
        ACTIVE_JOBS[job_id]["error"] = str(e)
        ACTIVE_JOBS[job_id]["end"] = datetime.now().isoformat()

# ─────────────────────────────────────────────────────────────
# Routes
# ─────────────────────────────────────────────────────────────

@app.route("/api/dashboard", methods=["GET"])
def get_dashboard():
    """
    Aggregeert de status van alle lagen + laatste correlatie + gedetecteerde
    lokale LLM-services tot één overzicht voor het dashboard-tabblad.

    Per laag wordt een 'light' bepaald:
      - "running"  : er draait nu een taak voor deze laag
      - "kritiek"   : laatste resultaat bevat een KRITIEK/HOOG-signaal of faalde
      - "aandacht"  : laatste resultaat bevat een lager-severity signaal
      - "schoon"    : laatste resultaat is volledig schoon
      - "onbekend"  : nog nooit gedraaid
    """
    prefix_map = {1: "laag1_", 2: "laag2_", 3: "laag3_", 4: "laag4_", 5: "laag5_verify_"}
    layers = {}

    try:
        import result_integrity as _ri
        _integrity_pub = _ri.get_public_key(_ri.resolve_key_dir())
    except Exception:
        _integrity_pub = None

    for layer_id, prefix in prefix_map.items():
        running = any(j.get("layer") == layer_id and j.get("status") == "running" for j in ACTIVE_JOBS.values())
        if running:
            layers[str(layer_id)] = {"light": "running", "last_run": None, "detail": "Bezig...", "findings": [], "integrity": "onbekend"}
            continue

        candidates = sorted(
            [f for f in RESULTS_DIR.glob(f"{prefix}*.json") if "_samples" not in f.name],
            key=lambda x: x.stat().st_mtime, reverse=True
        )
        if not candidates:
            layers[str(layer_id)] = {"light": "onbekend", "last_run": None, "detail": "Nog niet gedraaid", "findings": [], "integrity": "onbekend"}
            continue

        latest = candidates[0]
        last_run = datetime.fromtimestamp(latest.stat().st_mtime).isoformat()

        integrity_status = "onbekend"
        if _integrity_pub is not None:
            try:
                integrity_status = _ri.verify_result_file(str(latest), _integrity_pub)["status"]
            except Exception:
                pass

        try:
            with open(latest, encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            layers[str(layer_id)] = {"light": "onbekend", "last_run": last_run, "detail": "Resultaat onleesbaar", "findings": [], "integrity": integrity_status}
            continue

        light, detail = _derive_layer_light(layer_id, data)
        findings = _extract_findings(layer_id, data)
        layers[str(layer_id)] = {"light": light, "last_run": last_run, "detail": detail, "findings": findings, "integrity": integrity_status}

    # Laatste correlatieresultaat
    correlatie_files = sorted(RESULTS_DIR.glob("correlatie_*.json"), key=lambda x: x.stat().st_mtime, reverse=True)
    latest_correlation = None
    if correlatie_files:
        try:
            with open(correlatie_files[0], encoding="utf-8") as f:
                results = json.load(f)
            if results:
                latest_correlation = max(results, key=lambda r: r.get("correlated_score", 0))
                latest_correlation["_timestamp"] = datetime.fromtimestamp(correlatie_files[0].stat().st_mtime).isoformat()
        except Exception:
            pass

    # Gedetecteerde lokale LLM/ML-services uit het meest recente Laag 1-resultaat
    detected_services = []
    laag1_files = sorted(RESULTS_DIR.glob("laag1_*.json"), key=lambda x: x.stat().st_mtime, reverse=True)
    if laag1_files:
        try:
            with open(laag1_files[0], encoding="utf-8") as f:
                data = json.load(f)
            for entry in data.get("network", []):
                detected_services.append({
                    "port": entry.get("port"),
                    "service": entry.get("service_guess", "onbekend"),
                    "pid": entry.get("pid", "onbekend"),
                })
        except Exception:
            pass

    active_jobs_count = sum(1 for j in ACTIVE_JOBS.values() if j.get("status") == "running")

    return jsonify({
        "layers": layers,
        "latest_correlation": latest_correlation,
        "detected_services": detected_services,
        "active_jobs_count": active_jobs_count,
        "is_windows": IS_WINDOWS,
    })


def _derive_layer_light(layer_id, data):
    """Bepaalt groen/geel/rood-achtige status per laag, gegeven diens eigen JSON-schema."""
    if layer_id == 1:
        max_sev = 0
        for f in data.get("files", []):
            max_sev = max(max_sev, f.get("severity", 0))
        for c in data.get("correlated", []):
            max_sev = max(max_sev, c.get("combined_severity", 0))
        if max_sev >= 8:
            return "kritiek", f"Hoogste severity: {max_sev}"
        if max_sev > 0:
            return "aandacht", f"Hoogste severity: {max_sev}"
        return "schoon", "Geen bijzonderheden"

    if layer_id == 2:
        if not isinstance(data, list) or not data:
            return "schoon", "Geen hosts met verkeer"
        max_sev = max((h.get("total_severity", 0) for h in data), default=0)
        if max_sev >= 40:
            return "kritiek", f"Hoogste score: {max_sev}"
        if max_sev > 0:
            return "aandacht", f"Hoogste score: {max_sev}"
        return "schoon", "Geen bijzonderheden"

    if layer_id == 3:
        if not isinstance(data, list) or not data:
            return "schoon", "0 events"
        severities = [e.get("severity") for e in data]
        if "KRITIEK" in severities:
            return "kritiek", f"{len(data)} events, incl. KRITIEK"
        if "HOOG" in severities or "MIDDEL" in severities:
            return "aandacht", f"{len(data)} events"
        return "schoon", f"{len(data)} events (LAAG)"

    if layer_id == 4:
        sev = data.get("severity", 0)
        if sev >= 7:
            return "kritiek", f"Score: {sev}"
        if sev > 0:
            return "aandacht", f"Score: {sev}"
        return "schoon", "Geen GPU-inferentiesignatuur"

    if layer_id == 5:
        checks = data.get("checks", [])
        if data.get("overall_pass") is True:
            return "schoon", "Laatste attestatie: TOEGESTAAN"
        if checks:
            return "kritiek", "Laatste attestatie: GEWEIGERD"
        return "onbekend", "Nog geen verificatie uitgevoerd"

    return "onbekend", ""


def _extract_findings(layer_id, data, max_items=12):
    """
    Haalt de daadwerkelijke bevindingen (leesbare tekstregels) op per laag,
    zodat het dashboard bij een klik op een laag-kaart écht kan tonen WAT er
    gevonden is, niet alleen een samenvattend cijfer. Elk laag-schema is
    anders, dus per laag een eigen extractie — dezelfde velden die ook al in
    _derive_layer_light() gebruikt worden.
    """
    findings = []

    if layer_id == 1:
        for f in data.get("files", []):
            for msg in f.get("findings", []):
                findings.append(f"[bestand] {f.get('path', '?')}: {msg}")
        for c in data.get("correlated", []):
            for r in c.get("reasons", []):
                findings.append(f"[proces+netwerk] PID {c.get('pid', '?')}: {r}")

    elif layer_id == 2:
        if isinstance(data, list):
            for host in data:
                if host.get("churn_finding"):
                    findings.append(f"[{host.get('host', '?')}] {host['churn_finding']}")
                for peer in host.get("peer_results", []):
                    for msg in peer.get("findings", []):
                        findings.append(f"[{host.get('host', '?')} → {peer.get('peer', '?')}] {msg}")

    elif layer_id == 3:
        if isinstance(data, list):
            for e in data:
                findings.append(f"[{e.get('severity', '?')}] PID {e.get('pid', '?')} ({e.get('comm', '?')}): {e.get('message', '')}")

    elif layer_id == 4:
        for msg in data.get("findings", []):
            findings.append(msg)

    elif layer_id == 5:
        for c in data.get("checks", []):
            status = "OK" if c.get("pass") else "FAIL"
            findings.append(f"[{status}] {c.get('check', '?')}: {c.get('detail', '')}")

    # Meest recente/relevante eerst waar zinvol (laag 3 is al chronologisch;
    # de rest laten we in de volgorde van het bronbestand), en begrenzen zodat
    # het dashboard niet overspoeld wordt bij een groot resultaat.
    return findings[-max_items:] if layer_id == 3 else findings[:max_items]


@app.route("/")
def index():
    return render_template("index.html")

@app.route("/documentatie/")
@app.route("/documentatie/<path:filename>")
def documentatie(filename="index.html"):
    """
    Serveert de meegeleverde documentatiewebsite (projectoverzicht +
    het geanimeerde verhaal) direct vanuit de GUI zelf, zodat een gebruiker
    die niet komt naar deze bestanden hoeft te zoeken. Dezelfde
    Basic-Auth-bescherming als de rest van de GUI geldt hier automatisch
    (via @app.before_request), en de relatieve links tussen index.html en
    verhaal.html blijven werken omdat beide bestanden onder hetzelfde pad
    ("/documentatie/...") bereikbaar zijn.
    """
    doc_dir = os.path.join(BASE_DIR, "documentatie")
    safe_path = os.path.normpath(os.path.join(doc_dir, filename))
    if not safe_path.startswith(os.path.normpath(doc_dir)):
        return "Ongeldig pad.", 400
    if not os.path.isfile(safe_path):
        return f"Bestand niet gevonden: {filename}", 404
    response = send_file(safe_path)
    # Expliciet geen browsercache toestaan voor deze documentatiebestanden —
    # zonder dit kon een gebruiker na een update nog een verouderde versie
    # van documentatie.html te zien krijgen (bijv. een al-verwijderd
    # marktonderzoek-hoofdstuk dat toch weer leek terug te komen). De
    # browser moet bij elk bezoek opnieuw bij de server checken, niet
    # blind op een lokaal bewaarde kopie vertrouwen.
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    return response

@app.route("/api/layers", methods=["GET"])
def get_layers():
    """Haalt beschrijvingen van alle lagen op."""
    return jsonify({
        "layers": [
            {"id": 1, "name": "Laag 1: Bestand/Proces/Netwerk", "description": "Snapshot-scan voor GGUF-bestanden, ML-processen, verdachte poorten"},
            {"id": 2, "name": "Laag 2: Netflow Gossip", "description": "Analyseert flow-records op gossip-patronen"},
            {"id": 3, "name": "Laag 3: Realtime Kernel-Agent", "description": "Continu processmonitoring"},
            {"id": 4, "name": "Laag 4: GPU-Fingerprinting", "description": "GPU computationele signatuuranalyse"},
            {"id": 5, "name": "Laag 5: TPM-Attestatie", "description": "Cryptografische model-autorisatie"},
        ]
    })

@app.route("/api/layer/<int:layer_id>/params", methods=["GET"])
def get_layer_params(layer_id):
    """Haalt beschikbare parameters voor een laag op."""
    params = {
        1: {
            "mode": {"type": "select", "options": ["all", "files", "processes", "network"], "default": "all", "label": "Scan-modus"},
            "path": {"type": "text", "default": "/home", "label": "Pad om te scannen"},
            "min_size": {"type": "number", "default": 50, "label": "Minimale bestandsgrootte (MB)"},
        },
        2: {
            "input_file": {"type": "text", "default": "flows.json", "label": "Netflow JSON-bestand"},
        },
        3: {
            "interval": {"type": "number", "default": 2, "label": "Poll-interval (seconden)"},
            "duration": {"type": "number", "default": 3600, "label": "Looptijd (seconden)"},
        },
        4: {
            "mode": {"type": "select", "options": ["live", "synthetic"], "default": "synthetic", "label": "Modus"},
            "duration": {"type": "number", "default": 60, "label": "Meetduur (seconden)"},
            "interval": {"type": "number", "default": 0.1, "label": "Sample-interval (seconden)"},
            "synthetic_type": {"type": "select", "options": ["gaming", "idle", "llm_inference"], "default": "idle", "label": "Synthetisch scenario"},
        },
        5: {
            "action": {"type": "select", "options": ["measure", "sign", "verify"], "default": "measure", "label": "Actie"},
            "model_path": {"type": "text", "default": "model.gguf", "label": "Modelpad"},
            "nonce": {"type": "text", "default": "0123456789abcdef", "label": "Nonce (hex)"},
            "authority_key": {"type": "text", "default": "~/llm-detect-keys/authority_keys/private.pem", "label": "Authority private key"},
            "endpoint_key": {"type": "text", "default": "~/llm-detect-keys/endpoint_keys/private.pem", "label": "Endpoint private key"},
            "registry": {"type": "text", "default": "~/llm-detect-keys/registry.json", "label": "Registry pad"},
        },
    }
    return jsonify(params.get(layer_id, {}))

@app.route("/api/layer/<int:layer_id>/run", methods=["POST"])
def run_layer(layer_id):
    """Start een laag-taak."""
    unavailable = _layer_unavailable_response(layer_id)
    if unavailable is not None:
        return jsonify(unavailable), 404

    params = request.json or {}
    job_id = str(uuid.uuid4())[:8]

    thread = threading.Thread(target=run_layer_task, args=(job_id, layer_id, params), daemon=True)
    thread.start()

    return jsonify({"job_id": job_id, "status": "started"})

@app.route("/api/layer/2/generate-synthetic", methods=["POST"])
def generate_netflow_synthetic():
    """
    Genereert synthetische netflow-testdata direct vanuit de GUI (geen
    terminal nodig). Werkt op elk platform zonder extra afhankelijkheden —
    dit genereert testdata programmatisch, er wordt niets echt gevangen.
    """
    params = request.json or {}
    synthetic_type = params.get("synthetic_type", "gossip")
    out_path = os.path.expanduser(params.get("out_path", "~/llm-detect-results/test_gossip.json"))

    try:
        os.makedirs(os.path.dirname(out_path), exist_ok=True)
        cmd = [
            PYTHON_CMD, os.path.join(BASE_DIR, "netflow_gossip_detector.py"),
            "--generate-synthetic", synthetic_type
        ]
        with open(out_path, "w", encoding="utf-8") as f:
            result = subprocess.run(cmd, stdout=f, stderr=subprocess.PIPE, text=True, timeout=30)
        if result.returncode != 0:
            return jsonify({"error": f"Generatie mislukt: {result.stderr}"}), 500
        return jsonify({"path": out_path, "status": "ok"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/logs/realtime-agent", methods=["GET"])
def get_realtime_agent_logs():
    """
    Toont Laag 3's journaal (laatste N minuten) rechtstreeks in de GUI —
    voorheen moest de gebruiker daarvoor altijd naar een eigen terminal,
    ook al was de rest van "Testen & Simulatie" al volledig functioneel
    vanuit de GUI zelf. Alleen op Linux — journalctl bestaat niet op Windows.

    Vereist het beperkte sudo-recht uit llm-detect-logs.sudoers (uitsluitend
    journalctl voor déze ene systemd-dienst, geen algemene root- of
    journalctl-toegang — zie dat bestand voor de volledige toelichting).
    'sudo -n' (non-interactief), zelfde reden als bij de diagnose-route:
    een ontbrekend recht moet direct en duidelijk falen, niet voor altijd
    blijven hangen op een wachtwoordprompt die nooit komt.
    """
    if IS_WINDOWS:
        return jsonify({"error": "journalctl is alleen beschikbaar op Linux."}), 400

    minuten = request.args.get("minuten", "2")
    try:
        minuten_int = max(1, min(int(minuten), 60))  # redelijke grenzen, geen extreem lange/ongeldige waarden
    except ValueError:
        minuten_int = 2

    try:
        result = subprocess.run(
            ["sudo", "-n", "/usr/bin/journalctl", "-u", "llm-detect-realtime-agent.service",
             "--since", f"{minuten_int} min ago", "--no-pager"],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode != 0:
            return jsonify({
                "error": (
                    "Kon het journaal niet lezen — controleer of het sudo-recht "
                    "(/etc/sudoers.d/llm-detect-logs) daadwerkelijk aanwezig is. "
                    "Bijwerken naar deze versie installeert dit automatisch."
                ),
                "detail": result.stderr.strip()[:300],
            }), 500
        output = result.stdout.strip()
        return jsonify({"output": output if output else "(geen regels in dit tijdvak — dat is normaal als Laag 3 recent niets nieuws zag)"})
    except subprocess.TimeoutExpired:
        return jsonify({"error": "Time-out bij het lezen van het journaal."}), 500
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/version", methods=["GET"])
def get_version():
    """
    Leest het VERSION-bestand — puur informatief, voor weergave in de
    GUI-koptekst. Ontbrak tot nu toe volledig: geen enkele plek in de GUI
    toonde welke versie daadwerkelijk draaide, terwijl dit deze hele sessie
    al meermaals tot verwarring leidde bij het diagnosticeren van meldingen.
    """
    try:
        with open(os.path.join(BASE_DIR, "VERSION"), encoding="utf-8") as f:
            return jsonify({"version": f.read().strip()})
    except Exception:
        return jsonify({"version": "onbekend"})

@app.route("/api/diagnose/run", methods=["POST"])
def run_diagnose():
    """
    Start diagnose-detectiesuite.sh (optie 'e' in het installatieprogramma)
    als achtergrondtaak, met live-uitvoer via hetzelfde job-mechanisme als
    de vijf detectielagen. Alleen op Linux — er is geen Windows-equivalent.

    Vereist het beperkte sudo-recht uit llm-detect-diagnose.sudoers (alleen
    dit ene script, geen algemene root-toegang — zie dat bestand voor de
    volledige toelichting). 'sudo -n' (non-interactief) is bewust gekozen:
    zonder dat recht zou een gewone 'sudo'-aanroep hier voor altijd blijven
    hangen op een wachtwoordprompt die nooit komt (een web-request heeft
    geen interactief terminalvenster) — '-n' laat het in plaats daarvan
    direct, duidelijk falen.
    """
    if IS_WINDOWS:
        return jsonify({"error": "diagnose-detectiesuite.sh is alleen beschikbaar op Linux."}), 400

    job_id = str(uuid.uuid4())[:8]
    script_path = os.path.join(BASE_DIR, "diagnose-detectiesuite.sh")

    def run_diagnose_task():
        ACTIVE_JOBS[job_id] = {"status": "running", "output": "", "layer": "diagnose", "start": datetime.now().isoformat()}
        try:
            cmd = ["sudo", "-n", "/bin/bash", script_path]
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
            output_lines = []
            for line in proc.stdout:
                output_lines.append(line.rstrip())
                ACTIVE_JOBS[job_id]["output"] = "\n".join(output_lines[-300:])
            proc.wait()
            ACTIVE_JOBS[job_id]["status"] = "done"
            ACTIVE_JOBS[job_id]["return_code"] = proc.returncode
            if proc.returncode != 0:
                ACTIVE_JOBS[job_id]["error_summary"] = (
                    "Diagnose eindigde met een foutcode — controleer of het sudo-recht "
                    "(/etc/sudoers.d/llm-detect-diagnose) daadwerkelijk aanwezig is. "
                    "Bijwerken naar deze versie installeert dit automatisch."
                )
        except Exception as e:
            ACTIVE_JOBS[job_id]["status"] = "error"
            ACTIVE_JOBS[job_id]["error"] = str(e)
        finally:
            ACTIVE_JOBS[job_id]["end"] = datetime.now().isoformat()

    thread = threading.Thread(target=run_diagnose_task, daemon=True)
    thread.start()
    return jsonify({"job_id": job_id, "status": "started"})

@app.route("/api/pentest/run", methods=["POST"])
def run_pentest():
    """
    Start pentest_simulator.py als achtergrondtaak — bewust GEEN sudo nodig,
    het script schrijft uitsluitend naar mappen die al van de gebruiker
    zijn (zie pentest_simulator.py's eigen documentatie).
    """
    params = request.json or {}
    scenario = params.get("scenario", "all")
    flag_map = {"all": "--all", "model": "--model-only", "netflow": "--netflow-only", "gpu": "--gpu-only", "attestation": "--attestation-only"}
    if scenario not in flag_map:
        return jsonify({"error": f"Onbekend scenario: {scenario}"}), 400

    job_id = str(uuid.uuid4())[:8]
    script_path = os.path.join(BASE_DIR, "pentest_simulator.py")

    def run_pentest_task():
        ACTIVE_JOBS[job_id] = {"status": "running", "output": "", "layer": "pentest", "start": datetime.now().isoformat()}
        try:
            cmd = [PYTHON_CMD, "-u", script_path, flag_map[scenario]]
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
            output_lines = []
            for line in proc.stdout:
                output_lines.append(line.rstrip())
                ACTIVE_JOBS[job_id]["output"] = "\n".join(output_lines[-300:])
            proc.wait()
            ACTIVE_JOBS[job_id]["status"] = "done"
            ACTIVE_JOBS[job_id]["return_code"] = proc.returncode
            if proc.returncode != 0:
                ACTIVE_JOBS[job_id]["error_summary"] = "Script eindigde met een foutcode — zie de uitvoer hierboven."
        except Exception as e:
            ACTIVE_JOBS[job_id]["status"] = "error"
            ACTIVE_JOBS[job_id]["error"] = str(e)
        finally:
            ACTIVE_JOBS[job_id]["end"] = datetime.now().isoformat()

    thread = threading.Thread(target=run_pentest_task, daemon=True)
    thread.start()
    return jsonify({"job_id": job_id, "status": "started"})

@app.route("/api/pentest/cleanup", methods=["POST"])
def run_pentest_cleanup():
    """Start pentest_simulator.py --cleanup als achtergrondtaak."""
    job_id = str(uuid.uuid4())[:8]
    script_path = os.path.join(BASE_DIR, "pentest_simulator.py")

    def run_cleanup_task():
        ACTIVE_JOBS[job_id] = {"status": "running", "output": "", "layer": "pentestcleanup", "start": datetime.now().isoformat()}
        try:
            result = subprocess.run([PYTHON_CMD, "-u", script_path, "--cleanup"], capture_output=True, text=True, timeout=30)
            ACTIVE_JOBS[job_id]["output"] = result.stdout + result.stderr
            ACTIVE_JOBS[job_id]["status"] = "done"
            ACTIVE_JOBS[job_id]["return_code"] = result.returncode
        except Exception as e:
            ACTIVE_JOBS[job_id]["status"] = "error"
            ACTIVE_JOBS[job_id]["error"] = str(e)
        finally:
            ACTIVE_JOBS[job_id]["end"] = datetime.now().isoformat()

    thread = threading.Thread(target=run_cleanup_task, daemon=True)
    thread.start()
    return jsonify({"job_id": job_id, "status": "started"})

@app.route("/api/history", methods=["GET"])
def get_history():
    """
    Chronologisch overzicht van alles wat er is gebeurd: elk resultaatbestand
    (van elke laag, en elke correlatie-run) als één leesbare regel, nieuwste
    eerst. Bedoeld als simpel 'wat is er gebeurd'-overzicht, los van de
    per-laag-tabbladen.
    """
    SKIP_MARKERS = ("_tmp_", "_samples", "manifest_", "stix_", ".write_test")
    LAYER_PREFIXES = [
        (1, "laag1_"), (2, "laag2_"), (3, "laag3_"), (4, "laag4_"), (5, "laag5_verify_"),
    ]

    entries = []
    all_files = sorted(RESULTS_DIR.glob("*.json"), key=lambda x: x.stat().st_mtime, reverse=True)

    for f in all_files:
        if any(marker in f.name for marker in SKIP_MARKERS):
            continue

        timestamp = datetime.fromtimestamp(f.stat().st_mtime).isoformat()

        try:
            with open(f, encoding="utf-8") as fh:
                data = json.load(fh)
        except Exception:
            continue

        if f.name.startswith("correlatie_"):
            if not data:
                continue
            top = max(data, key=lambda r: r.get("correlated_score", 0))
            entries.append({
                "timestamp": timestamp,
                "type": "Correlatie",
                "icon": "📊",
                "summary": f"{len(data)} endpoint(s) — hoogste score {top.get('correlated_score', 0)} ({top.get('host', '?')})",
                "filename": f.name,
            })
            continue

        layer_id = None
        for lid, prefix in LAYER_PREFIXES:
            if f.name.startswith(prefix):
                layer_id = lid
                break
        if layer_id is None:
            continue

        light, detail = _derive_layer_light(layer_id, data)
        entries.append({
            "timestamp": timestamp,
            "type": LAYER_META_NAMES.get(layer_id, f"Laag {layer_id}"),
            "icon": LAYER_META_ICONS.get(layer_id, "•"),
            "summary": detail,
            "light": light,
            "filename": f.name,
        })

    return jsonify({"entries": entries[:100]})


LAYER_META_NAMES = {1: "Laag 1: Bestand/Proces", 2: "Laag 2: Netflow", 3: "Laag 3: Kernel-Agent", 4: "Laag 4: GPU", 5: "Laag 5: TPM"}
LAYER_META_ICONS = {1: "📁", 2: "🌐", 3: "⚡", 4: "🎮", 5: "🔐"}


@app.route("/api/history/reset", methods=["POST"])
def reset_history():
    """
    Verwijdert alle resultaatbestanden uit de geschiedenis. Vereist een
    expliciete bevestiging vanuit de GUI (niet zomaar één klik) — dit is
    onomkeerbaar. Sleutels/registry (~/llm-detect-keys/) blijven ONGEMOEID;
    dit raakt alleen scan-/detectieresultaten in RESULTS_DIR.
    """
    confirm = request.json.get("confirm") if request.json else False
    if not confirm:
        return jsonify({"error": "Bevestiging vereist."}), 400

    deleted = 0
    for f in RESULTS_DIR.glob("*.json"):
        try:
            f.unlink()
            deleted += 1
        except OSError:
            pass

    return jsonify({"deleted": deleted})


@app.route("/api/layer/5/registry", methods=["GET"])
def get_model_registry():
    """
    Leest de model-registry en geeft per model de huidige status terug
    (toegestaan/ingetrokken), voor de checkbox-lijst in de GUI.
    """
    registry_path = os.path.expanduser(request.args.get("registry", "~/llm-detect-keys/registry.json"))
    if not os.path.exists(registry_path):
        return jsonify({"models": []})

    try:
        with open(registry_path, encoding="utf-8") as f:
            registry = json.load(f)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    revoked_hashes = {r["sha256"]: r.get("reason", "") for r in registry.get("revoked", [])}
    models = []
    for m in registry.get("models", []):
        is_revoked = m["sha256"] in revoked_hashes
        models.append({
            "name": m.get("name", "(zonder naam)"),
            "sha256": m["sha256"],
            "sha256_short": m["sha256"][:12],
            "signed_at": m.get("signed_at"),
            "allowed": not is_revoked,
            "revoked_reason": revoked_hashes.get(m["sha256"], ""),
        })
    return jsonify({"models": models})


@app.route("/api/layer/5/apparmor-binaries", methods=["GET"])
def get_apparmor_binaries():
    """Leest de lijst met programma's die via AppArmor bewaakt worden bij
    intrekking (registry['apparmor_binaries']) — de aanvulling op chmod die
    ook tegen een root-draaiend proces (bijv. een systeembreed geïnstalleerde
    Ollama) standhoudt. Leeg/afwezig betekent: alleen chmod, geen AppArmor."""
    registry_path = os.path.expanduser(request.args.get("registry", "~/llm-detect-keys/registry.json"))
    if not os.path.exists(registry_path):
        return jsonify({"binaries": [], "apparmor_available": False})
    try:
        with open(registry_path, encoding="utf-8") as f:
            registry = json.load(f)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

    try:
        import apparmor_enforcement as aa
        available = aa.is_apparmor_available()
    except Exception:
        available = False

    return jsonify({"binaries": registry.get("apparmor_binaries", []), "apparmor_available": available})


@app.route("/api/layer/5/apparmor-binaries", methods=["POST"])
def set_apparmor_binaries():
    """Slaat de lijst met te bewaken programma's op in de registry. Past
    bewust nog GEEN bestaande, al-ingetrokken modellen met terugwerkende
    kracht aan — een nieuw toegevoegd programma geldt pas voor toekomstige
    intrekkingen. Dat is een bewuste, eenvoudige keuze: met terugwerkende
    kracht alle historische intrekkingen opnieuw doorlopen zou trager en
    foutgevoeliger zijn dan wat dit scope-1-onderdeel rechtvaardigt."""
    data = request.get_json(force=True)
    registry_path = os.path.expanduser(data.get("registry", "~/llm-detect-keys/registry.json"))
    binaries = data.get("binaries", [])
    if not isinstance(binaries, list) or not all(isinstance(b, str) for b in binaries):
        return jsonify({"error": "binaries moet een lijst van tekstuele paden zijn"}), 400

    registry = {"models": [], "revoked": []}
    if os.path.exists(registry_path):
        try:
            with open(registry_path, encoding="utf-8") as f:
                registry = json.load(f)
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    registry["apparmor_binaries"] = [b.strip() for b in binaries if b.strip()]
    os.makedirs(os.path.dirname(registry_path), exist_ok=True)
    with open(registry_path, "w", encoding="utf-8") as f:
        json.dump(registry, f, indent=2)

    return jsonify({"status": "ok", "binaries": registry["apparmor_binaries"]})


@app.route("/api/layer/5/toggle-model", methods=["POST"])
def toggle_model_status():
    """
    Trekt een model in (allowed=false) of maakt een eerdere intrekking
    ongedaan (allowed=true), via de CLI van tpm_model_attestation.py — zelfde
    architectuur als de rest van Laag 5 in deze GUI (subprocess i.p.v.
    rechtstreeks importeren).
    """
    params = request.json or {}
    sha256 = params.get("sha256")
    allow = params.get("allowed")
    registry_path = os.path.expanduser(params.get("registry", "~/llm-detect-keys/registry.json"))
    authority_key = os.path.expanduser(params.get("authority_key", "~/llm-detect-keys/authority_keys/private.pem"))
    authority_pubkey = os.path.expanduser(params.get("authority_pubkey", "~/llm-detect-keys/authority_keys/public.pem"))

    if not sha256 or allow is None:
        return jsonify({"error": "sha256 en allowed zijn verplicht"}), 400

    if allow:
        cmd = [
            PYTHON_CMD, os.path.join(BASE_DIR, "tpm_model_attestation.py"),
            "unrevoke", "--sha256", sha256,
            "--authority-key", authority_key,
            "--authority-pubkey", authority_pubkey,
            "--registry", registry_path,
        ]
    else:
        cmd = [
            PYTHON_CMD, os.path.join(BASE_DIR, "tpm_model_attestation.py"),
            "revoke", "--sha256", sha256,
            "--authority-key", authority_key,
            "--registry", registry_path,
            "--reason", params.get("reason", "Ingetrokken via GUI"),
        ]

    result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
    if result.returncode != 0:
        return jsonify({"error": result.stderr.strip() or result.stdout.strip()}), 400
    return jsonify({"status": "ok", "output": result.stdout.strip()})


_hash_cache = {}  # (pad, mtime, grootte) -> sha256-hex — voorkomt herhaald volledig
                  # inlezen van dezelfde (vaak grote) bestanden bij elke keer
                  # dat de Laag 5-dropdown geopend wordt. In-memory, dus reset
                  # bij een herstart van de GUI — geen probleem, want dan wordt
                  # gewoon opnieuw gehasht zodra nodig.


@app.route("/api/layer/5/discovered-models", methods=["GET"])
def discovered_models():
    """
    Zoekt in het meest recente Laag 1-resultaat naar GGUF/model-bestanden, en
    geeft per gevonden bestand aan of het al in de registry staat — zodat de
    GUI een lijst kan tonen van 'modellen die op dit systeem gevonden zijn
    maar nog niet expliciet zijn goed- of afgekeurd'.
    """
    registry_path = os.path.expanduser(request.args.get("registry", "~/llm-detect-keys/registry.json"))
    known_hashes = set()
    if os.path.exists(registry_path):
        try:
            with open(registry_path, encoding="utf-8") as f:
                registry = json.load(f)
            known_hashes = {m["sha256"] for m in registry.get("models", [])}
        except Exception:
            pass

    laag1_files = sorted(
        [f for f in RESULTS_DIR.glob("laag1_*.json") if "_samples" not in f.name],
        key=lambda x: x.stat().st_mtime, reverse=True
    )
    if not laag1_files:
        return jsonify({"models": []})

    # Voorheen werd uitsluitend het allerlaatste Laag 1-bestand gebruikt —
    # ongeacht of dat een smalle, handmatige scan was (standaard-scanpad
    # /home) of de brede, uurlijkse volledige scan (--path /). Gevolg: een
    # latere, smallere scan liet modellen die de volledige scan eerder al
    # wél vond (bijv. Ollama-modellen onder /usr/share/ollama/...) stil uit
    # dit overzicht verdwijnen, ook al stonden ze nog gewoon, geldig op
    # schijf. Gevonden via een reëel geval: 13+ Ollama-modellen die 'ollama
    # list' wél toonde, maar hier niet verschenen. Nu: het meest recente
    # bestand blijft leidend, aangevuld met de meest recente
    # laag1_fullscan_*.json specifiek (altijd --path /, dus altijd
    # betrouwbaar volledig) — resultaten samengevoegd, op hash gededupliceerd.
    bronnen = [laag1_files[0]]
    fullscan_files = sorted(
        [f for f in laag1_files if f.name.startswith("laag1_fullscan_")],
        key=lambda x: x.stat().st_mtime, reverse=True
    )
    if fullscan_files and fullscan_files[0] not in bronnen:
        bronnen.append(fullscan_files[0])

    entries = []
    for bron in bronnen:
        try:
            with open(bron, encoding="utf-8") as f:
                entries.extend(json.load(f).get("files", []))
        except Exception:
            continue
    if not entries:
        return jsonify({"models": []})

    discovered = []
    seen_hashes = set()
    for entry in entries:
        path = entry.get("path")
        if not path or not os.path.exists(path):
            continue
        # Alleen bestanden die daadwerkelijk als model-signatuur zijn herkend
        if not any("GGUF" in f or "SafeTensors" in f or "gekwantiseerd" in f for f in entry.get("findings", [])):
            continue
        try:
            stat = os.stat(path)
            cache_key = (path, stat.st_mtime, stat.st_size)
            if cache_key in _hash_cache:
                file_hash = _hash_cache[cache_key]
            else:
                h = hashlib.sha256()
                with open(path, "rb") as fh:
                    while chunk := fh.read(1024 * 1024):
                        h.update(chunk)
                file_hash = h.hexdigest()
                _hash_cache[cache_key] = file_hash
        except OSError:
            continue
        if file_hash in seen_hashes:
            continue  # zelfde bestand via meerdere paden/bronnen, niet dubbel tonen
        seen_hashes.add(file_hash)
        discovered.append({
            "path": path,
            "sha256": file_hash,
            "already_signed": file_hash in known_hashes,
            "incomplete_download": entry.get("incomplete_download", False),
        })

    return jsonify({"models": discovered})


@app.route("/api/settings/notifications", methods=["GET"])
def get_notification_settings():
    return jsonify(notification_helper.load_settings())


@app.route("/api/settings/notifications", methods=["POST"])
def save_notification_settings():
    incoming = request.json or {}
    valid_severities = notification_helper.SEVERITY_ORDER
    if incoming.get("min_severity") not in valid_severities:
        return jsonify({"error": f"min_severity moet één van {valid_severities} zijn"}), 400
    saved = notification_helper.save_settings(incoming)
    return jsonify(saved)


@app.route("/api/settings/test-notification", methods=["POST"])
def send_test_notification():
    settings = notification_helper.load_settings()
    result = notification_helper.dispatch_notifications(
        score=100, host="test-melding", firing_domains=["dit is een test"], settings=settings
    )
    return jsonify(result)


@app.route("/api/settings/reset-integrity-key", methods=["POST"])
def reset_integrity_key():
    """
    Verwijdert het huidige resultaat-ondertekeningssleutelpaar. Bewust
    destructief en zonder eigen bevestigingslaag hier — de bevestiging
    hoort in de GUI zelf te zitten (een expliciete tweede klik), niet
    hierin verstopt, zodat een los API-verzoek nooit per ongeluk dit
    effect kan hebben zonder dat de gebruiker dat zag aankomen.

    Na reset genereert de eerstvolgende laag-run automatisch een nieuw
    sleutelpaar (zelfde gedrag als bij een verse installatie) — maar elk
    bestaand, eerder ondertekend resultaat wordt dan 'unsigned' in plaats
    van 'valid', want de oude handtekeningen horen niet meer bij de
    nieuwe sleutel.
    """
    import result_integrity as _ri
    key_dir = _ri.resolve_key_dir()
    priv_path = os.path.join(key_dir, "result_signing_private.pem")
    pub_path = os.path.join(key_dir, "result_signing_public.pem")
    removed = []
    for p in (priv_path, pub_path):
        if os.path.isfile(p):
            os.remove(p)
            removed.append(os.path.basename(p))
    return jsonify({"status": "ok", "removed": removed})


QUICK_SCAN_JOBS = {}


@app.route("/api/quick-scan", methods=["POST"])
def start_quick_scan():
    """
    Eén-klik-gezondheidscheck: draait Laag 1 (volledig), Laag 3 (kort, 30s
    i.p.v. de standaard 3600s — dit is bewust een QUICK-check, geen continue
    monitoring) en Laag 4 (synthetisch, kort), wacht tot alle drie klaar
    zijn, bouwt dan automatisch het manifest op en draait de correlatie.
    Laag 2 en 5 worden bewust overgeslagen: die vereisen eigen invoer
    (een netflow-databestand, resp. een modelpad + sleutels) die niet
    zinvol automatisch te verzinnen zijn.
    """
    for lid in (1, 3, 4):
        unavailable = _layer_unavailable_response(lid)
        if unavailable is not None:
            return jsonify({
                "error": "Snelle Systeemscan is niet inbegrepen in deze installatie.",
                "detail": "Deze functie vereist Laag 1, 3 en 4, die niet allemaal aanwezig zijn in deze installatie (bijv. de Wachter-tier, met alleen Laag 2).",
            }), 404

    orchestration_id = str(uuid.uuid4())[:8]
    QUICK_SCAN_JOBS[orchestration_id] = {"done": False, "correlated_score": None}

    def orchestrate():
        sub_job_ids = []
        for layer_id, params in [
            (1, {"mode": "all", "path": "/home", "min_size": 50}),
            (3, {"interval": 2, "duration": 30}),
            (4, {"mode": "synthetic", "synthetic_type": "idle", "duration": 15}),
        ]:
            job_id = str(uuid.uuid4())[:8]
            sub_job_ids.append(job_id)
            thread = threading.Thread(target=run_layer_task, args=(job_id, layer_id, params), daemon=True)
            thread.start()

        # Wacht tot alle drie sub-taken klaar zijn (max ~90s als vangnet)
        waited = 0
        while waited < 90:
            if all(ACTIVE_JOBS.get(jid, {}).get("status") in ("done", "error") for jid in sub_job_ids):
                break
            time.sleep(2)
            waited += 2

        # Manifest automatisch opbouwen (dezelfde logica als de bestaande knop)
        prefix_map = {"local_scan": "laag1_", "netflow": "laag2_", "realtime_agent": "laag3_",
                      "gpu_fingerprint": "laag4_", "attestation": "laag5_verify_"}
        reports = {}
        for key, prefix in prefix_map.items():
            candidates = sorted(
                [f for f in RESULTS_DIR.glob(f"{prefix}*.json") if "_samples" not in f.name],
                key=lambda x: x.stat().st_mtime, reverse=True
            )
            if candidates:
                reports[key] = str(candidates[0])

        if not reports:
            QUICK_SCAN_JOBS[orchestration_id] = {"done": True, "correlated_score": None}
            return

        manifest = {"endpoints": [{"host": "quick-scan-endpoint", "reports": reports}]}
        manifest_path = RESULTS_DIR / f"manifest_quickscan_{orchestration_id}.json"
        with open(manifest_path, "w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=2)

        correlatie_path = RESULTS_DIR / f"correlatie_quickscan_{orchestration_id}.json"
        cmd = [PYTHON_CMD, "-u", os.path.join(BASE_DIR, "correlation_engine.py"),
               "--manifest", str(manifest_path), "--json", str(correlatie_path)]
        subprocess.run(cmd, capture_output=True, text=True, timeout=30)

        score = None
        try:
            with open(correlatie_path, encoding="utf-8") as f:
                results = json.load(f)
            if results:
                score = max(r.get("correlated_score", 0) for r in results)
                notification_helper.dispatch_notifications(
                    score=score, host=results[0].get("host", "onbekend"),
                    firing_domains=results[0].get("firing_domains", []),
                )
        except Exception:
            pass

        QUICK_SCAN_JOBS[orchestration_id] = {"done": True, "correlated_score": score}

    threading.Thread(target=orchestrate, daemon=True).start()
    return jsonify({"orchestration_id": orchestration_id, "status": "started"})


@app.route("/api/quick-scan/<orchestration_id>", methods=["GET"])
def get_quick_scan_status(orchestration_id):
    return jsonify(QUICK_SCAN_JOBS.get(orchestration_id, {"done": False, "correlated_score": None}))


@app.route("/api/calibration-report", methods=["GET"])
def calibration_report():
    """
    Bundelt alles wat het systeem binnen een datumbereik heeft gemeten,
    gezien en gealarmeerd tot één downloadbaar rapport — met samenvattende
    statistieken erbij, niet alleen ruwe bestanden. Bedoeld om in één keer
    te delen voor kalibratie-analyse, i.p.v. losse resultaten handmatig te
    moeten verzamelen.
    """
    date_from_str = request.args.get("from")
    date_to_str = request.args.get("to")
    try:
        report = _build_calibration_report(date_from_str, date_to_str)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

    filename = f"kalibratie-rapport_{date_from_str or 'begin'}_tot_{date_to_str or 'nu'}.json"
    response = jsonify(report)
    response.headers["Content-Disposition"] = f"attachment; filename={filename}"
    return response


@app.route("/api/calibration-report/compare", methods=["GET"])
def calibration_report_compare():
    """
    Legt twee periodes naast elkaar en toont alleen het verschil: welke
    apparaten, cloud-AI-diensten en modellen zijn nieuw bijgekomen in
    periode B t.o.v. periode A? Bedoeld om snel te zien 'wat is er sinds
    de vorige keer veranderd', i.p.v. handmatig twee volledige rapporten
    naast elkaar te moeten leggen.

    Query-parameters: from_a, to_a (periode A, de oudere/referentie-periode),
    from_b, to_b (periode B, meestal 'nu', mag leeg voor 'tot nu').
    """
    try:
        report_a = _build_calibration_report(request.args.get("from_a"), request.args.get("to_a"))
        report_b = _build_calibration_report(request.args.get("from_b"), request.args.get("to_b"))
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

    return jsonify({
        "periode_a": {"from": request.args.get("from_a"), "to": request.args.get("to_a")},
        "periode_b": {"from": request.args.get("from_b"), "to": request.args.get("to_b")},
        "modellen_a": report_a.get("model_statistics", {}),
        "modellen_b": report_b.get("model_statistics", {}),
        "nieuwe_modellen": max(0, report_b.get("model_statistics", {}).get("totaal_modellen", 0)
                                - report_a.get("model_statistics", {}).get("totaal_modellen", 0)),
    })


def _finding_fingerprint(layer_id, light, detail):
    """
    Vingerafdruk van een BEVINDINGSTYPE, niet van een exacte gebeurtenis —
    tijdstempels en bestandsnamen tellen bewust niet mee, anders zou
    'dempen' nooit iets herkennen (elk resultaat heeft een andere tijd).
    Genormaliseerd (kleine letters, geknipt) zodat kleine tekstverschillen
    dezelfde vingerafdruk opleveren.
    """
    normalized = f"{layer_id}|{light}|{(detail or '').strip().lower()[:200]}"
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:16]


def _load_dismissed_fingerprints():
    path = os.path.expanduser("~/llm-detect-results/dismissed_findings.json")
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save_dismissed_fingerprints(data):
    path = os.path.expanduser("~/llm-detect-results/dismissed_findings.json")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


@app.route("/api/findings/dismiss", methods=["POST"])
def dismiss_finding():
    """
    Markeert een BEVINDINGSTYPE als 'bekend, beoordeeld, onschuldig' — bijv.
    de eigen Ollama-laadactiviteit die telkens als HOOG terugkomt. Werkt op
    basis van de vingerafdruk (laag + severity + genormaliseerde detailtekst),
    dus dempt voortaan elke toekomstige bevinding die op hetzelfde neerkomt,
    niet alleen dit ene exemplaar.
    """
    params = request.json or {}
    layer_id = params.get("layer_id")
    light = params.get("light")
    detail = params.get("detail", "")
    reason = params.get("reason", "")
    if layer_id is None or light is None:
        return jsonify({"error": "layer_id en light zijn verplicht"}), 400

    fp = _finding_fingerprint(layer_id, light, detail)
    dismissed = _load_dismissed_fingerprints()
    dismissed[fp] = {
        "layer_id": layer_id, "light": light, "detail_preview": (detail or "")[:200],
        "reason": reason, "dismissed_at": datetime.now().isoformat(),
    }
    _save_dismissed_fingerprints(dismissed)
    return jsonify({"status": "ok", "fingerprint": fp, "total_dismissed": len(dismissed)})


@app.route("/api/findings/dismissed", methods=["GET"])
def list_dismissed_findings():
    """Overzicht van alle gedempte bevindingstypes — voor beheer/intrekken."""
    return jsonify(_load_dismissed_fingerprints())


@app.route("/api/findings/dismiss/<fingerprint>", methods=["DELETE"])
def undismiss_finding(fingerprint):
    """Trekt een eerdere demping in — de bevinding telt weer gewoon mee."""
    dismissed = _load_dismissed_fingerprints()
    if fingerprint in dismissed:
        del dismissed[fingerprint]
        _save_dismissed_fingerprints(dismissed)
        return jsonify({"status": "ok"})
    return jsonify({"error": "Vingerafdruk niet gevonden"}), 404


def _get_environment_info():
    """
    Minimale omgevingscontext bij een rapport — met meerdere machines
    (bijv. Dell + Lenovo) in gebruik is 'van welke machine komt dit
    eigenlijk' geen theoretische vraag meer.
    """
    info = {
        "hostname": platform.node(),
        "os": platform.platform(),
        "python_version": platform.python_version(),
    }
    try:
        import pynvml
        pynvml.nvmlInit()
        info["gpu"] = pynvml.nvmlDeviceGetName(pynvml.nvmlDeviceGetHandleByIndex(0))
        pynvml.nvmlShutdown()
    except Exception:
        info["gpu"] = "geen NVIDIA-GPU gedetecteerd (of pynvml niet beschikbaar)"
    return info


def _get_model_statistics():
    """
    Samenvatting van de Laag 5-modelregistry — hoeveel modellen zijn hier
    ooit gezien, hoeveel daarvan zijn bewust geautoriseerd. Deze data
    bestond al (registry.json), maar stond nog nergens samengevat in een
    rapport.

    Schema (zie tpm_model_attestation.py): "models" is een LIJST van
    modelobjecten (elk met een eigen "sha256"), en "revoked" is een
    LOSSE, aparte lijst van intrekkingsvermeldingen — geen vlag op het
    model zelf. Een model is ingetrokken dan en slechts dan als zijn
    sha256 voorkomt in die aparte revoked-lijst.
    """
    keys_base = os.environ.get("LLM_DETECT_KEYS_BASE") or os.path.expanduser("~/llm-detect-keys")
    registry_path = os.path.join(keys_base, "registry.json")
    stats = {"totaal_modellen": 0, "geautoriseerd": 0, "ingetrokken": 0}
    try:
        with open(registry_path, encoding="utf-8") as f:
            registry = json.load(f)
        models = registry.get("models", [])
        revoked_hashes = {r.get("sha256") for r in registry.get("revoked", [])}
        stats["totaal_modellen"] = len(models)
        for m in models:
            if m.get("sha256") in revoked_hashes:
                stats["ingetrokken"] += 1
            else:
                stats["geautoriseerd"] += 1
    except Exception:
        pass
    return stats


def _build_calibration_report(date_from_str, date_to_str):
    try:
        date_from = datetime.fromisoformat(date_from_str).timestamp() if date_from_str else 0
    except ValueError:
        raise ValueError(f"Ongeldige 'from'-datum: {date_from_str}")
    try:
        # 'to' is inclusief de hele dag: tel er (bijna) 24 uur bij op
        date_to = (datetime.fromisoformat(date_to_str).timestamp() + 86399) if date_to_str else time.time()
    except ValueError:
        raise ValueError(f"Ongeldige 'to'-datum: {date_to_str}")

    SKIP_MARKERS = ("_tmp_", "_samples", "manifest_", ".write_test")
    LAYER_PREFIXES = [(1, "laag1_"), (2, "laag2_"), (3, "laag3_"), (4, "laag4_"), (5, "laag5_verify_")]

    findings_by_layer = {str(lid): [] for lid, _ in LAYER_PREFIXES}
    correlation_results = []
    severity_counts = {"onbekend": 0, "schoon": 0, "aandacht": 0, "kritiek": 0}
    highest_score = 0.0
    dismissed_fingerprints = _load_dismissed_fingerprints()

    all_files = sorted(RESULTS_DIR.glob("*.json"), key=lambda x: x.stat().st_mtime)
    for f in all_files:
        mtime = f.stat().st_mtime
        if mtime < date_from or mtime > date_to:
            continue
        if any(marker in f.name for marker in SKIP_MARKERS):
            continue

        timestamp = datetime.fromtimestamp(mtime).isoformat()
        try:
            with open(f, encoding="utf-8") as fh:
                data = json.load(fh)
        except Exception:
            continue

        integrity_status = "onbekend"
        try:
            import result_integrity as _ri
            _key_dir = _ri.resolve_key_dir()
            _pub = _ri.get_public_key(_key_dir)
            integrity_status = _ri.verify_result_file(str(f), _pub)["status"]
        except Exception:
            pass

        if f.name.startswith("correlatie_"):
            if isinstance(data, list):
                for r in data:
                    correlation_results.append({
                        "timestamp": timestamp, "filename": f.name,
                        "host": r.get("host"), "score": r.get("correlated_score", 0),
                        "firing_domains": r.get("firing_domains", []),
                        "integrity": integrity_status,
                    })
                    highest_score = max(highest_score, r.get("correlated_score", 0))
            continue

        layer_id = None
        for lid, prefix in LAYER_PREFIXES:
            if f.name.startswith(prefix):
                layer_id = lid
                break
        if layer_id is None:
            continue

        light, detail = _derive_layer_light(layer_id, data)
        findings = _extract_findings(layer_id, data)
        severity_counts[light] = severity_counts.get(light, 0) + 1
        fp = _finding_fingerprint(layer_id, light, detail)
        findings_by_layer[str(layer_id)].append({
            "timestamp": timestamp, "filename": f.name, "light": light, "detail": detail, "findings": findings,
            "integrity": integrity_status, "dismissed": fp in dismissed_fingerprints,
        })

    return {
        "generated_at": datetime.now().isoformat(),
        "date_range": {
            "from": date_from_str or "(vanaf het begin)",
            "to": date_to_str or "(tot nu)",
        },
        "environment": _get_environment_info(),
        "model_statistics": _get_model_statistics(),
        "summary": {
            "total_result_files": sum(len(v) for v in findings_by_layer.values()) + len(correlation_results),
            "results_per_laag": {k: len(v) for k, v in findings_by_layer.items()},
            "severity_verdeling": severity_counts,
            "correlatie_runs": len(correlation_results),
            "hoogste_correlatiescore": highest_score,
            "gedempte_bevindingstypes_actief": len(dismissed_fingerprints),
            "integriteit_gemanipuleerd": sum(
                1 for v in findings_by_layer.values() for item in v if item.get("integrity") == "tampered"
            ) + sum(1 for r in correlation_results if r.get("integrity") == "tampered"),
        },
        "findings_by_layer": findings_by_layer,
        "correlation_results": correlation_results,
    }


def _flatten_report_to_rows(report: dict) -> list:
    """
    Herleidt de geneste rapportstructuur tot één platte lijst van rijen —
    nodig voor CSV/XML, die beide van nature tabelvormig zijn. Elke rij
    krijgt dezelfde kolommen, ongeacht bron (laag-bevinding of correlatie),
    zodat het in één spreadsheet/XML-parser te openen is zonder eerst
    meerdere verschillende structuren te moeten begrijpen.
    """
    rows = []
    for layer_id, findings in report["findings_by_layer"].items():
        for f in findings:
            rows.append({
                "timestamp": f["timestamp"],
                "type": "laag_bevinding",
                "laag": layer_id,
                "host": "",
                "severity_of_score": f["light"],
                "detail": f["detail"],
                "bevindingen": "; ".join(f.get("findings", [])),
                "integriteit": f.get("integrity", "onbekend"),
                "bestand": f["filename"],
            })
    for r in report["correlation_results"]:
        rows.append({
            "timestamp": r["timestamp"],
            "type": "correlatie",
            "laag": "",
            "host": r.get("host", ""),
            "severity_of_score": r.get("score", ""),
            "detail": "",
            "bevindingen": "; ".join(r.get("firing_domains", [])),
            "integriteit": r.get("integrity", "onbekend"),
            "bestand": r["filename"],
        })
    rows.sort(key=lambda r: r["timestamp"])
    return rows


def _sanitize_csv_cell(value):
    """
    Voorkomt CSV-/formule-injectie (OWASP: 'CSV Injection'). Een celwaarde
    die begint met =, +, -, @, tab of CR wordt door Excel/LibreOffice als
    FORMULE geïnterpreteerd, niet als tekst — bijv. =cmd|'/c calc'!A1 kan
    dan willekeurige code uitvoeren zodra iemand het bestand opent. Deze
    waarden komen uit door het netwerk beïnvloedbare data (bijv. een
    hostnaam), dus expliciete sanitisatie is nodig, niet optioneel.
    Een voorloop-apostrof dwingt de spreadsheet-applicatie de waarde als
    platte tekst te behandelen, zonder de zichtbare inhoud te veranderen.
    """
    text = str(value)
    if text and text[0] in ("=", "+", "-", "@", "\t", "\r"):
        return "'" + text
    return text


@app.route("/api/calibration-report/csv", methods=["GET"])
def calibration_report_csv():
    """CSV-export van hetzelfde kalibratie-rapport — voor Excel/spreadsheet-analyse of overdracht aan derden (bijv. een pentester of auditor)."""
    date_from_str = request.args.get("from")
    date_to_str = request.args.get("to")
    try:
        report = _build_calibration_report(date_from_str, date_to_str)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

    rows = _flatten_report_to_rows(report)
    output = io.StringIO()
    fieldnames = ["timestamp", "type", "laag", "host", "severity_of_score", "detail", "bevindingen", "integriteit", "bestand"]
    writer = csv.DictWriter(output, fieldnames=fieldnames)
    writer.writeheader()

    # environment/model_statistics zijn geen gebeurtenissen, maar horen wel
    # in de export — anders staat deze info alleen in de JSON-variant. CSV
    # is fundamenteel tabelvormig, dus dit gaat als extra rijen vooraan,
    # binnen hetzelfde kolomschema (info in de detail-kolom), i.p.v. een
    # tweede, incompatibele structuur te introduceren.
    env = report.get("environment", {})
    if env:
        writer.writerow({
            "timestamp": report.get("generated_at", ""), "type": "omgeving", "laag": "", "host": env.get("hostname", ""),
            "severity_of_score": "", "detail": f"OS: {env.get('os', '')} | Python: {env.get('python_version', '')} | GPU: {env.get('gpu', '')}",
            "bevindingen": "", "integriteit": "", "bestand": "",
        })
    stats = report.get("model_statistics", {})
    if stats:
        writer.writerow({
            "timestamp": report.get("generated_at", ""), "type": "modelstatistiek", "laag": "5", "host": "",
            "severity_of_score": "",
            "detail": f"Totaal: {stats.get('totaal_modellen', 0)} | Geautoriseerd: {stats.get('geautoriseerd', 0)} | Ingetrokken: {stats.get('ingetrokken', 0)}",
            "bevindingen": "", "integriteit": "", "bestand": "",
        })

    for row in rows:
        writer.writerow({k: _sanitize_csv_cell(v) for k, v in row.items()})

    filename = f"kalibratie-rapport_{date_from_str or 'begin'}_tot_{date_to_str or 'nu'}.csv"
    response = app.response_class(output.getvalue(), mimetype="text/csv")
    response.headers["Content-Disposition"] = f"attachment; filename={filename}"
    return response


@app.route("/api/calibration-report/xml", methods=["GET"])
def calibration_report_xml():
    """XML-export van hetzelfde kalibratie-rapport — voor tools/scripts die XML verwachten i.p.v. JSON."""
    date_from_str = request.args.get("from")
    date_to_str = request.args.get("to")
    try:
        report = _build_calibration_report(date_from_str, date_to_str)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400

    rows = _flatten_report_to_rows(report)
    root = ET.Element("kalibratie_rapport")
    meta = ET.SubElement(root, "meta")
    ET.SubElement(meta, "gegenereerd_op").text = report["generated_at"]
    ET.SubElement(meta, "van").text = str(report["date_range"]["from"])
    ET.SubElement(meta, "tot").text = str(report["date_range"]["to"])
    summary_el = ET.SubElement(root, "samenvatting")
    for key, value in report["summary"].items():
        if isinstance(value, dict):
            parent_el = ET.SubElement(summary_el, key)
            for sub_key, sub_value in value.items():
                # XML-elementnamen mogen niet met een cijfer beginnen (bijv.
                # laag-ID's "1".."5") — voorvoegen met "laag_" maakt het geldig.
                safe_key = f"laag_{sub_key}" if sub_key and sub_key[0].isdigit() else sub_key
                ET.SubElement(parent_el, safe_key).text = str(sub_value)
        else:
            ET.SubElement(summary_el, key).text = str(value)

    # environment en model_statistics zaten al in het onderliggende
    # rapport-object, maar werden hier nooit geserialiseerd — dit voegt
    # ze alsnog toe, op dezelfde manier als de summary hierboven.
    for top_key in ("environment", "model_statistics"):
        top_value = report.get(top_key)
        if isinstance(top_value, dict):
            top_el = ET.SubElement(root, top_key)
            for sub_key, sub_value in top_value.items():
                ET.SubElement(top_el, sub_key).text = str(sub_value)

    events_el = ET.SubElement(root, "gebeurtenissen")
    for row in rows:
        event_el = ET.SubElement(events_el, "gebeurtenis")
        for key, value in row.items():
            ET.SubElement(event_el, key).text = str(value)

    xml_bytes = ET.tostring(root, encoding="utf-8", xml_declaration=True)
    filename = f"kalibratie-rapport_{date_from_str or 'begin'}_tot_{date_to_str or 'nu'}.xml"
    response = app.response_class(xml_bytes, mimetype="application/xml")
    response.headers["Content-Disposition"] = f"attachment; filename={filename}"
    return response


@app.route("/api/browse-files", methods=["GET"])
def browse_files():
    """
    Generieke bestandssuggestie voor invulvelden die naar een bestaand
    resultaatbestand verwijzen (netflow-JSON, quote-bestand, manifest,
    pcap) — i.p.v. dat de gebruiker een volledig pad blind moet
    onthouden/intypen. Doorzoekt RESULTS_DIR op een glob-patroon; het
    invulveld zelf blijft gewoon vrije tekst, dit is puur een suggestie.
    """
    pattern = request.args.get("pattern", "*")
    matches = sorted(RESULTS_DIR.glob(pattern), key=lambda p: p.stat().st_mtime, reverse=True)[:30]
    return jsonify({
        "files": [
            {"path": str(f), "mtime": f.stat().st_mtime}
            for f in matches if f.is_file()
        ]
    })


@app.route("/api/network-interfaces", methods=["GET"])
def get_network_interfaces():
    """
    Lijst van actieve netwerkinterfaces met hun huidige IP-adres, voor de
    interface-dropdown bij Laag 2 (Windows live-capture). Sluit
    triviale/niet-relevante interfaces uit (loopback, docker-bridges,
    Tailscale) — dit voorkomt exact het probleem dat we al eerder bij de
    netflow-laag tegenkwamen: een interface-naam die verandert (bijv. na het
    wisselen van USB-ethernet-adapter) en dan een verouderde, hardcoded
    waarde in een invoerveld laat staan zonder dat iemand het merkt totdat
    een taak faalt.

    Gebruikt psutil (cross-platform) i.p.v. het Linux-specifieke 'ip'-
    commando — dezelfde library die de Windows-versies van Laag 1/3 al
    gebruiken, zodat dit endpoint ook op Windows werkt (waar Windows'
    interfacenamen bovendien vaak leesbare namen zijn zoals 'Ethernet' of
    'Wi-Fi' i.p.v. Linux' technische namen, wat de dropdown daar zelfs
    prettiger maakt).
    """
    if psutil is None:
        return jsonify({"interfaces": [], "error": "psutil niet geïnstalleerd — pip install psutil"})

    EXCLUDE_PREFIXES = ("lo", "docker", "br-", "veth", "tailscale", "loopback")
    interfaces = []
    try:
        for iface_name, addr_list in psutil.net_if_addrs().items():
            if iface_name.lower().startswith(EXCLUDE_PREFIXES):
                continue
            for addr in addr_list:
                if addr.family == socket.AF_INET:
                    interfaces.append({"name": iface_name, "ip": addr.address})
                    break  # eerste IPv4-adres per interface is voldoende
    except Exception as e:
        return jsonify({"interfaces": [], "error": str(e)})

    return jsonify({"interfaces": interfaces})


@app.route("/api/layer/5/key-status", methods=["GET"])
def check_key_status():
    """
    Controleert of er al een private key bestaat op het opgegeven pad. Gebruikt
    door de GUI om de sleutelgeneratie-knoppen uit te schakelen zodra er al een
    sleutel is — sleutelgeneratie overschrijft anders stilzwijgend de bestaande
    private key, waardoor alle eerder gesigneerde modellen en quotes in één klap
    onverifieerbaar worden (geen backup, geen bevestigingsvraag in de onderliggende
    tool). Zie ook: tpm_model_attestation.py, generate_keypair().
    """
    out_dir = os.path.expanduser(request.args.get("out_dir", ""))
    if not out_dir:
        return jsonify({"exists": False})
    private_key_path = os.path.join(out_dir, "private.pem")
    return jsonify({"exists": os.path.exists(private_key_path), "path": private_key_path})


@app.route("/api/layer/5/generate-testmodel", methods=["POST"])
def generate_test_model():
    """Maakt een persistent dummy-modelbestand aan voor TPM-demo-doeleinden."""
    params = request.json or {}
    out_path = os.path.expanduser(params.get("out_path", "~/llm-detect-results/test_model.gguf"))
    try:
        os.makedirs(os.path.dirname(out_path), exist_ok=True)
        with open(out_path, "w", encoding="utf-8") as f:
            f.write("GGUF-test-model-inhoud-voor-TPM-attestatie-demo\n")
        return jsonify({"path": out_path, "status": "ok"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/manifest/auto-build", methods=["POST"])
def auto_build_manifest():
    """
    Bouwt automatisch een manifest.json voor de correlatie-engine, door per
    laag het meest recente resultaatbestand uit de geschiedenis te pakken.
    Voorkomt dat de gebruiker handmatig paden hoeft te verzamelen/onthouden.
    """
    prefix_map = {
        "local_scan": "laag1_",
        "netflow": "laag2_",
        "realtime_agent": "laag3_",
        "gpu_fingerprint": "laag4_",
        "attestation": "laag5_verify_",
    }
    reports = {}
    sources = []

    for key, prefix in prefix_map.items():
        candidates = sorted(
            [f for f in RESULTS_DIR.glob(f"{prefix}*.json") if "_samples" not in f.name],
            key=lambda x: x.stat().st_mtime, reverse=True
        )
        if candidates:
            reports[key] = str(candidates[0])
            sources.append(f"{key} ({candidates[0].name})")

    if not reports:
        return jsonify({"error": "Geen resultaten gevonden in de geschiedenis. Draai eerst minstens één laag."}), 400

    host = "endpoint-1"
    if "local_scan" in reports:
        try:
            with open(reports["local_scan"], encoding="utf-8") as f:
                data = json.load(f)
                host = data.get("hostname", host)
        except Exception:
            pass

    manifest = {"endpoints": [{"host": host, "reports": reports}]}
    manifest_path = Path.home() / "llm-detect-results" / "manifest.json"
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)

    return jsonify({"path": str(manifest_path), "n_sources": len(sources), "sources": sources})

@app.route("/api/job/<job_id>", methods=["GET"])
def get_job_status(job_id):
    """Haalt de status van een job op."""
    if job_id not in ACTIVE_JOBS:
        return jsonify({"error": "Job niet gevonden"}), 404
    return jsonify(ACTIVE_JOBS[job_id])

@app.route("/api/results", methods=["GET"])
def get_results():
    """Haalt alle opgeslagen resultaten op (sorteer op timestamp)."""
    results = []
    for json_file in sorted(RESULTS_DIR.glob("*.json"), key=lambda x: x.stat().st_mtime, reverse=True):
        try:
            with open(json_file, encoding="utf-8") as f:
                data = json.load(f)
                size_bytes = json_file.stat().st_size
                results.append({
                    "filename": json_file.name,
                    "timestamp": datetime.fromtimestamp(json_file.stat().st_mtime).isoformat(),
                    # Bytes i.p.v. afgeronde KB — een geheeltallige KB-afronding
                    # toonde eerder "0 KB" voor elk bestand < 1024 bytes, ook als
                    # de inhoud volledig geldig en compleet was.
                    "size_bytes": size_bytes,
                    "size_display": f"{size_bytes} B" if size_bytes < 1024 else f"{size_bytes / 1024:.1f} KB",
                    "data_preview": str(data)[:200]
                })
        except Exception:
            pass
    return jsonify({"results": results})

@app.route("/api/results/<filename>", methods=["GET"])
def get_result_detail(filename):
    """Haalt volledige resultaat op (voor display of download), inclusief integriteitsstatus."""
    filepath = RESULTS_DIR / filename
    if not filepath.exists():
        return jsonify({"error": "Bestand niet gevonden"}), 404

    with open(filepath, encoding="utf-8") as f:
        data = json.load(f)

    integrity = {"status": "unknown", "valid": None}
    try:
        import result_integrity as _ri
        _key_dir = _ri.resolve_key_dir()
        _pub = _ri.get_public_key(_key_dir)
        integrity = _ri.verify_result_file(str(filepath), _pub)
    except Exception:
        pass

    return jsonify({"data": data, "_integrity_check": integrity})

@app.route("/api/results/<filename>/download", methods=["GET"])
def download_result(filename):
    """Download een resultaat-JSON."""
    filepath = RESULTS_DIR / filename
    if not filepath.exists():
        return jsonify({"error": "Bestand niet gevonden"}), 404
    return send_file(filepath, as_attachment=True, download_name=filename)

@app.route("/api/correlate", methods=["POST"])
def run_correlate():
    """Start de correlatie-engine."""
    if not os.path.isfile(os.path.join(BASE_DIR, "correlation_engine.py")):
        return jsonify({
            "error": "Correlatie is niet inbegrepen in deze installatie.",
            "detail": "De Wachter-tier gebruikt alleen Laag 2 rechtstreeks — correlatie tussen meerdere lagen heeft daarbij geen toegevoegde waarde en is daarom weggelaten.",
        }), 404

    manifest_path = os.path.expanduser(request.json.get("manifest_path", "~/llm-detect-results/manifest.json"))
    job_id = str(uuid.uuid4())[:8]

    def run_correlation():
        ACTIVE_JOBS[job_id] = {"status": "running", "output": "", "layer": "correlatie", "start": datetime.now().isoformat()}
        try:
            if not os.path.exists(manifest_path):
                raise FileNotFoundError(f"Manifest niet gevonden: {manifest_path}. Gebruik eerst 'Manifest Automatisch Opbouwen'.")
            cmd = [
                PYTHON_CMD, "-u", os.path.join(BASE_DIR, "correlation_engine.py"),
                "--manifest", manifest_path,
                "--json", str(RESULTS_DIR / f"correlatie_{job_id}.json"),
                "--stix", str(RESULTS_DIR / f"stix_{job_id}.json")
            ]
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
            output_lines = []
            for line in proc.stdout:
                output_lines.append(line.rstrip())
                ACTIVE_JOBS[job_id]["output"] = "\n".join(output_lines[-100:])
            proc.wait()
            ACTIVE_JOBS[job_id]["status"] = "done"
            ACTIVE_JOBS[job_id]["return_code"] = proc.returncode
            if proc.returncode == 0:
                check_and_notify_correlation_result(RESULTS_DIR / f"correlatie_{job_id}.json")
        except Exception as e:
            ACTIVE_JOBS[job_id]["status"] = "error"
            ACTIVE_JOBS[job_id]["error"] = str(e)
        finally:
            ACTIVE_JOBS[job_id]["end"] = datetime.now().isoformat()

    thread = threading.Thread(target=run_correlation, daemon=True)
    thread.start()

    return jsonify({"job_id": job_id, "status": "started"})

if __name__ == "__main__":
    print("🚀 LLM-Botnet Detectie GUI")

    if TLS_MODE == "tailscale-only":
        print("📍 http://localhost:5000  (en via Tailscale — alle andere netwerktoegang wordt geweigerd)")
        print("⏸️  Ctrl+C om te stoppen")
        app.run(debug=False, host="0.0.0.0", port=5000)
    else:
        import tls_utils
        cert_dir = os.path.expanduser("~/.config/llm-detect/tls")
        cert_path = os.path.join(cert_dir, "cert.pem")
        key_path = os.path.join(cert_dir, "key.pem")
        try:
            tls_utils.ensure_cert_exists(cert_path, key_path)
            print("📍 https://localhost:5000")
            print("    Je browser toont een 'niet veilig'-waarschuwing — dat is verwacht bij een")
            print("    zelfondertekend certificaat en betekent niet dat de verbinding onveilig is.")
            print("    Klik 'Geavanceerd' -> 'Toch doorgaan' om verder te gaan.")
            print("⏸️  Ctrl+C om te stoppen")
            app.run(debug=False, host="0.0.0.0", port=5000, ssl_context=(cert_path, key_path))
        except Exception as e:
            print(f"[!] Kon HTTPS-certificaat niet opzetten ({e}) — val terug op onversleuteld HTTP.")
            print("📍 http://localhost:5000")
            app.run(debug=False, host="0.0.0.0", port=5000)
